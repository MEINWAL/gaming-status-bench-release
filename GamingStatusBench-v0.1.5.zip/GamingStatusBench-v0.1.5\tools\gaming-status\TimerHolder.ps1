[CmdletBinding()]
param(
    [uint32]$Target100ns = 5070,
    [string]$StateDirectory = '',
    [string]$ConfigPath = '',
    [ValidateSet('Manual','SignIn','MachineTask')][string]$LaunchKind = 'Manual'
)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'TimerRuntime.ps1')
$paths = $null; $state = $null; $mutex = $null; $stop = $null
$owned = $false; $requested = $false; $failure = ''
try {
    if ($ConfigPath) {
        $config = Get-Content -LiteralPath $ConfigPath -Raw | ConvertFrom-Json
        $Target100ns = [uint32]$config.Target100ns
        $StateDirectory = $config.StateDirectory
    }
    $paths = Get-GsbTimerPaths $StateDirectory
    New-Item -ItemType Directory -Path (Split-Path $paths.State -Parent) -Force | Out-Null
    if ($ConfigPath) {
        foreach ($name in @('TimerHolder.ps1','TimerRuntime.ps1','TimerMachine.ps1')) {
            if ((Get-FileHash -LiteralPath (Join-Path $PSScriptRoot $name) -Algorithm SHA256).Hash -ne $config.Hashes.PSObject.Properties[$name].Value) { throw "Installed $name failed integrity verification." }
        }
    }
    if ($paths.Machine) {
        if ([Security.Principal.WindowsIdentity]::GetCurrent().User.Value -ne 'S-1-5-18') { throw 'Machine holder must run through its SYSTEM scheduled task.' }
        Assert-GsbMachineTimerFiles
        $mutexSecurity = New-Object Security.AccessControl.MutexSecurity
        $eventSecurity = New-Object Security.AccessControl.EventWaitHandleSecurity
        foreach ($sid in @('S-1-5-18','S-1-5-32-544')) {
            $identity = New-Object Security.Principal.SecurityIdentifier($sid)
            $mutexSecurity.AddAccessRule((New-Object Security.AccessControl.MutexAccessRule($identity,'FullControl','Allow')))
            $eventSecurity.AddAccessRule((New-Object Security.AccessControl.EventWaitHandleAccessRule($identity,'FullControl','Allow')))
        }
        $created = $false
        $mutex = New-Object Threading.Mutex($false,$paths.Mutex,[ref]$created,$mutexSecurity)
    }
    else { $mutex = New-Object Threading.Mutex($false,$paths.Mutex) }
    try { $owned = $mutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $owned = $true }
    if (-not $owned) { exit 0 }
    if ($paths.Machine) { $stop = New-Object Threading.EventWaitHandle($false,[Threading.EventResetMode]::ManualReset,$paths.StopEvent,[ref]$created,$eventSecurity) }
    else { $stop = New-Object Threading.EventWaitHandle($false,[Threading.EventResetMode]::ManualReset,$paths.StopEvent) }
    $process = Get-Process -Id $PID
    $cim = Get-CimInstance Win32_Process -Filter "ProcessId=$PID"
    $state = [ordered]@{
        ProcessId=$PID; ProcessStartTicks=$process.StartTime.ToUniversalTime().Ticks.ToString()
        ProcessCreationUtc=$cim.CreationDate.ToUniversalTime().ToString('o'); SessionId=$process.SessionId
        StartedUtc=[DateTime]::UtcNow.ToString('o'); BootUtc=(Get-CimInstance Win32_OperatingSystem).LastBootUpTime.ToUniversalTime().ToString('o')
        LaunchKind=$LaunchKind; Scope=$(if ($paths.Machine) { 'Machine' } else { 'User' })
        Requested100ns=$Target100ns; RequestedMs=$Target100ns / 10000.0; LogonIdentity=Get-GsbLogonIdentity
        Returned100ns=$null; Measured100ns=$null; PolicyVerified=$false
        Status='Starting'; HeartbeatUtc=[DateTime]::UtcNow.ToString('o'); ReleaseStatus=$null; Error=''
    }
    Assert-GsbTimerTarget $Target100ns
    $state.PolicyVerified = Set-GsbProcessTimerPolicy
    [uint32]$current = 0
    $status = [GsbTimerNative]::NtSetTimerResolution($Target100ns,$true,[ref]$current)
    if ($status -ne 0) { throw "NtSetTimerResolution failed: $status" }
    $requested = $true; $state.Returned100ns = $current; $state.Status = 'Running'
    if (Test-Path -LiteralPath $paths.ErrorLog) { Remove-Item -LiteralPath $paths.ErrorLog -ErrorAction Stop }
    do {
        $state.Measured100ns = (Get-GsbTimerResolution).Current100ns
        $state.HeartbeatUtc = [DateTime]::UtcNow.ToString('o')
        Write-GsbTimerJson $paths.State $state
    } while (-not $stop.WaitOne(500))
}
catch {
    $failure = $_.Exception.ToString()
    if ($null -ne $state) { $state.Status = 'Error'; $state.Error = $failure }
    try {
        if ($null -eq $paths) { $paths = Get-GsbTimerPaths $StateDirectory }
        New-Item -ItemType Directory -Path (Split-Path $paths.ErrorLog -Parent) -Force | Out-Null
        [IO.File]::WriteAllText($paths.ErrorLog,([DateTime]::UtcNow.ToString('o') + "`r`n" + $failure))
    }
    catch { [Console]::Error.WriteLine($_.Exception.Message) }
}
finally {
    if ($owned) {
        if ($requested) {
            [uint32]$current = 0
            $state.ReleaseStatus = [GsbTimerNative]::NtSetTimerResolution($Target100ns,$false,[ref]$current)
            $state.Measured100ns = $current
            if ($state.Status -ne 'Error') { $state.Status = $(if ($state.ReleaseStatus -eq 0) { 'Stopped' } else { 'Error' }) }
        }
        if ($null -ne $state) { $state.HeartbeatUtc=[DateTime]::UtcNow.ToString('o'); Write-GsbTimerJson $paths.State $state }
        $mutex.ReleaseMutex()
    }
    if ($null -ne $stop) { $stop.Dispose() }
    if ($null -ne $mutex) { $mutex.Dispose() }
}
if ($failure) { [Console]::Error.WriteLine($failure); exit 1 }
