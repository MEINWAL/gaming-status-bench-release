[CmdletBinding()]
param([switch]$Prepare, [string]$StateDirectory = '', [string]$StartupPath = '')
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot '..\TimerRuntime.ps1')
if (-not $StateDirectory) { $StateDirectory = Join-Path $env:LOCALAPPDATA 'GamingStatusBench\Timer' }
$paths = Get-GsbTimerPaths $StateDirectory
if ($paths.Machine) { throw 'This test validates the current-user Startup BAT only. Use Test-TimerMachineStartup.ps1 for SYSTEM boot validation.' }
$baselinePath = Join-Path $paths.Root 'sign-in-test-baseline.json'
if ($Prepare) {
    New-Item -ItemType Directory -Path $paths.Root -Force | Out-Null
    $baseline = [pscustomobject]@{ PreparedUtc=[DateTime]::UtcNow.ToString('o'); Identity=Get-GsbLogonIdentity; ExpectedTarget100ns=5070 }
    Write-GsbTimerJson $baselinePath $baseline
    $baseline
    return
}
$baseline = $null; $baselineError = ''
try {
    $baseline = Get-Content -LiteralPath $baselinePath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
    if (-not $baseline.PreparedUtc -or -not $baseline.Identity.UserSid -or -not $baseline.Identity.LogonId -or -not $baseline.ExpectedTarget100ns) { throw 'Sign-in baseline is incomplete.' }
    [void][DateTime]::Parse($baseline.PreparedUtc)
}
catch { $baselineError = "Prepare a current-user sign-in baseline first. $($_.Exception.Message)" }
$holder = Get-GsbTimerHolderState $StateDirectory
$auto = Get-GsbTimerAutostart -StateDirectory $StateDirectory -StartupPath $StartupPath
$result = [ordered]@{ Status='PENDING'; Reason=''; Scope='Current-user Startup BAT'; CheckedUtc=[DateTime]::UtcNow.ToString('o'); Baseline=$baseline; Holder=$holder; Autostart=$auto; Limitations='LaunchKind is a launch argument, not proof of an automatic Windows Startup trigger. Observe actual automatic execution after signing in; manual BAT execution does not satisfy that test.' }
if ($baselineError) { $result.Reason = $baselineError }
elseif ($auto.Status -ne 'Enabled') { $result.Reason = 'Startup BAT/configuration is not verified.' }
elseif (-not $holder.Running) { $result.Reason = 'No verified running holder after sign-in.' }
elseif ($holder.State.LaunchKind -ne 'SignIn') { $result.Reason = 'The holder is not marked as a Startup BAT launch.' }
elseif ($holder.State.LogonIdentity.UserSid -ne $baseline.Identity.UserSid -or $holder.State.LogonIdentity.LogonId -eq $baseline.Identity.LogonId) { $result.Reason = 'A new logon session for the same Windows user has not been proven.' }
else {
    $id = $holder.State.LogonIdentity.LogonId
    $logon = Get-CimInstance Win32_LogonSession -Filter "LogonId='$id'" -ErrorAction Stop
    if ($null -eq $logon -or $logon.LogonType -notin @(2,10,11) -or $logon.StartTime.ToUniversalTime() -le [DateTime]::Parse($baseline.PreparedUtc).ToUniversalTime()) {
        $result.Reason = 'A new interactive Windows logon after preparation has not been proven.'
    }
    elseif ($holder.State.Requested100ns -ne $baseline.ExpectedTarget100ns -or -not $holder.State.PolicyVerified) { $result.Reason = 'Requested target or process policy did not verify.' }
    else { $result.Status = 'PASS'; $result.Reason = 'Verified Startup BAT configuration and a matching 5070 holder in a new interactive Windows logon session. Automatic execution must also be observed; manual BAT execution is not equivalent.' }
}
New-Item -ItemType Directory -Path $paths.Root -Force | Out-Null
Write-GsbTimerJson (Join-Path $paths.Root 'sign-in-test-result.json') $result
[pscustomobject]$result
