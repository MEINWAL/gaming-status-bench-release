function Assert-GsbTimerAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    try {
        if (-not (New-Object Security.Principal.WindowsPrincipal($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Run as administrator to configure or control the machine timer task.' }
    }
    finally { $identity.Dispose() }
}

function Get-GsbMachineTimerPaths {
    Get-GsbTimerPaths (Join-Path $env:ProgramData 'GamingStatusBench\TimerMachine')
}

function Set-GsbMachineDirectorySecurity {
    param([string]$Path)
    if ((Get-Item -LiteralPath $Path -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Refusing a reparse-point installation: $Path" }
    $acl = New-Object Security.AccessControl.DirectorySecurity
    $acl.SetAccessRuleProtection($true,$false)
    $acl.SetOwner((New-Object Security.Principal.SecurityIdentifier('S-1-5-32-544')))
    foreach ($pair in @(@('S-1-5-18','FullControl'),@('S-1-5-32-544','FullControl'),@('S-1-5-32-545','ReadAndExecute'))) {
        $sid = New-Object Security.Principal.SecurityIdentifier($pair[0])
        $acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule($sid,$pair[1],'ContainerInherit, ObjectInherit','None','Allow')))
    }
    Set-Acl -LiteralPath $Path -AclObject $acl -ErrorAction Stop
}

function Assert-GsbMachineTimerFiles {
    $paths = Get-GsbMachineTimerPaths
    $items = @((Split-Path $paths.Root -Parent),$paths.Root,(Split-Path $paths.State -Parent),$paths.Config,$paths.Holder,$paths.Runtime,(Join-Path $paths.Root 'TimerMachine.ps1'))
    $write = [Security.AccessControl.FileSystemRights]::Write -bor [Security.AccessControl.FileSystemRights]::Delete -bor [Security.AccessControl.FileSystemRights]::DeleteSubdirectoriesAndFiles -bor [Security.AccessControl.FileSystemRights]::ChangePermissions -bor [Security.AccessControl.FileSystemRights]::TakeOwnership
    foreach ($item in $items) {
        $node = Get-Item -LiteralPath $item -Force -ErrorAction Stop
        if ($node.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Unsafe machine path: $item" }
        $acl = Get-Acl -LiteralPath $item -ErrorAction Stop
        if ($acl.GetOwner([Security.Principal.SecurityIdentifier]).Value -notin @('S-1-5-18','S-1-5-32-544')) { throw "Machine installation has an untrusted owner: $item" }
        foreach ($rule in $acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier])) {
            if ($rule.AccessControlType -eq 'Allow' -and ($rule.FileSystemRights -band $write) -and $rule.IdentityReference.Value -notin @('S-1-5-18','S-1-5-32-544')) { throw "Machine installation is writable by a non-administrator: $item" }
        }
    }
}

function Get-GsbMachineTimerArguments {
    $paths = Get-GsbMachineTimerPaths
    '-NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File "{0}" -ConfigPath "{1}" -LaunchKind MachineTask' -f $paths.Holder,$paths.Config
}

function Set-GsbMachineFileOwner {
    param([string]$Path)
    $acl = Get-Acl -LiteralPath $Path -ErrorAction Stop
    $acl.SetOwner((New-Object Security.Principal.SecurityIdentifier('S-1-5-32-544')))
    Set-Acl -LiteralPath $Path -AclObject $acl -ErrorAction Stop
}

function Get-GsbMachineTimerAutostart {
    $paths = Get-GsbMachineTimerPaths
    $result = [ordered]@{Status='Disabled';Scope='Machine';Target100ns=$null;Path='Task Scheduler\GamingStatusBench-Timer-Machine';Error='';TaskState='Missing'}
    try {
        $task = @(Get-ScheduledTask -TaskName 'GamingStatusBench-Timer-Machine' -TaskPath '\' -ErrorAction SilentlyContinue)
        if ($task.Count -eq 0) {
            if (Test-Path -LiteralPath $paths.Config) { throw 'Machine configuration exists but its scheduled task is missing.' }
            return [pscustomobject]$result
        }
        $task = $task[0]
        if ($task.Description -ne 'GamingStatusBench managed machine timer holder v1') { throw 'An unmanaged task uses the reserved GSB task name.' }
        if ($task.Principal.UserId -notin @('SYSTEM','S-1-5-18','NT AUTHORITY\SYSTEM') -or [string]$task.Principal.LogonType -ne 'ServiceAccount') { throw 'Machine task must run as SYSTEM with service-account logon.' }
        if ($task.Actions.Count -ne 1 -or $null -eq $task.Actions[0].PSObject.Properties['Execute'] -or $task.Actions[0].Execute -ne (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe') -or $task.Actions[0].Arguments -cne (Get-GsbMachineTimerArguments)) { throw 'Machine task action does not match the protected holder.' }
        $types = @($task.Triggers | ForEach-Object { $_.CimClass.CimClassName })
        if ($types.Count -ne 2 -or $types -notcontains 'MSFT_TaskBootTrigger' -or $types -notcontains 'MSFT_TaskLogonTrigger' -or @($task.Triggers | Where-Object { -not $_.Enabled }).Count -gt 0) { throw 'Enabled boot and logon triggers are required.' }
        if ([string]$task.Settings.MultipleInstances -ne 'IgnoreNew' -or $task.Settings.ExecutionTimeLimit -ne 'PT0S') { throw 'Machine task must ignore duplicates and have no runtime limit.' }
        Assert-GsbMachineTimerFiles
        $config = Get-Content -LiteralPath $paths.Config -Raw | ConvertFrom-Json
        if ($config.Scope -ne 'Machine' -or $config.StateDirectory -ne $paths.Root) { throw 'Machine configuration scope/path did not verify.' }
        foreach ($name in @('TimerHolder.ps1','TimerRuntime.ps1','TimerMachine.ps1')) {
            if ((Get-FileHash -LiteralPath (Join-Path $paths.Root $name) -Algorithm SHA256).Hash -ne $config.Hashes.PSObject.Properties[$name].Value) { throw "Installed $name failed integrity verification." }
        }
        Assert-GsbTimerTarget ([uint32]$config.Target100ns)
        $result.Target100ns = $config.Target100ns; $result.TaskState = [string]$task.State
        $info = Get-ScheduledTaskInfo -TaskName 'GamingStatusBench-Timer-Machine' -ErrorAction Stop
        $result.LastTaskResult = $info.LastTaskResult
        $result.LastTaskRun = $info.LastRunTime.ToString('o')
        $result.Status = if ($task.Settings.Enabled) { 'Enabled' } else { 'Disabled' }
    }
    catch { $result.Status='Invalid'; $result.Error=$_.Exception.Message }
    [pscustomobject]$result
}

function Get-GsbLegacyTimerEntries {
    $rows = @()
    foreach ($path in @('HKLM:\Software\Microsoft\Windows\CurrentVersion\Run','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run','HKCU:\Software\Microsoft\Windows\CurrentVersion\Run')) {
        if (-not (Test-Path -LiteralPath $path)) { continue }
        $key = Get-Item -LiteralPath $path -ErrorAction Stop
        foreach ($name in $key.GetValueNames()) {
            $value = [string]$key.GetValue($name,$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
            if ($value -match '(?i)(^|[\\"\s])SetTimerResolution\.exe(?=["\s]|$)') {
                $rows += [pscustomobject]@{Path=$path;Name=$name;Command=$value;Kind=[string]$key.GetValueKind($name)}
            }
        }
    }
    return $rows
}

function Get-GsbLegacyTimerTasks {
    Assert-GsbTimerAdministrator
    $runner = Join-Path $env:ProgramData 'TimerResolution\Set-TimerResolution.ps1'
    $knownHash = '52A6A3960795433956BA1676DA466744CE965217AB8C7C0E2B61ADA96AF366B6'
    $trusted = (Test-Path -LiteralPath $runner) -and (Get-FileHash -LiteralPath $runner -Algorithm SHA256).Hash -eq $knownHash
    foreach ($task in Get-ScheduledTask -ErrorAction Stop) {
        if (@($task.Actions | Where-Object { $null -ne $_.PSObject.Properties['Arguments'] -and $_.Arguments -and $_.Arguments.IndexOf($runner,[StringComparison]::OrdinalIgnoreCase) -ge 0 }).Count -eq 0) { continue }
        $action = $task.Actions[0]
        $pattern = '^\s*-NoProfile\s+-ExecutionPolicy\s+Bypass\s+-WindowStyle\s+Hidden\s+-File\s+"' + [regex]::Escape($runner) + '"\s+-Desired100ns\s+(?<target>\d+)\s*$'
        $matchesKnown = $task.Actions.Count -eq 1 -and $null -ne $action.PSObject.Properties['Execute'] -and $action.Execute -eq (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe') -and $action.Arguments -match $pattern -and $task.Principal.UserId -in @('SYSTEM','S-1-5-18','NT AUTHORITY\SYSTEM')
        $target = if ($matchesKnown) { [uint32]$matches.target } else { $null }
        [pscustomobject]@{TaskName=$task.TaskName;TaskPath=$task.TaskPath;Enabled=[bool]$task.Settings.Enabled;State=[string]$task.State;Execute=$action.Execute;Arguments=$action.Arguments;Runner=$runner;Target100ns=$target;Recognized=($matchesKnown -and $trusted)}
    }
}

function Get-GsbLegacyScriptTimerProcesses {
    Assert-GsbTimerAdministrator
    $runner = Join-Path $env:ProgramData 'TimerResolution\Set-TimerResolution.ps1'
    $pattern = '(?i)(?:^|\s)-File\s+"' + [regex]::Escape($runner) + '"(?=\s|$)'
    Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction Stop | Where-Object { $_.CommandLine -and $_.CommandLine -match $pattern }
}

function Disable-GsbLegacyTimerTasks {
    param([Parameter(Mandatory=$true)][string]$BackupDirectory)
    Assert-GsbTimerAdministrator
    $tasks = @(Get-GsbLegacyTimerTasks)
    if ($tasks.Count -eq 0) { return @() }
    if (@($tasks | Where-Object { -not $_.Recognized }).Count) { throw 'An altered or unrecognized legacy timer task requires manual review; nothing was disabled.' }
    $service = New-Object -ComObject 'Schedule.Service'; $service.Connect()
    $snapshots = @($tasks | ForEach-Object { [pscustomobject]@{TaskName=$_.TaskName;TaskPath=$_.TaskPath;Enabled=$_.Enabled;Execute=$_.Execute;Arguments=$_.Arguments;Xml=(Export-ScheduledTask -TaskName $_.TaskName -TaskPath $_.TaskPath);SecurityDescriptor=$service.GetFolder($_.TaskPath).GetTask($_.TaskName).GetSecurityDescriptor(7)} })
    $backupPath = Join-Path $BackupDirectory 'legacy-timer-tasks.json'
    Write-GsbTimerJson $backupPath $snapshots
    $saved = @(Get-Content -LiteralPath $backupPath -Raw | ConvertFrom-Json)
    if ($saved.Count -ne $snapshots.Count) { throw 'Legacy task backup did not verify.' }
    $disabled = @()
    try {
        foreach ($row in $snapshots) {
            $live = Get-ScheduledTask -TaskName $row.TaskName -TaskPath $row.TaskPath -ErrorAction Stop
            if ($live.Actions.Count -ne 1 -or $live.Actions[0].Execute -cne $row.Execute -or $live.Actions[0].Arguments -cne $row.Arguments) { throw 'Legacy task changed after backup; cleanup aborted.' }
            [void](Disable-ScheduledTask -TaskName $row.TaskName -TaskPath $row.TaskPath -ErrorAction Stop)
            $disabled += $row
            if ($live.State -eq 'Running') { Stop-ScheduledTask -TaskName $row.TaskName -TaskPath $row.TaskPath -ErrorAction Stop }
        }
        foreach ($process in @(Get-GsbLegacyScriptTimerProcesses)) {
            $live = Get-CimInstance Win32_Process -Filter "ProcessId=$($process.ProcessId)" -ErrorAction Stop
            if ($null -ne $live -and $live.CreationDate -eq $process.CreationDate -and $live.CommandLine -ceq $process.CommandLine) { Stop-Process -Id $process.ProcessId -Force -ErrorAction Stop }
        }
        if (@(Get-GsbLegacyTimerTasks | Where-Object { $_.Enabled -or $_.State -eq 'Running' }).Count -or @(Get-GsbLegacyScriptTimerProcesses).Count) { throw 'Legacy task/process cleanup did not verify.' }
        return $snapshots
    }
    catch {
        foreach ($row in $disabled) { if ($row.Enabled) { [void](Enable-ScheduledTask -TaskName $row.TaskName -TaskPath $row.TaskPath -ErrorAction Stop) } }
        throw
    }
}

function Enable-GsbMachineTimerAutostart {
    param([uint32]$Target100ns=5070,[switch]$ReplaceLegacy)
    Assert-GsbTimerAdministrator
    Assert-GsbTimerTarget $Target100ns
    $paths = Get-GsbMachineTimerPaths
    $existingTask = @(Get-ScheduledTask -TaskPath '\' -ErrorAction Stop | Where-Object { $_.TaskName -eq 'GamingStatusBench-Timer-Machine' })
    if ($existingTask.Count -gt 0 -and $existingTask[0].Description -ne 'GamingStatusBench managed machine timer holder v1') { throw 'Refusing to overwrite an unmanaged scheduled task.' }
    $legacy = @(Get-GsbLegacyTimerEntries)
    $legacyTasks = @(Get-GsbLegacyTimerTasks | Where-Object { $_.Enabled -or $_.State -eq 'Running' })
    $legacyProcesses = @(Get-CimInstance Win32_Process -Filter "Name='SetTimerResolution.exe'" -ErrorAction Stop)
    if (-not $ReplaceLegacy -and ($legacy.Count -gt 0 -or $legacyTasks.Count -gt 0 -or $legacyProcesses.Count -gt 0)) { throw 'A legacy timer startup/process exists. Inspect it and explicitly choose replacement before enabling another holder.' }
    $userRoot = Join-Path $env:LOCALAPPDATA 'GamingStatusBench\Timer'
    $userPaths = Get-GsbTimerPaths $userRoot
    if (Test-Path -LiteralPath $userPaths.Startup) {
        if (-not ([IO.File]::ReadAllText($userPaths.Startup).Contains('rem GamingStatusBench managed timer holder - current-user sign-in'))) { throw 'Refusing to replace an unmanaged user Startup BAT.' }
    }
    foreach ($dir in @((Split-Path $paths.Root -Parent),$paths.Root,(Split-Path $paths.State -Parent))) {
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -ErrorAction Stop | Out-Null }
        Set-GsbMachineDirectorySecurity $dir
    }
    $backupDir = Join-Path $paths.Root ('Backups\' + [DateTime]::UtcNow.ToString('yyyyMMddTHHmmssZ') + '-' + [guid]::NewGuid().ToString('N').Substring(0,8))
    New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
    $userBat = if (Test-Path -LiteralPath $userPaths.Startup) { [IO.File]::ReadAllText($userPaths.Startup) } else { $null }
    $taskXml = if ($existingTask.Count) { Export-ScheduledTask -TaskName 'GamingStatusBench-Timer-Machine' } else { $null }
    Write-GsbTimerJson (Join-Path $backupDir 'startup-before.json') ([ordered]@{CreatedUtc=[DateTime]::UtcNow.ToString('o');LegacyRunEntries=$legacy;UserStartupPath=$userPaths.Startup;UserStartupContent=$userBat;PreviousTaskXml=$taskXml})
    $before = Get-Content -LiteralPath (Join-Path $backupDir 'startup-before.json') -Raw | ConvertFrom-Json
    if (@($before.LegacyRunEntries).Count -ne $legacy.Count -or $before.UserStartupContent -cne $userBat) { throw 'Startup backup did not verify.' }
    $savedFiles = @()
    foreach ($name in @('TimerHolder.ps1','TimerRuntime.ps1','TimerMachine.ps1','config.json')) {
        $file = Join-Path $paths.Root $name
        if (Test-Path -LiteralPath $file) { Copy-Item -LiteralPath $file -Destination (Join-Path $backupDir $name) -ErrorAction Stop; $savedFiles += $name }
    }
    $removed = @(); $registered = $false; $disabledLegacyTasks = @()
    try {
    if ($existingTask.Count) { [void](Disable-ScheduledTask -TaskName 'GamingStatusBench-Timer-Machine' -ErrorAction Stop) }
    if ((Get-GsbTimerHolderState $userRoot).Running) { [void](Stop-GsbTimerHolder $userRoot) }
    if ((Get-GsbTimerHolderState $paths.Root).Running) { [void](Stop-GsbTimerHolder $paths.Root) }
    $hashes = [ordered]@{}
    foreach ($name in @('TimerHolder.ps1','TimerRuntime.ps1','TimerMachine.ps1')) {
        $destination = Join-Path $paths.Root $name
        if ((Test-Path -LiteralPath $destination) -and ((Get-Item -LiteralPath $destination -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Refusing to overwrite a linked machine script.' }
        Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination $destination -Force -ErrorAction Stop
        Set-GsbMachineFileOwner $destination
        $hashes[$name] = (Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash
    }
    Write-GsbTimerJson $paths.Config ([ordered]@{Scope='Machine';Target100ns=$Target100ns;StateDirectory=$paths.Root;Hashes=$hashes})
    Set-GsbMachineFileOwner $paths.Config
    Assert-GsbMachineTimerFiles
    $action = New-ScheduledTaskAction -Execute (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe') -Argument (Get-GsbMachineTimerArguments) -WorkingDirectory $paths.Root
    $triggers = @((New-ScheduledTaskTrigger -AtStartup),(New-ScheduledTaskTrigger -AtLogOn))
    $principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
    $settings = New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit ([TimeSpan]::Zero) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -Disable
    [void](Register-ScheduledTask -TaskName 'GamingStatusBench-Timer-Machine' -Action $action -Trigger $triggers -Principal $principal -Settings $settings -Description 'GamingStatusBench managed machine timer holder v1' -Force -ErrorAction Stop)
    $registered = $true
    $service = New-Object -ComObject 'Schedule.Service'
    $service.Connect()
    $service.GetFolder('\').GetTask('GamingStatusBench-Timer-Machine').SetSecurityDescriptor('D:P(A;;GA;;;SY)(A;;GA;;;BA)(A;;GR;;;BU)',0)
    if ((Get-GsbMachineTimerAutostart).Status -ne 'Disabled') { throw 'Protected machine task did not verify before activation.' }
    foreach ($row in $legacy) {
        $key = Get-Item -LiteralPath $row.Path
        if ([string]$key.GetValue($row.Name,$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames) -cne $row.Command) { throw 'Legacy startup changed after backup; removal aborted.' }
        Remove-ItemProperty -LiteralPath $row.Path -Name $row.Name -ErrorAction Stop
        $removed += $row
        if ((Get-Item -LiteralPath $row.Path).GetValueNames() -contains $row.Name) { throw 'Legacy timer startup removal did not verify.' }
    }
    foreach ($process in $legacyProcesses) {
        $live = Get-CimInstance Win32_Process -Filter "ProcessId=$($process.ProcessId)" -ErrorAction Stop
        if ($null -ne $live -and $live.CreationDate -eq $process.CreationDate -and $live.ExecutablePath -eq $process.ExecutablePath) {
            Stop-Process -Id $process.ProcessId -Force -ErrorAction Stop
        }
    }
    if ($ReplaceLegacy) { $disabledLegacyTasks = @(Disable-GsbLegacyTimerTasks $backupDir) }
    if (@(Get-GsbLegacyTimerEntries).Count -gt 0 -or @(Get-CimInstance Win32_Process -Filter "Name='SetTimerResolution.exe'").Count -gt 0) { throw 'A legacy timer entry/process remains. Machine holder was not activated.' }
    if ($null -ne $userBat) { [void](Disable-GsbTimerAutostart $userRoot $userPaths.Startup) }
    [void](Enable-ScheduledTask -TaskName 'GamingStatusBench-Timer-Machine' -ErrorAction Stop)
    $verified = Get-GsbMachineTimerAutostart
    if ($verified.Status -ne 'Enabled') { throw "Machine task failed verification: $($verified.Error). Backup: $backupDir" }
    $verified | Add-Member -NotePropertyName BackupDirectory -NotePropertyValue $backupDir
    return $verified
    }
    catch {
        $message = $_.Exception.Message
        $rollbackErrors = @()
        try {
            if ($registered) { [void](Disable-ScheduledTask -TaskName 'GamingStatusBench-Timer-Machine'); Unregister-ScheduledTask -TaskName 'GamingStatusBench-Timer-Machine' -Confirm:$false -ErrorAction Stop }
            foreach ($name in $savedFiles) { Copy-Item -LiteralPath (Join-Path $backupDir $name) -Destination (Join-Path $paths.Root $name) -Force -ErrorAction Stop }
            if ($null -ne $taskXml) { [void](Register-ScheduledTask -TaskName 'GamingStatusBench-Timer-Machine' -Xml $taskXml -Force -ErrorAction Stop) }
            foreach ($row in $removed) {
                $key = Get-Item -LiteralPath $row.Path
                if ($key.GetValueNames() -contains $row.Name) { throw 'Rollback refuses to overwrite a new Run value.' }
                [void](New-ItemProperty -LiteralPath $row.Path -Name $row.Name -Value $row.Command -PropertyType $row.Kind -ErrorAction Stop)
                if ((Get-Item -LiteralPath $row.Path).GetValue($row.Name) -cne $row.Command) { throw 'Run value rollback did not verify.' }
            }
            foreach ($row in $disabledLegacyTasks) { if ($row.Enabled) { [void](Enable-ScheduledTask -TaskName $row.TaskName -TaskPath $row.TaskPath -ErrorAction Stop) } }
            if ($null -ne $userBat -and -not (Test-Path -LiteralPath $userPaths.Startup)) { [IO.File]::WriteAllText($userPaths.Startup,$userBat,(New-Object Text.UTF8Encoding($false))) }
            if ($null -eq $taskXml -and $savedFiles -notcontains 'config.json' -and (Test-Path -LiteralPath $paths.Config)) { Remove-Item -LiteralPath $paths.Config -ErrorAction Stop }
        }
        catch { $rollbackErrors += $_.Exception.Message }
        throw "Machine installation failed: $message Backup: $backupDir. Rollback errors: $($rollbackErrors -join '; '). Previously stopped processes were not restarted."
    }
}

function Start-GsbMachineTimer {
    param([uint32]$Target100ns=5070)
    Assert-GsbTimerAdministrator
    $auto = Get-GsbMachineTimerAutostart
    if ($auto.Status -ne 'Enabled' -or $auto.Target100ns -ne $Target100ns) { throw 'Machine startup must be verified and configured for the selected target before starting it.' }
    $paths = Get-GsbMachineTimerPaths
    $state = Get-GsbTimerHolderState $paths.Root
    if ($state.Running) { return $state }
    $exitDeadline = [DateTime]::UtcNow.AddSeconds(10)
    while ((Get-ScheduledTask -TaskName 'GamingStatusBench-Timer-Machine').State -eq 'Running') {
        $state = Get-GsbTimerHolderState $paths.Root
        if ($state.Running) { return $state }
        if ([DateTime]::UtcNow -gt $exitDeadline) { throw 'Existing scheduled holder has not exited or verified. No duplicate was started.' }
        Start-Sleep -Milliseconds 100
    }
    Start-ScheduledTask -TaskName 'GamingStatusBench-Timer-Machine' -ErrorAction Stop
    $deadline = [DateTime]::UtcNow.AddSeconds(25)
    do {
        Start-Sleep -Milliseconds 200
        $state = Get-GsbTimerHolderState $paths.Root
        if ($state.Running -and $state.State.Requested100ns -eq $Target100ns -and $state.State.LogonIdentity.UserSid -eq 'S-1-5-18' -and $state.State.SessionId -eq 0) { return $state }
    } while ([DateTime]::UtcNow -lt $deadline)
    throw "Machine holder did not verify. $($state.Error) Error log: $($paths.ErrorLog)"
}

function Disable-GsbMachineTimerAutostart {
    Assert-GsbTimerAdministrator
    $auto = Get-GsbMachineTimerAutostart
    if ($auto.Status -eq 'Invalid') { throw $auto.Error }
    if ($auto.TaskState -ne 'Missing') { [void](Disable-ScheduledTask -TaskName 'GamingStatusBench-Timer-Machine' -ErrorAction Stop) }
    if ((Get-GsbMachineTimerAutostart).Status -ne 'Disabled') { throw 'Machine startup disable did not verify.' }
    return $true
}
