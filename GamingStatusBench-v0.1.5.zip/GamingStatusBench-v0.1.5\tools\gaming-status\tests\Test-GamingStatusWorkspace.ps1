[CmdletBinding()]
param([switch]$SkipScan, [string]$EvidenceDirectory = '')
$ErrorActionPreference = 'Stop'
$source = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$root = [IO.Path]::GetFullPath((Join-Path $source '..\..'))
$testDirectory = Join-Path $env:TEMP ('GSB timer QA ' + [guid]::NewGuid())
if (-not $EvidenceDirectory) { $EvidenceDirectory = Join-Path $root 'reports\ui-qa' }
New-Item -ItemType Directory -Path $testDirectory,$EvidenceDirectory -Force | Out-Null
. (Join-Path $source 'TimerRuntime.ps1')
$results = New-Object 'System.Collections.Generic.List[object]'
function Assert-Test {
    param([bool]$Condition, [string]$Name)
    if (-not $Condition) { throw "FAIL: $Name" }
    $results.Add([pscustomobject]@{ Test = $Name; Status = 'PASS' })
    Write-Output "PASS: $Name"
}
function Assert-Throws {
    param([scriptblock]$Action, [string]$Name)
    $thrown = $false
    try { & $Action | Out-Null } catch { $thrown = $true }
    Assert-Test $thrown $Name
}
function Save-UiScreenshot {
    param([string]$Name)
    [Windows.Forms.Application]::DoEvents()
    Update-SectionLayout
    [Windows.Forms.Application]::DoEvents()
    $bitmap = New-Object Drawing.Bitmap($script:Form.Width,$script:Form.Height)
    try {
        $script:Form.DrawToBitmap($bitmap,(New-Object Drawing.Rectangle(0,0,$bitmap.Width,$bitmap.Height)))
        $bitmap.Save((Join-Path $EvidenceDirectory "$Name.png"))
    }
    finally { $bitmap.Dispose() }
}
try {
    $normalPaths = Get-GsbTimerPaths $testDirectory
    $aliasPaths = Get-GsbTimerPaths ($testDirectory + '\')
    Assert-Test ($normalPaths.Root -eq $aliasPaths.Root -and $normalPaths.Mutex -eq $aliasPaths.Mutex -and $normalPaths.StopEvent -eq $aliasPaths.StopEvent) 'Trailing directory separators preserve canonical holder identity and stop-event keys'
    $userPaths = Get-GsbTimerPaths (Join-Path $env:LOCALAPPDATA 'GamingStatusBench\Timer')
    Assert-Test ((Get-GsbTimerPaths ($userPaths.Root + '\')).Root -eq $userPaths.Root) 'Current-user path alias cannot bypass managed-scope recognition'
    $first = Start-GsbTimerHolder 5070 $testDirectory
    Assert-Test ($first.Running -and $first.State.Requested100ns -eq 5070 -and $first.State.PolicyVerified) '5070 request starts and policy read-back verifies'
    Start-Sleep -Milliseconds 1200
    $second = Start-GsbTimerHolder 5070 ($testDirectory + '\')
    Assert-Test ($first.State.ProcessId -eq $second.State.ProcessId) 'Repeated start uses one holder process'
    Assert-Throws { Start-GsbTimerHolder 6000 $testDirectory } 'Changing a running target is rejected'
    Assert-Throws { Start-GsbTimerHolder 1 $testDirectory } 'Unsupported target is rejected before launch'
    [void](Stop-GsbTimerHolder ($testDirectory + '\'))
    $stopped = Get-GsbTimerHolderState $testDirectory
    Assert-Test (-not $stopped.Running -and $stopped.State.Status -eq 'Stopped' -and $stopped.State.ReleaseStatus -eq 0) 'Stop verifies matched request release'
    [void](Stop-GsbTimerHolder $testDirectory)
    Assert-Test (-not (Get-GsbTimerHolderState $testDirectory).Running) 'Repeated stop does not create another request'
    $startup = Join-Path $testDirectory 'Timer QA.bat'
    $auto = Enable-GsbTimerAutostart 5070 $testDirectory $startup
    Assert-Test ($auto.Status -eq 'Enabled' -and $auto.Target100ns -eq 5070) 'Startup BAT, configuration and installed script hashes verify'
    $installed = Join-Path $testDirectory 'TimerHolder.ps1'
    [IO.File]::AppendAllText($installed,"`r`n# QA tamper`r`n")
    Assert-Test ((Get-GsbTimerAutostart $testDirectory $startup).Status -eq 'Invalid') 'Autostart detects installed script modification'
    $failureInfo = New-Object Diagnostics.ProcessStartInfo
    $failureInfo.FileName = Join-Path $PSHOME 'powershell.exe'
    $failureInfo.Arguments = '-NoProfile -ExecutionPolicy Bypass -File "{0}" -ConfigPath "{1}"' -f $installed,(Join-Path $testDirectory 'config.json')
    $failureInfo.UseShellExecute = $false; $failureInfo.CreateNoWindow = $true
    $failureProcess = [Diagnostics.Process]::Start($failureInfo)
    try {
        if (-not $failureProcess.WaitForExit(10000)) { throw 'Expected integrity-failure process did not exit.' }
        $failedHolder = Get-GsbTimerHolderState $testDirectory
        Assert-Test ($failureProcess.ExitCode -ne 0 -and -not $failedHolder.Running -and $failedHolder.Error -like '*integrity verification*') 'Pre-heartbeat startup failure persists and is visible after the process exits'
    }
    finally { $failureProcess.Dispose() }
    [void](Enable-GsbTimerAutostart 5070 $testDirectory $startup)
    $batchInfo = New-Object Diagnostics.ProcessStartInfo
    $batchInfo.FileName = $env:ComSpec; $batchInfo.Arguments = '/d /c ""{0}""' -f $startup
    $batchInfo.UseShellExecute = $false; $batchInfo.CreateNoWindow = $true
    $batchProcess = [Diagnostics.Process]::Start($batchInfo)
    if (-not $batchProcess.WaitForExit(10000)) { throw 'Startup BAT shell did not exit within 10 seconds.' }
    Assert-Test ($batchProcess.ExitCode -eq 0) 'Exact Startup BAT executes successfully (manual launch, not a sign-in test)'
    $batchProcess.Dispose()
    $deadline = [DateTime]::UtcNow.AddSeconds(15)
    do { Start-Sleep -Milliseconds 100; $state = Get-GsbTimerHolderState $testDirectory } while (-not $state.Running -and [DateTime]::UtcNow -lt $deadline)
    Assert-Test ($state.Running -and $state.State.Requested100ns -eq 5070 -and $state.State.LaunchKind -eq 'SignIn') 'Startup BAT launches the configured background holder'
    $signInTest = Join-Path $source 'tests\Test-TimerSignIn.ps1'
    Assert-Throws { & $signInTest -StateDirectory (Get-GsbMachineTimerPaths).Root } 'Current-user sign-in validator refuses machine scope without changing it'
    $signIn = & $signInTest -StateDirectory $testDirectory -StartupPath $startup
    Assert-Test ($signIn.Status -eq 'PENDING' -and $signIn.Reason -like '*baseline first*' -and $signIn.Scope -eq 'Current-user Startup BAT') 'Missing sign-in baseline returns pending rather than a false pass'
    [void](& $signInTest -Prepare -StateDirectory $testDirectory)
    $signIn = & $signInTest -StateDirectory $testDirectory -StartupPath $startup
    Assert-Test ($signIn.Status -eq 'PENDING' -and $signIn.Reason -like '*new logon session*' -and $signIn.Limitations -like '*manual BAT execution does not satisfy*') 'Manual BAT launch in the same logon cannot pass sign-in validation'
    Write-GsbTimerJson (Join-Path $testDirectory 'sign-in-test-baseline.json') ([pscustomobject]@{PreparedUtc='bad date'})
    $signIn = & $signInTest -StateDirectory $testDirectory -StartupPath $startup
    Assert-Test ($signIn.Status -eq 'PENDING' -and $signIn.Reason -like '*baseline first*') 'Malformed sign-in baseline remains pending'
    [void](Disable-GsbTimerAutostart $testDirectory $startup)
    Assert-Test ((Get-GsbTimerAutostart $testDirectory $startup).Status -eq 'Disabled' -and (Get-GsbTimerHolderState $testDirectory).Running) 'Disabling autostart removes BAT but preserves a running holder'
    [void](Stop-GsbTimerHolder $testDirectory)

    . (Join-Path $source 'GamingStatusGui.ps1') -NoShow -OutputDir (Join-Path $testDirectory 'reports') -SampleReportPath (Join-Path $root 'sample-report.json') -TimerStateDirectory $testDirectory -StartupPath $startup
    $ErrorActionPreference = 'Stop'
    $script:Form.Show()
    [Windows.Forms.Application]::DoEvents()
    Assert-Test ($script:Navigation.Items.Count -eq 9) 'All seven subject sections plus Logs and Report JSON are present'
    Assert-Test ($script:TimerScopePinned -and -not $script:StartupScopeBox.Enabled) 'Explicit custom test directory fixes its scope instead of presenting a misleading machine switch'
    Assert-Test ($script:MeasurementStatus.Text -like '*STALE*') 'Historical/sample measurements are explicitly stale'
    Assert-Test ($script:GuiPrivilegeLabel.Text -eq $(if (Test-IsAdmin) {'GUI: Admin'} else {'GUI: Standard user'}) -and $script:HostLabel.Text -like '*Scan elevated:*') 'Current GUI privilege is labeled independently of the loaded scan privilege'
    $names = @($script:ActionButtons | ForEach-Object { $_.Text })
    Assert-Test (@($names | Group-Object | Where-Object { $_.Count -gt 1 }).Count -eq 0) 'Action labels are unique'
    $script:Navigation.SelectedItem = 'Timer'
    Invoke-GuiAction 'Start holder' { Set-TimerHold $true }
    Assert-Test ($script:ActionStatus.Text -like 'Verified:*' -or $script:ActionStatus.Text -like 'Review:*') 'Timer start reports verification or an explicit mismatch'
    Assert-Test ($script:TimerHoldActive -and $script:HolderLabel.Text -like '*5070*') 'GUI displays the actual requested target from the holder'
    Assert-Test (-not $script:TimerTarget.Enabled) 'Running request locks the target control'
    Save-UiScreenshot 'timer-running-1280'
    Invoke-GuiAction 'Stop holder' { Set-TimerHold $false }
    Assert-Test (-not $script:TimerHoldActive -and $script:TimerTarget.Enabled) 'GUI stop releases request and unlocks target'
    Invoke-GuiAction 'QA failure' { throw 'Deliberate verification failure' }
    Assert-Test ($script:ActionStatus.Text -like 'Failed:*' -and -not $script:IsBusy -and $script:RunButton.Enabled) 'Failure remains visible and controls recover'
    Invoke-GuiAction 'QA busy guard' {
        Assert-Test (-not $script:RunButton.Enabled -and -not $script:AutostartCheck.Enabled) 'Conflicting controls are disabled while an action runs' | Out-Null
        New-GuiResult 'Busy guard checked.'
    }
    $script:Navigation.SelectedItem = 'Network'
    Assert-Test (@($script:FindingsList.Items | Where-Object { $_.Tag.Area -ne 'Network' }).Count -eq 0) 'Subject filter isolates Network findings'
    $script:StatusFilter.SelectedItem = 'WARN'
    Assert-Test (@($script:FindingsList.Items | Where-Object { $_.Tag.Status -ne 'WARN' }).Count -eq 0) 'Status filter isolates WARN findings'
    $script:StatusFilter.SelectedIndex = 0
    $script:SearchBox.Text = 'does-not-exist-in-any-finding'
    Assert-Test ($script:FindingsList.Items.Count -eq 0) 'Text search filters findings'
    $script:SearchBox.Clear()
    $script:Navigation.SelectedItem = 'Overview'
    Save-UiScreenshot 'overview-1280'
    $script:Form.Size = New-Object Drawing.Size(1060,740)
    foreach ($section in @('Overview','Timer','CPU','USB','Network','Display/GPU','Power/Game')) {
        $script:Navigation.SelectedItem = $section
        Save-UiScreenshot ($section.Replace('/','-') + '-1060')
        $splitControl = $script:FindingsList.Parent.Parent
        Assert-Test ($script:FindingsList.Height -ge 100 -and $script:DetailTabs.Height -ge 130) "$section keeps findings and details visible at minimum window size"
    }
    $script:Navigation.SelectedItem = 'Overview'
    if (-not $SkipScan) {
        $script:TimerSamplesBox.Value = 40
        Start-GuiScan -SkipNetwork
        $deadline = [DateTime]::UtcNow.AddSeconds(150)
        while ($script:IsRunning -and [DateTime]::UtcNow -lt $deadline) { [Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 100 }
        Assert-Test (-not $script:IsRunning -and $script:StatusLabel.Text -eq 'SCAN COMPLETE' -and -not $script:MeasurementsStale) 'Real Windows collector scan loads only a new verified report'
        Assert-Test ($script:ActionStatus.Text -like 'Verified:*' -and $script:ActionStatus.ForeColor.ToArgb() -eq (Get-StatusColor 'OK').ToArgb()) 'Verified scan feedback uses the success status color'
        Assert-Test ($script:LastReport.Findings.Count -gt 10 -and $script:LastJsonPath -and (Test-Path -LiteralPath $script:LastJsonPath)) 'Real report preserves diagnostics and export paths'
    }
    $script:Navigation.SelectedItem = 'Timer'
    Invoke-GuiAction 'Start holder for lifetime check' { Set-TimerHold $true }
    $script:Form.Close()
    Assert-Test ((Get-GsbTimerHolderState $testDirectory).Running) 'Closing the GUI leaves the independent holder running'
    [void](Stop-GsbTimerHolder $testDirectory)
    $results.Add([pscustomobject]@{ Test = 'Autostart after a real Windows sign-in'; Status = 'PENDING'; Reason = 'Manual Startup BAT execution is not a sign-out/sign-in test.' })
}
catch { $ErrorActionPreference = 'Stop'; throw }
finally {
    try { [void](Stop-GsbTimerHolder $testDirectory) } catch { Write-Warning $_.Exception.Message }
    if (Test-Path -LiteralPath (Join-Path $testDirectory 'Timer QA.bat')) { [void](Disable-GsbTimerAutostart $testDirectory (Join-Path $testDirectory 'Timer QA.bat')) }
    if ($null -ne (Get-Variable Form -Scope Script -ErrorAction SilentlyContinue)) { $script:Form.Dispose() }
    $results | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $EvidenceDirectory 'windows-tests.json') -Encoding UTF8
    Remove-Item -LiteralPath $testDirectory -Recurse -Force -ErrorAction SilentlyContinue
}
