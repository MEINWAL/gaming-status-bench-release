function New-GuiResult {
    param([string]$Message, [ValidateSet('Verified','Review','Reboot required','Cancelled')][string]$Status = 'Verified')
    [pscustomobject]@{ Status = $Status; Message = $Message }
}

function Confirm-GuiChange {
    param([string]$Title, [string]$Message)
    return [Windows.Forms.MessageBox]::Show($Message, $Title, 'YesNo', 'Warning') -eq [Windows.Forms.DialogResult]::Yes
}

function Set-VerifiedGuiClipboardText {
    param([string]$Text)
    [Windows.Forms.Clipboard]::SetText($Text)
    $deadline = [DateTime]::UtcNow.AddSeconds(1)
    do {
        $copied = [Windows.Forms.Clipboard]::GetText()
        if ($copied -ceq $Text) { return }
        [Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 20
    } while ([DateTime]::UtcNow -lt $deadline)
    throw 'Clipboard copy did not verify.'
}

function Set-GuiMeasurementsStale {
    $script:MeasurementsStale = $true
    Update-MeasurementStatus
    Update-CpuSolverButtons $script:LastReport
}

function Get-GuiRebootReceiptPaths {
    $paths = Get-GsbTimerPaths $script:TimerStateDirectory
    $userRoot = (Get-GsbTimerPaths (Join-Path $env:LOCALAPPDATA 'GamingStatusBench\Timer')).Root
    if (-not $paths.Machine -and $paths.Root -ne $userRoot) {
        return [pscustomobject]@{ Current=(Join-Path $paths.Root 'pending-reboot.json'); Legacy=@() }
    }
    [pscustomobject]@{
        Current = Join-Path $env:LOCALAPPDATA 'GamingStatusBench\Workspace\pending-reboot.json'
        Legacy = @((Join-Path $userRoot 'pending-reboot.json'),(Join-Path (Get-GsbMachineTimerPaths).Root 'pending-reboot.json'))
    }
}

function Load-GuiPendingReboot {
    $script:PendingReboot = $null; $script:RebootStateError = ''
    $paths = Get-GuiRebootReceiptPaths
    $pending = @(); $errors = @(); $boot = $null
    foreach ($path in @($paths.Current) + @($paths.Legacy)) {
        try {
            if (-not (Test-Path -LiteralPath $path -ErrorAction Stop)) { continue }
            $receipt = Get-Content -LiteralPath $path -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
            if (-not $receipt.Action -or -not $receipt.BootUtc) { throw 'Reboot receipt is incomplete.' }
            [void][DateTime]::Parse($receipt.BootUtc)
            if (-not $boot) { $boot = (Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).LastBootUpTime.ToUniversalTime().ToString('o') }
            if ($receipt.BootUtc -eq $boot) { $pending += $receipt }
            # Expired legacy receipts can be protected; ignoring them requires no write permission.
        }
        catch { $errors += "${path}: $($_.Exception.Message)" }
    }
    if ($pending.Count -gt 0) {
        $script:PendingReboot = [pscustomobject]@{Action=(@($pending.Action | Select-Object -Unique) -join '; ');BootUtc=$boot}
    }
    if ($errors.Count -gt 0) {
        $script:RebootStateError = $errors -join '; '
        Write-TerminalLog "Pending reboot state could not be fully verified: $script:RebootStateError" (Get-StatusColor 'WARN')
    }
}

function Save-GuiPendingReboot {
    param([string]$Action)
    $path = (Get-GuiRebootReceiptPaths).Current
    $script:PendingReboot = [pscustomobject]@{
        Action = $Action
        BootUtc = (Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).LastBootUpTime.ToUniversalTime().ToString('o')
        WrittenUtc = [DateTime]::UtcNow.ToString('o')
    }
    Update-MeasurementStatus
    New-Item -ItemType Directory -Path (Split-Path $path -Parent) -Force -ErrorAction Stop | Out-Null
    Write-GsbTimerJson $path $script:PendingReboot
}

function Invoke-GuiAction {
    param([string]$Name, [scriptblock]$Action)
    if ($script:IsRunning -or $script:IsBusy) { return }
    $script:IsBusy = $true
    $script:ActionStatus.Text = "Running: $Name"
    $script:ActionStatus.ForeColor = Get-StatusColor 'INFO'
    Update-ActionControls
    [Windows.Forms.Application]::DoEvents()
    Write-TerminalLog "Running: $Name" (Get-StatusColor 'INFO')
    try {
        $result = & $Action
        if ($null -eq $result -or $null -eq $result.PSObject.Properties['Status']) { throw 'Action returned no verifiable result.' }
        if ($result.Status -eq 'Reboot required') { Save-GuiPendingReboot $Name }
        $script:ActionStatus.Text = "$($result.Status): $($result.Message)"
        $status = if ($result.Status -eq 'Verified') { 'OK' } elseif ($result.Status -eq 'Cancelled') { 'INFO' } else { 'WARN' }
        $script:ActionStatus.ForeColor = Get-StatusColor $status
        Write-TerminalLog $script:ActionStatus.Text (Get-StatusColor $status)
    }
    catch {
        $script:ActionStatus.Text = "Failed: $Name. $($_.Exception.Message)"
        $script:ActionStatus.ForeColor = Get-StatusColor 'FAIL'
        Write-TerminalLog $script:ActionStatus.Text (Get-StatusColor 'FAIL')
    }
    finally {
        $script:IsBusy = $false
        if (-not $script:Form.IsDisposed) {
            if ($script:AdminRelaunched) { $script:Form.Close() }
            else {
                Update-LiveTimer
                Update-ActionControls
            }
        }
    }
}

function Invoke-GuiProcess {
    param([string]$FilePath, [string[]]$Arguments, [int]$TimeoutSeconds = 90)
    $psi = New-Object Diagnostics.ProcessStartInfo
    $psi.FileName = $FilePath
    $psi.Arguments = (($Arguments | ForEach-Object { Quote-Arg ([string]$_) }) -join ' ')
    $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true
    $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
    $process = [Diagnostics.Process]::Start($psi)
    try {
        # Drain both pipes concurrently, including while Windows tools are still running.
        $stdout = $process.StandardOutput.ReadToEndAsync()
        $stderr = $process.StandardError.ReadToEndAsync()
        $deadline = [DateTime]::UtcNow.AddSeconds($TimeoutSeconds)
        while (-not $process.WaitForExit(50)) {
            [Windows.Forms.Application]::DoEvents()
            if ([DateTime]::UtcNow -gt $deadline) { $process.Kill(); $process.WaitForExit(); throw "$FilePath timed out after ${TimeoutSeconds}s." }
        }
        $process.WaitForExit()
        $result = [pscustomobject]@{ ExitCode = $process.ExitCode; Output = $stdout.Result; Error = $stderr.Result }
        Write-TerminalLog "$FilePath $($psi.Arguments) -> exit $($result.ExitCode)" (Get-StatusColor 'INFO')
        foreach ($line in (($result.Output + "`n" + $result.Error) -split '\r?\n')) {
            if ($line.Trim()) { Write-TerminalLog $line (Get-StatusColor $(if ($result.ExitCode -eq 0) { 'INFO' } else { 'WARN' })) }
        }
        return $result
    }
    finally { $process.Dispose() }
}

function Invoke-CheckedGuiProcess {
    param([string]$FilePath, [string[]]$Arguments)
    $result = Invoke-GuiProcess $FilePath $Arguments
    if ($result.ExitCode -ne 0) { throw "$FilePath failed (exit $($result.ExitCode)). See Logs for details." }
    return $result.Output
}

function Apply-ProcessTimerPolicy {
    [void](Set-GsbProcessTimerPolicy)
    $script:ProcessTimerPolicyApplied = $true
    New-GuiResult 'GUI process policy verified. This does not change a game process.'
}

function Set-TimerHold {
    param([bool]$Enabled)
    if ($Enabled) {
        $result = Start-GsbTimerHolder -Target100ns ([uint32]$script:TimerTarget.Value) -StateDirectory $script:TimerStateDirectory
        Set-GuiMeasurementsStale
        $returned = $result.State.Returned100ns
        $measured = $result.State.Measured100ns
        if ($returned -ne $result.State.Requested100ns -or $measured -ne $result.State.Requested100ns) {
            return New-GuiResult "Holder running; request=$($result.State.Requested100ns), API=$returned, measured=$measured (100 ns). Target mismatch." 'Review'
        }
        return New-GuiResult "Holder running. Requested and measured $($result.State.RequestedMs.ToString('F4')) ms."
    }
    [void](Stop-GsbTimerHolder -StateDirectory $script:TimerStateDirectory)
    Set-GuiMeasurementsStale
    New-GuiResult 'Holder stopped; its timer request was released. Other processes may keep a fine resolution active.'
}

function Enable-GuiTimerAutostart {
    if ($script:StartupScopeBox.SelectedIndex -eq 1) {
        if (-not (Test-IsAdmin)) { throw 'Restart the GUI as administrator to configure machine startup.' }
        $legacy = @(Get-GsbLegacyTimerEntries)
        $legacyTasks = @(Get-GsbLegacyTimerTasks | Where-Object { $_.Enabled -or $_.State -eq 'Running' })
        $message = "Install a protected ProgramData timer holder and a SYSTEM scheduled task at boot/logon?`r`nTarget: $($script:TimerTarget.Value) (100 ns).`r`nThe current-user GSB Startup BAT will be backed up and removed. This does not make your desktop account permanently elevated."
        if ($legacy.Count) { $message += "`r`nRecognized legacy Run entries will also be backed up and removed:`r`n" + (($legacy | ForEach-Object { "$($_.Path) :: $($_.Name) = $($_.Command)" }) -join "`r`n") }
        if ($legacyTasks.Count) { $message += "`r`nRecognized legacy scheduled tasks will be backed up and disabled:`r`n" + (($legacyTasks | ForEach-Object { "$($_.TaskPath)$($_.TaskName) :: $($_.Arguments)" }) -join "`r`n") }
        if (-not (Confirm-GuiChange 'Configure machine timer startup' $message)) { return New-GuiResult 'Startup unchanged.' 'Cancelled' }
        $result = Enable-GsbMachineTimerAutostart -Target100ns ([uint32]$script:TimerTarget.Value) -ReplaceLegacy
        New-GuiResult "SYSTEM boot/logon task and protected scripts verified for $($result.Target100ns). Backup: $($result.BackupDirectory). Actual boot execution still needs verification."
        return
    }
    if (-not (Confirm-GuiChange 'Enable timer at sign-in' "Install readable timer scripts in LocalAppData and create a current-user Startup BAT?`r`n`r`nTarget: $($script:TimerTarget.Value) (100 ns). Starts at Windows sign-in, not before sign-in. The holder stays running independently of the GUI and may increase power use. This does not start the holder now.")) { return New-GuiResult 'Autostart unchanged.' 'Cancelled' }
    $directory = if ($script:TimerStateDirectory) { $script:TimerStateDirectory } else { Join-Path $env:LOCALAPPDATA 'GamingStatusBench\Timer' }
    if (-not $script:TimerStateDirectory -and (Get-GsbMachineTimerAutostart).Status -eq 'Enabled') { throw 'Disable machine startup before switching to a user Startup BAT.' }
    $result = Enable-GsbTimerAutostart -Target100ns ([uint32]$script:TimerTarget.Value) -StateDirectory $directory -StartupPath $script:StartupPath
    New-GuiResult "Startup BAT and installed scripts verified for target $($result.Target100ns). Next sign-in execution is not yet proven."
}

function Disable-GuiTimerAutostart {
    if ($script:StartupScopeBox.SelectedIndex -eq 1) {
        [void](Disable-GsbMachineTimerAutostart)
        return New-GuiResult 'Machine startup task disabled and verified. A running holder is not stopped by this action.'
    }
    [void](Disable-GsbTimerAutostart -StateDirectory $script:TimerStateDirectory -StartupPath $script:StartupPath)
    New-GuiResult 'Startup BAT removed and absence verified. A running holder is not stopped by this action.'
}

function Inspect-GuiTimerAutostart {
    $state = Get-GsbTimerAutostart -StateDirectory $script:TimerStateDirectory -StartupPath $script:StartupPath
    $paths = Get-GsbTimerPaths $script:TimerStateDirectory
    $script:TechnicalBox.Text = "Autostart: $($state.Status)`r`nTarget (100 ns): $($state.Target100ns)`r`nStartup entry: $($state.Path)`r`nConfiguration: $($paths.Config)`r`nHolder: $($paths.Holder)`r`nScope: $(if ($paths.Machine) { 'Machine / SYSTEM' } else { 'Current user' })`r`nError log: $($paths.ErrorLog)`r`n$($state.Error)"
    if (Test-Path -LiteralPath $state.Path) { $script:TechnicalBox.AppendText("`r`n`r`n" + [IO.File]::ReadAllText($state.Path)) }
    $script:TechnicalBox.AppendText("`r`n`r`nRecognized legacy Run entries:`r`n" + (@(Get-GsbLegacyTimerEntries) | ConvertTo-Json -Depth 5))
    if (Test-IsAdmin) { $script:TechnicalBox.AppendText("`r`n`r`nRecognized legacy scheduled tasks:`r`n" + (@(Get-GsbLegacyTimerTasks) | ConvertTo-Json -Depth 5)) }
    else { $script:TechnicalBox.AppendText("`r`n`r`nLegacy scheduled-task coverage is INCOMPLETE without elevation. Restart as admin to inspect protected machine tasks; missing rows do not prove absence.") }
    if (Test-Path -LiteralPath $paths.ErrorLog) { $script:TechnicalBox.AppendText("`r`n`r`nLast startup error:`r`n" + [IO.File]::ReadAllText($paths.ErrorLog)) }
    $script:DetailTabs.SelectedIndex = 1
    if ($state.Status -eq 'Invalid') { throw $state.Error }
    New-GuiResult "Autostart $($state.Status.ToLowerInvariant()); inspected in Technical details."
}

function Check-GuiTimerStartup {
    $script:StartupHealthLabel.Text='Startup check: running'
    $script:StartupHealthLabel.ForeColor=Get-StatusColor 'INFO'
    $script:SelectedFinding=$null
    $script:CommandBox.Clear()
    Update-ActionControls
    try {$diagnostics=Get-GsbTimerStartupDiagnostics -StateDirectory $script:TimerStateDirectory -StartupPath $script:StartupPath}
    catch {
        $script:StartupHealthLabel.Text='Startup check: UNKNOWN - check failed'
        $script:StartupHealthLabel.ForeColor=Get-StatusColor 'WARN'
        $script:DiagnosisBox.Text='Unverified: startup check failed. No startup or process changes were made.'
        $script:TechnicalBox.Text=$_.Exception.Message
        $script:DetailTabs.SelectedIndex=0
        throw
    }
    $script:StartupHealthLabel.Text="Last startup check: $($diagnostics.Status) | Coverage: $($diagnostics.Coverage.Status) | $($diagnostics.CheckedUtc)"
    $script:StartupHealthLabel.ForeColor=Get-StatusColor $diagnostics.Status
    $scope=Get-GsbDiagnosticProperty $diagnostics.Coverage 'Scope' 'Known timer launch signatures; machine and current user'
    $limits=@(Get-GsbDiagnosticProperty $diagnostics 'Limitations' @())
    $script:DiagnosisBox.Text=$diagnostics.Summary+"`r`nCoverage: $($diagnostics.Coverage.Status) | $scope`r`n`r`n"+ (($diagnostics.Issues | ForEach-Object {"$($_.Code): $($_.Value)`r`n$($_.Note)`r`n$($_.Action)"}) -join "`r`n`r`n")+"`r`n`r`n"+($limits -join "`r`n")
    $script:TechnicalBox.Text=$diagnostics | ConvertTo-Json -Depth 10
    $script:CommandBox.Text='Read-only diagnostic check. No startup or process changes were made.'
    $script:SelectedFinding=$null
    $script:DetailTabs.SelectedIndex=0
    New-GuiResult "$($diagnostics.Summary) Coverage: $($diagnostics.Coverage.Status). Nothing changed." $(if($diagnostics.Status -eq 'OK'){'Verified'}else{'Review'})
}

function Apply-GlobalTimerResolutionRequests {
    if (-not (Test-IsAdmin)) { throw 'Administrator rights are required.' }
    if (-not (Confirm-GuiChange 'Enable legacy global timer mode' "Write GlobalTimerResolutionRequests=1?`r`n`r`nOptional compatibility setting for older apps. Not a guaranteed gaming improvement. Requires a reboot and can increase power use.`r`nRevert: delete the GlobalTimerResolutionRequests registry value.")) { return New-GuiResult 'Legacy mode unchanged.' 'Cancelled' }
    Set-GuiMeasurementsStale
    [void](Invoke-CheckedGuiProcess 'reg.exe' @('add', 'HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel', '/v', 'GlobalTimerResolutionRequests', '/t', 'REG_DWORD', '/d', '1', '/f'))
    $value = Get-ItemPropertyValue -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\kernel' -Name GlobalTimerResolutionRequests -ErrorAction Stop
    if ($value -ne 1) { throw 'Global timer registry value did not verify.' }
    New-GuiResult 'Global timer registry value verified. Effective behavior needs reboot and retest.' 'Reboot required'
}

function Get-GuiBootConfiguration {
    return Invoke-CheckedGuiProcess 'bcdedit.exe' @('/enum', '{current}')
}

function Apply-BcdeditBaseline {
    if (-not (Test-IsAdmin)) { throw 'Administrator rights are required.' }
    $before = Get-GuiBootConfiguration
    if (-not (Confirm-GuiChange 'Apply timer boot baseline' "Disable dynamic tick and remove forced platform clock/tick overrides from {current}?`r`n`r`nRequires reboot. These settings are system-specific; no guaranteed FPS benefit. Current configuration will be recorded in Logs before changes.")) { return New-GuiResult 'Boot settings unchanged.' 'Cancelled' }
    Write-TerminalLog "BCD before changes:`r`n$before"
    Set-GuiMeasurementsStale
    [void](Invoke-CheckedGuiProcess 'bcdedit.exe' @('/set', '{current}', 'disabledynamictick', 'yes'))
    foreach ($name in @('useplatformclock', 'useplatformtick')) {
        if ($before -match "(?im)^\s*$name\s+\S+") { [void](Invoke-CheckedGuiProcess 'bcdedit.exe' @('/deletevalue', '{current}', $name)) }
    }
    $after = Get-GuiBootConfiguration
    if ($after -notmatch '(?im)^\s*disabledynamictick\s+(Yes|Ja|true|1)\s*$' -or $after -match '(?im)^\s*useplatform(clock|tick)\s+') { throw 'Timer boot configuration did not verify.' }
    New-GuiResult 'Boot configuration verified. Runtime behavior remains unverified until reboot and rescan.' 'Reboot required'
}

function Set-GuiCpuLimit {
    param([bool]$Remove)
    if (-not (Test-IsAdmin)) { throw 'Administrator rights are required.' }
    if ($script:MeasurementsStale -or $null -eq $script:LastReport) { throw 'A fresh scan is required before changing the processor limit.' }
    $property = if ($Remove) { 'RestoreAllowed' } else { 'Set16Allowed' }
    if ((Get-CpuSolverValue $script:LastReport $property) -ne $true) { throw 'This processor-limit action is not allowed by the current report.' }
    $before = Get-GuiBootConfiguration
    if ($Remove -and $before -notmatch '(?im)^\s*numproc\s+\d+\s*$') { throw 'The live boot configuration no longer has a processor limit. Rescan first.' }
    $command = if ($Remove) { 'bcdedit /deletevalue {current} numproc' } else { 'bcdedit /set {current} numproc 16' }
    if (-not (Confirm-GuiChange 'Change boot processor limit' "$command`r`n`r`nThis changes boot configuration, not BIOS SMT. Requires reboot.`r`n$(Get-CpuSolverStateText $script:LastReport)")) { return New-GuiResult 'Processor limit unchanged.' 'Cancelled' }
    Write-TerminalLog "BCD before changes:`r`n$before"
    Set-GuiMeasurementsStale
    $arguments = if ($Remove) { @('/deletevalue', '{current}', 'numproc') } else { @('/set', '{current}', 'numproc', '16') }
    [void](Invoke-CheckedGuiProcess 'bcdedit.exe' $arguments)
    $after = Get-GuiBootConfiguration
    if ($Remove -and $after -match '(?im)^\s*numproc\s+') { throw 'Processor limit removal did not verify.' }
    if (-not $Remove -and $after -notmatch '(?im)^\s*numproc\s+16\s*$') { throw 'Processor limit did not verify as 16.' }
    New-GuiResult 'Boot processor limit verified. Reboot and rescan to verify usable threads.' 'Reboot required'
}

function Set-GuiGameRegistry {
    param([bool]$CaptureOff)
    $name = if ($CaptureOff) { 'Disable capture and replay buffer' } else { 'Enable Game Mode' }
    $rows = if ($CaptureOff) {
        @(@('HKCU\System\GameConfigStore','GameDVR_Enabled',0), @('HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR','AppCaptureEnabled',0), @('HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR','HistoricalCaptureEnabled',0))
    } else { @(@('HKCU\Software\Microsoft\GameBar','AutoGameModeEnabled',1), @('HKCU\Software\Microsoft\GameBar','AllowAutoGameMode',1)) }
    $preview = ($rows | ForEach-Object { "$($_[0]) :: $($_[1])=$($_[2])" }) -join "`r`n"
    if (-not (Confirm-GuiChange $name "$preview`r`n`r`nChanges current-user settings. Restart the game before retesting.")) { return New-GuiResult 'Game settings unchanged.' 'Cancelled' }
    Set-GuiMeasurementsStale
    foreach ($row in $rows) {
        [void](Invoke-CheckedGuiProcess 'reg.exe' @('add', $row[0], '/v', $row[1], '/t', 'REG_DWORD', '/d', [string]$row[2], '/f'))
        $path = $row[0] -replace '^HKCU\\', 'HKCU:\'
        if ((Get-ItemPropertyValue -LiteralPath $path -Name $row[1] -ErrorAction Stop) -ne $row[2]) { throw "Game setting did not verify: $($row[1])" }
    }
    New-GuiResult 'Current-user game settings verified. Restart the game and rescan.'
}

function Copy-PowerShowAll {
    $output = Invoke-CheckedGuiProcess 'powercfg.exe' @('/qh','SCHEME_CURRENT')
    if (-not $output.Trim()) { throw 'Power plan query returned no output.' }
    Set-VerifiedGuiClipboardText $output
    New-GuiResult 'Full current power plan output copied to clipboard. No values changed.'
}

function Apply-PowerUnhideAll {
    if (-not (Test-IsAdmin)) { throw 'Administrator rights are required.' }
    $rows = @(Get-PowerSettingRegistryRows)
    if ($rows.Count -eq 0) { throw 'No readable power settings were found.' }
    if (-not (Confirm-GuiChange 'Unhide advanced power settings' "Expose $($rows.Count) Advanced Power Settings entries?`r`n`r`nOnly clears the hidden bit in Attributes. Does not change active AC/DC power values.")) { return New-GuiResult 'Power settings unchanged.' 'Cancelled' }
    Set-GuiMeasurementsStale
    $failed = @()
    foreach ($row in $rows) {
        try {
            $expected = $row.Attributes -band (-bnot 1)
            Set-ItemProperty -LiteralPath $row.Path -Name Attributes -Value $expected -ErrorAction Stop
            if ((Get-ItemPropertyValue -LiteralPath $row.Path -Name Attributes -ErrorAction Stop) -ne $expected) { throw 'Read-back mismatch.' }
        }
        catch { $failed += $row.SettingGuid; Write-TerminalLog "$($row.SettingGuid): $($_.Exception.Message)" (Get-StatusColor 'FAIL') }
        [Windows.Forms.Application]::DoEvents()
    }
    if ($failed.Count -gt 0) { throw "Power settings partially updated: $($failed.Count) failed read-back checks. See Logs." }
    New-GuiResult "$($rows.Count) power setting visibility flags verified. Active values unchanged."
}

function Apply-UsbPowerSavingOff {
    if (-not (Test-IsAdmin)) { throw 'Administrator rights are required.' }
    $rows = @(Get-UsbPowerSavingRows)
    if ($rows.Count -eq 0) { throw 'No matched USB entries were readable; device power state is unknown.' }
    $enabled = @($rows | Where-Object { $_.Enable })
    if ($enabled.Count -eq 0) { return New-GuiResult "$($rows.Count) matched USB entries already read as disabled. Unmatched devices are not covered." }
    if (-not (Confirm-GuiChange 'Disable matched USB power saving' "Change $($enabled.Count) enabled USB WMI/registry entries?`r`n`r`nMay increase idle power. Reconnect affected devices or reboot afterward; hardware behavior still needs testing.")) { return New-GuiResult 'USB settings unchanged.' 'Cancelled' }
    Set-GuiMeasurementsStale
    $failed = @()
    foreach ($row in $enabled) {
        try {
            if ($row.Backend -eq 'Registry') {
                Set-ItemProperty -LiteralPath $row.RegistryPath -Name $row.Name -Value $row.TargetValue -ErrorAction Stop
                if ((Get-ItemPropertyValue -LiteralPath $row.RegistryPath -Name $row.Name -ErrorAction Stop) -ne $row.TargetValue) { throw 'Registry read-back mismatch.' }
            } else {
                $row.PowerEntry.Enable = $false
                [void]$row.PowerEntry.psbase.Put()
                $row.PowerEntry.psbase.Get()
                if ($row.PowerEntry.Enable) { throw 'WMI read-back mismatch.' }
            }
        }
        catch { $failed += $row.InstanceName; Write-TerminalLog $_.Exception.Message (Get-StatusColor 'FAIL') }
        [Windows.Forms.Application]::DoEvents()
    }
    if ($failed.Count -gt 0) { throw "USB settings partially updated: $($failed.Count) entries failed verification." }
    New-GuiResult "$($enabled.Count) matched USB flags verified as disabled. Reconnect/reboot may be needed; no input-latency improvement is implied."
}

function Wait-GuiSeconds {
    param([int]$Seconds, [string]$Reason)
    $deadline = [DateTime]::UtcNow.AddSeconds($Seconds)
    while ([DateTime]::UtcNow -lt $deadline) {
        $script:ActionStatus.Text = "Running: $Reason ($([Math]::Ceiling(($deadline - [DateTime]::UtcNow).TotalSeconds))s)"
        [Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 100
    }
}

function Invoke-PreGameNetworkRefresh {
    if (-not (Confirm-GuiChange 'Refresh DHCP and DNS' "ipconfig /release -> wait 6s -> /renew -> wait 6s -> /flushdns`r`n`r`nBriefly disconnects DHCP adapters. Do not use during a game, download, or remote session. No guaranteed ping improvement.")) { return New-GuiResult 'Network unchanged.' 'Cancelled' }
    Set-GuiMeasurementsStale
    $releaseError = ''; $renewError = ''; $flushError = ''
    try { [void](Invoke-CheckedGuiProcess 'ipconfig.exe' @('/release')) } catch { $releaseError = $_.Exception.Message }
    # Always attempt renewal, even if release reported an error or timed out.
    Wait-GuiSeconds 6 'After DHCP release'
    try { [void](Invoke-CheckedGuiProcess 'ipconfig.exe' @('/renew')) } catch { $renewError = $_.Exception.Message }
    Wait-GuiSeconds 6 'After DHCP renewal'
    try { [void](Invoke-CheckedGuiProcess 'ipconfig.exe' @('/flushdns')) } catch { $flushError = $_.Exception.Message }
    if ($releaseError -or $renewError -or $flushError) { throw "Network refresh errors. Release: $releaseError Renew: $renewError Flush: $flushError" }
    $online = @(Get-NetIPConfiguration -ErrorAction Stop | Where-Object { $null -ne $_.IPv4DefaultGateway -and $null -ne $_.IPv4Address -and $_.IPv4Address.IPAddress -notmatch '^169\.254\.' })
    if ($online.Count -eq 0) { throw 'Commands completed, but no IPv4 address with a default gateway was verified. Check the adapter before gaming.' }
    New-GuiResult 'DHCP/DNS commands completed; IPv4 address and default gateway verified. Internet/game connectivity still needs testing.'
}
