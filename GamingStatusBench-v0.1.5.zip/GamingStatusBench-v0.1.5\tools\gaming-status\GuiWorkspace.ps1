$script:IsBusy = $false
$script:AdminRelaunched = $false
$script:MeasurementsStale = $false
$script:TimerStateDirectory = $TimerStateDirectory
$initialTimerPaths = Get-GsbTimerPaths $TimerStateDirectory
$defaultUserTimerRoot = (Get-GsbTimerPaths (Join-Path $env:LOCALAPPDATA 'GamingStatusBench\Timer')).Root
$script:TimerScopePinned = $initialTimerPaths.Root -ne $defaultUserTimerRoot -and -not $initialTimerPaths.Machine
$script:UserStartupPathOverride = $StartupPath
$script:StartupPath = if ($initialTimerPaths.Machine) { '' } else { $StartupPath }
$script:ActionButtons = New-Object 'System.Collections.Generic.List[object]'
$script:SectionPanels = @{}
$script:UpdatingAutostart = $false
$script:LiveTimerUnavailable = $false
$script:OtherTimerScopeBlocked = $true
$script:SelectedFinding = $null
$script:PendingReboot = $null
$script:RebootStateError = ''
$script:Colors = @{
    Background = [Drawing.Color]::FromArgb(24,24,27)
    Surface = [Drawing.Color]::FromArgb(32,32,36)
    Text = [Drawing.Color]::FromArgb(235,235,239)
    Muted = [Drawing.Color]::FromArgb(170,170,181)
    Border = [Drawing.Color]::FromArgb(76,76,85)
}

function New-WorkspaceTextBox {
    param([bool]$Multiline = $true)
    $box = New-Object Windows.Forms.TextBox
    $box.BackColor = $script:Colors.Background; $box.ForeColor = $script:Colors.Text
    $box.Multiline = $Multiline; $box.BorderStyle = 'FixedSingle'
    if ($Multiline) { $box.ScrollBars = 'Both'; $box.WordWrap = $false }
    return $box
}

function New-WorkspaceLabel {
    param([string]$Text)
    $label = New-Object Windows.Forms.Label
    $label.Text = $Text; $label.AutoSize = $true
    $label.Margin = New-Object Windows.Forms.Padding(6,3,8,3)
    $label.ForeColor = $script:Colors.Text
    return $label
}

function Format-GuiMeasurement {
    param([object]$Value, [string]$Unit = '')
    if ($null -eq $Value -or [string]$Value -eq '') { return 'unknown' }
    if ($Unit) { return "$Value $Unit" }
    return [string]$Value
}

function New-ActionRow {
    $row = New-Object Windows.Forms.FlowLayoutPanel
    $row.Dock = 'Top'; $row.AutoSize = $true; $row.WrapContents = $true
    $row.AutoSizeMode = 'GrowAndShrink'; $row.Padding = New-Object Windows.Forms.Padding(0,2,0,2)
    return $row
}

function New-ActionButton {
    param([string]$Text, [scriptblock]$Action, [string]$Hint = '', [bool]$Admin = $false, [string]$Gate = '')
    $button = New-Object Windows.Forms.Button
    $button.Text = $Text; $button.AutoSize = $true; $button.AutoSizeMode = 'GrowAndShrink'
    $button.MinimumSize = New-Object Drawing.Size(90,32)
    $button.Padding = New-Object Windows.Forms.Padding(8,3,8,3)
    $button.Margin = New-Object Windows.Forms.Padding(4,2,4,2)
    $button.FlatStyle = 'Flat'; $button.FlatAppearance.BorderColor = $script:Colors.Border
    $button.BackColor = $script:Colors.Surface; $button.ForeColor = $script:Colors.Text
    $button.Tag = [pscustomobject]@{ Action = $Action; Admin = $Admin; Gate = $Gate; Name = $Text }
    $script:ToolTips.SetToolTip($button, $Hint)
    $button.Add_Click({
        param($sender,$e)
        if ($sender.Tag.Gate -eq 'Scan') { & $sender.Tag.Action }
        else { Invoke-GuiAction $sender.Tag.Name $sender.Tag.Action }
    })
    $button.Add_Paint({
        param($sender,$e)
        if (-not $sender.Enabled) {
            $brush = New-Object Drawing.SolidBrush($sender.BackColor)
            try { $e.Graphics.FillRectangle($brush,$sender.ClientRectangle) } finally { $brush.Dispose() }
            [Windows.Forms.ControlPaint]::DrawBorder($e.Graphics,$sender.ClientRectangle,$script:Colors.Border,[Windows.Forms.ButtonBorderStyle]::Solid)
            [Windows.Forms.TextRenderer]::DrawText($e.Graphics,$sender.Text,$sender.Font,$sender.ClientRectangle,$script:Colors.Muted,([Windows.Forms.TextFormatFlags]::HorizontalCenter -bor [Windows.Forms.TextFormatFlags]::VerticalCenter))
        }
    })
    $script:ActionButtons.Add($button)
    return $button
}

function Update-CpuSolverButtons {
    param([object]$Report)
    if ($null -eq $script:CpuSet16Button) { return }
    $ready = (Test-IsAdmin) -and -not $script:IsRunning -and -not $script:IsBusy -and -not $script:MeasurementsStale
    $script:CpuSet16Button.Enabled = $ready -and (Get-CpuSolverValue $Report 'Set16Allowed') -eq $true
    $script:CpuRestoreButton.Enabled = $ready -and (Get-CpuSolverValue $Report 'RestoreAllowed') -eq $true
}

function Update-ActionControls {
    $ready = -not $script:IsRunning -and -not $script:IsBusy
    $script:GuiPrivilegeLabel.Text = if (Test-IsAdmin) { 'GUI: Admin' } else { 'GUI: Standard user' }
    $machine = (Get-GsbTimerPaths $script:TimerStateDirectory).Machine
    foreach ($button in $script:ActionButtons) {
        $button.Enabled = $ready -and (-not $button.Tag.Admin -or (Test-IsAdmin))
        switch ($button.Tag.Gate) {
            'Report' { $button.Enabled = $button.Enabled -and $null -ne $script:LastReport }
            'SelectedCommands' { $button.Enabled = $button.Enabled -and @(Get-FindingCommands $script:SelectedFinding).Count -gt 0 }
            'HolderStart' { $button.Enabled = $button.Enabled -and -not $script:LiveTimerUnavailable -and -not $script:TimerHoldActive -and -not $script:OtherTimerScopeBlocked -and (-not $machine -or (Test-IsAdmin)) }
            'HolderStop' { $button.Enabled = $button.Enabled -and -not $script:LiveTimerUnavailable -and ($script:TimerHoldActive -or $script:HolderError) -and (-not $machine -or (Test-IsAdmin)) }
            'Html' { $button.Enabled = $button.Enabled -and $script:LastHtmlPath -and (Test-Path -LiteralPath $script:LastHtmlPath) }
            'Json' { $button.Enabled = $button.Enabled -and $script:LastJsonPath -and (Test-Path -LiteralPath $script:LastJsonPath) }
            'StartupConfigure' { $button.Enabled = $button.Enabled -and ($script:StartupScopeBox.SelectedIndex -eq 1 -and (Test-IsAdmin) -or $script:StartupScopeBox.SelectedIndex -eq 0 -and -not $script:OtherTimerScopeBlocked) }
        }
        if ($button.Tag.Gate -like 'Commands:*') {
            $section = $button.Tag.Gate.Substring('Commands:'.Length)
            $commands = @(foreach ($finding in @(Get-SectionFindings $section)) { Get-FindingCommands $finding })
            $button.Enabled = $button.Enabled -and $commands.Count -gt 0
        }
    }
    $script:RunButton.Enabled = $ready
    $script:TimerTarget.Enabled = $ready -and -not $script:LiveTimerUnavailable -and -not $script:TimerHoldActive
    $script:AutostartCheck.Enabled = $ready -and ($script:StartupScopeBox.SelectedIndex -eq 0 -or (Test-IsAdmin))
    if ($script:StartupScopeBox.SelectedIndex -eq 0 -and $script:OtherTimerScopeBlocked -and $script:AutostartCheck.CheckState -eq 'Unchecked') { $script:AutostartCheck.Enabled = $false }
    $script:StartupScopeBox.Enabled = $ready -and -not $script:TimerScopePinned
    Update-CpuSolverButtons $script:LastReport
}

function Set-ScanControlsEnabled {
    param([bool]$Enabled)
    foreach ($control in @($script:GameExeBox,$script:PingTargetBox,$script:GamePingProfileBox,$script:PingCountBox,$script:TimerSamplesBox,$script:NetworkBox)) { $control.Enabled = $Enabled }
    Update-ActionControls
}

function Update-MeasurementStatus {
    if ($null -eq $script:LastReport) {
        $script:MeasurementStatus.Text = 'Measurements: no scan loaded'
    }
    else {
        $stamp = Get-JsonValue $script:LastReport @('Host','TimestampLocal')
        $state = if ($script:MeasurementsStale) { 'STALE - rescan needed' } else { 'last scan' }
        $script:MeasurementStatus.Text = "Measurements: $state | $stamp"
    }
    if ($script:PendingReboot) { $script:MeasurementStatus.Text += " | REBOOT REQUIRED: $($script:PendingReboot.Action)" }
    if ($script:RebootStateError) { $script:MeasurementStatus.Text += ' | REBOOT STATE UNVERIFIED (see Logs)' }
    $script:MeasurementStatus.ForeColor = Get-StatusColor $(if ($script:MeasurementsStale -or $script:PendingReboot -or $script:RebootStateError) { 'WARN' } else { 'INFO' })
    $script:ToolTips.SetToolTip($script:MeasurementStatus,$script:MeasurementStatus.Text)
}

function Get-SectionFindings {
    param([string]$Section)
    $all = @(Get-ObjectsWithProperty (Get-JsonValue $script:LastReport @('Findings')) 'Area')
    switch ($Section) {
        'Overview' { return $all }
        'Timer' { return @($all | Where-Object { $_.Area -in @('Timer','Kernel') }) }
        'CPU' { return @($all | Where-Object { $_.Area -eq 'CPU' }) }
        'USB' { return @($all | Where-Object { $_.Name -like '*USB*' }) }
        'Network' { return @($all | Where-Object { $_.Area -eq 'Network' }) }
        'Display/GPU' { return @($all | Where-Object { $_.Area -eq 'Display/GPU' }) }
        'Power/Game' { return @($all | Where-Object { $_.Area -in @('Power','Fullscreen/Game','Overlays','Security') -and $_.Name -notlike '*USB*' }) }
        default { return @() }
    }
}

function Get-FindingCommands {
    param([object]$Finding)
    $commands = Get-JsonValue $Finding @('FixCommands')
    foreach ($command in @($commands)) {
        if ($command -isnot [string] -or -not $command.Trim()) { continue }
        if ($command -match '(?i)bcdedit\s+/set\s+.*numproc\s+16' -and ((Get-CpuSolverValue $script:LastReport 'Set16Allowed') -ne $true -or $script:MeasurementsStale)) { continue }
        $command
    }
}

function Show-FindingDetails {
    param([object]$Finding)
    $script:SelectedFinding = $Finding
    if ($null -eq $Finding) {
        $script:DiagnosisBox.Clear(); $script:CommandBox.Clear()
        $section = [string]$script:Navigation.SelectedItem
        $path = switch ($section) { 'Timer' { 'Timer' } 'CPU' { 'CpuScheduler' } 'USB' { 'Power' } 'Network' { 'Network' } 'Display/GPU' { 'DisplayGpu' } 'Power/Game' { 'Power' } default { '' } }
        $data = if ($path) { Get-JsonValue $script:LastReport @('Sections',$path) } else { Get-JsonValue $script:LastReport @('Analysis','DiagnosisGuide') }
        $script:TechnicalBox.Text = if ($null -ne $data) { $data | ConvertTo-Json -Depth 30 } else { 'No technical measurements loaded.' }
        Update-ActionControls
        return
    }
    $script:DiagnosisBox.Text = @(
        "$($Finding.Name) | $($Finding.Status) | $($Finding.Decision)",
        "Measured: $($Finding.Value)", "Expected: $($Finding.Expected)", '',
        "Diagnosis: $($Finding.Note)", '', "Recommendation: $($Finding.Action)", '',
        "Fix summary: $(Get-JsonValue $Finding @('FixSummary'))",
        "Fix steps: $(@(Get-JsonValue $Finding @('FixSteps')) -join ' -> ')", '',
        "Risk: $($Finding.Risk)", "Admin required: $($Finding.RequiresAdmin) | Reboot required: $($Finding.RequiresReboot)"
    ) -join "`r`n"
    $script:TechnicalBox.Text = $Finding | ConvertTo-Json -Depth 30
    $commands = @(Get-FindingCommands $Finding)
    $script:CommandBox.Text = if ($commands.Count -gt 0) { $commands -join "`r`n`r`n" } else { 'No runnable commands for this finding.' }
    Update-ActionControls
}

function Copy-SelectedCommands {
    $commands = @(Get-FindingCommands $script:SelectedFinding)
    if ($commands.Count -eq 0) { throw 'No commands are available for the selected finding.' }
    $text = $commands -join "`r`n"
    Set-VerifiedGuiClipboardText $text
    New-GuiResult 'Selected commands copied. Nothing executed.'
}

function Copy-SectionCommands {
    param([string]$Section)
    $lines = @()
    foreach ($finding in @(Get-SectionFindings $Section)) {
        $commands = @(Get-FindingCommands $finding)
        if ($commands.Count -eq 0) { continue }
        $lines += "# $($finding.Name) | Admin=$($finding.RequiresAdmin) | Reboot=$($finding.RequiresReboot)"
        $lines += $commands
        $lines += ''
    }
    if ($lines.Count -eq 0) { throw 'No commands are available. Run a scan first.' }
    $text = $lines -join "`r`n"
    $script:CommandBox.Text = $text; $script:DetailTabs.SelectedIndex = 2
    Set-VerifiedGuiClipboardText $text
    New-GuiResult "$Section commands copied for review. Nothing executed."
}

function Update-FindingsFilter {
    $section = [string]$script:Navigation.SelectedItem
    $status = [string]$script:StatusFilter.SelectedItem
    $text = $script:SearchBox.Text.Trim()
    $script:FindingsList.BeginUpdate()
    try {
        $script:FindingsList.Items.Clear()
        foreach ($finding in @(Get-SectionFindings $section | Sort-Object Priority,Status,Area,Name)) {
            if ($null -eq $finding) { continue }
            if ($status -ne 'All statuses' -and $finding.Status -ne $status) { continue }
            if ($text -and ("$($finding.Name) $($finding.Value) $($finding.Note)".IndexOf($text,[StringComparison]::OrdinalIgnoreCase) -lt 0)) { continue }
            $item = New-Object Windows.Forms.ListViewItem([string]$finding.Status)
            foreach ($value in @($finding.Area,$finding.Name,$finding.Value,$finding.Decision)) { [void]$item.SubItems.Add([string]$value) }
            $item.ForeColor = Get-StatusColor $finding.Status; $item.Tag = $finding
            [void]$script:FindingsList.Items.Add($item)
        }
    }
    finally { $script:FindingsList.EndUpdate() }
    $script:FindingCount.Text = "$($script:FindingsList.Items.Count) findings"
    Show-FindingDetails $null
    if ($script:FindingsList.Items.Count -gt 0) { $script:FindingsList.Items[0].Selected = $true }
}

function Update-CpuStateLabel {
    $script:CpuStateLabel.Text = "CPU threads: $(Format-GuiMeasurement (Get-CpuSolverValue $script:LastReport 'VisibleLogicalProcessors')) visible / $(Format-GuiMeasurement (Get-CpuSolverValue $script:LastReport 'ExpectedLogicalProcessors')) expected | SMT: $(Format-GuiMeasurement (Get-CpuSolverValue $script:LastReport 'SmtState')) | numproc: $(Format-GuiMeasurement (Get-CpuSolverValue $script:LastReport 'BcdNumProc'))"
}

function Update-SectionLayout {
    $section = [string]$script:Navigation.SelectedItem
    if (-not $script:SectionPanels.ContainsKey($section)) { return }
    $panel = $script:SectionPanels[$section]
    $panel.PerformLayout()
    $height = ($panel.GetRowHeights() | Measure-Object -Sum).Sum + 6
    $maximum = [Math]::Max(140, $script:Workspace.ClientSize.Height - 300)
    $script:DiagnosticLayout.RowStyles[0].Height = [Math]::Min($height, $maximum)
    $script:ActionHost.AutoScrollMinSize = New-Object Drawing.Size(0,([Math]::Max(0,$height-6)))
}

function Update-ReportView {
    param([object]$Report, [bool]$FreshScan = $true)
    $script:LastReport = $Report; $script:MeasurementsStale = -not $FreshScan
    $findings = @(Get-JsonValue $Report @('Findings'))
    foreach ($entry in @(@('OK',$script:OkLabel),@('WARN',$script:WarnLabel),@('FAIL',$script:FailLabel),@('INFO',$script:InfoLabel),@('UNKNOWN',$script:UnknownLabel))) {
        $count = @($findings | Where-Object { $_.Status -eq $entry[0] }).Count
        Set-SummaryLabel $entry[1] "$($entry[0]) $count" $entry[0]
    }
    $script:HostLabel.Text = "$(Get-JsonValue $Report @('Host','ComputerName')) | Scan elevated: $(Get-JsonValue $Report @('Host','IsAdmin')) | $(Get-JsonValue $Report @('Host','OS'))"
    $timer = Get-JsonValue $Report @('Sections','Timer','NtQueryTimerResolution','CurrentMs')
    $sleep = Get-JsonValue $Report @('Sections','Timer','SleepJitter','P95Ms')
    $wait = Get-JsonValue $Report @('Sections','Timer','HighResolutionWaitableTimer','P95Ms')
    $script:TimerLabel.Text = "Last scan: reported $(Format-GuiMeasurement $timer 'ms') | Sleep(1) p95 $(Format-GuiMeasurement $sleep 'ms') | waitable p95 $(Format-GuiMeasurement $wait 'ms')"
    $gpus = @(Get-ObjectsWithProperty (Get-JsonValue $Report @('Sections','DisplayGpu','ActiveDisplayModes')) 'DisplayMode')
    $script:DisplayLabel.Text = if ($gpus.Count -gt 0) { ($gpus | ForEach-Object { "$($_.Name): $($_.DisplayMode)" }) -join ' | ' } else { 'Active display mode: unknown (not a failed GPU)' }
    $pings = @(Get-ObjectsWithProperty (Get-JsonValue $Report @('Sections','Network','Ping')) 'Target' | Where-Object { $_.Received -gt 0 })
    $script:NetworkLabel.Text = if ($pings.Count -gt 0) { ($pings | ForEach-Object { "$($_.Target): $($_.AvgMs) ms, $($_.LossPct)% loss" }) -join ' | ' } else { 'Network: skipped or no replies; latency unknown' }
    $script:OverviewVerdict.Text = "Report verdict: $(Format-GuiMeasurement (Get-JsonValue $Report @('Analysis','ActionGuide','Summary','Verdict')))"
    $script:OverviewTimer.Text = $script:TimerLabel.Text
    $script:OverviewDisplay.Text = $script:DisplayLabel.Text
    $script:DetailsBox.Text = $Report | ConvertTo-Json -Depth 40
    $script:LastJsonPath = Get-JsonValue $Report @('Paths','Json'); $script:LastHtmlPath = Get-JsonValue $Report @('Paths','Html')
    $startup=Get-JsonValue $Report @('Sections','Timer','StartupDiagnostics')
    $script:StartupHealthLabel.Text=if($null -ne $startup){"Last scan startup check: $($startup.Status) | Coverage: $($startup.Coverage.Status) | $($startup.CheckedUtc)"}else{'Startup check: not included in loaded report'}
    $script:StartupHealthLabel.ForeColor=Get-StatusColor $(if($null -ne $startup){$startup.Status}else{'INFO'})
    Update-MeasurementStatus
    Update-CpuStateLabel
    Update-FindingsFilter
    Update-ActionControls
}

function Update-OtherTimerScope {
    $paths = Get-GsbTimerPaths $script:TimerStateDirectory
    $userPaths = Get-GsbTimerPaths (Join-Path $env:LOCALAPPDATA 'GamingStatusBench\Timer')
    $script:OtherTimerScopeBlocked = $false
    $status = 'INFO'
    if (-not $paths.Machine -and $paths.Root -ne $userPaths.Root) {
        $text = 'Other GSB scope: custom holder directory; managed-scope guard does not apply.'
    }
    else {
        $other = if ($paths.Machine) { $userPaths.Root } else { (Get-GsbMachineTimerPaths).Root }
        $scope = if ($paths.Machine) { 'current user' } else { 'machine / SYSTEM' }
        try {
            $auto = Get-GsbTimerAutostart -StateDirectory $other
            $holder = Get-GsbTimerHolderState -StateDirectory $other
            if ($auto.Status -notin @('Enabled','Disabled') -or $auto.Error -or $holder.Error) {
                throw "Startup: $($auto.Status). $($auto.Error) $($holder.Error)"
            }
            $script:OtherTimerScopeBlocked = $auto.Status -eq 'Enabled' -or $holder.Running
            if ($script:OtherTimerScopeBlocked) {
                $status = 'WARN'
                $text = "CONFLICT: GSB $scope startup or holder is active. Disable its startup and stop its holder before starting here."
            }
            else { $text = "Other GSB scope ($scope): no enabled startup or running holder found." }
        }
        catch {
            $script:OtherTimerScopeBlocked = $true
            $status = 'WARN'
            $text = "UNVERIFIED: GSB $scope state could not be verified; starting here is blocked. $($_.Exception.Message)"
        }
    }
    $script:OtherTimerScopeLabel.Text = $text
    $script:OtherTimerScopeLabel.ForeColor = Get-StatusColor $status
    $script:ToolTips.SetToolTip($script:OtherTimerScopeLabel,$text)
}

function Update-LiveTimer {
    try {
        $query = Get-GsbTimerResolution
        $holder = Get-GsbTimerHolderState $script:TimerStateDirectory
        $script:TimerHoldActive = $holder.Running
        $script:HolderError = $holder.Error
        $requested = if ($holder.Running) { "$($holder.State.Requested100ns) / $($holder.State.RequestedMs.ToString('F4')) ms" } else { 'none' }
        $api = if ($holder.Running) { "$($holder.State.Returned100ns) (100 ns)" } else { 'none' }
        $mismatch = $holder.Running -and ($holder.State.Requested100ns -ne $query.Current100ns -or $holder.State.Requested100ns -ne $holder.State.Returned100ns)
        $script:TimerLiveLabel.Text = "LIVE measured: $($query.Current100ns) / $($query.CurrentMs.ToString('F4')) ms | Supported: $($query.Lowest100ns)-$($query.Highest100ns) (100 ns)"
        $scope = if ((Get-GsbTimerPaths $script:TimerStateDirectory).Machine) { 'Machine / SYSTEM' } else { 'Current user' }
        $script:HolderLabel.Text = "Holder: $(if ($holder.Running) { 'Running, PID ' + $holder.State.ProcessId } elseif ($holder.Error) { 'Unverified' } else { 'Stopped' }) | $scope | Requested: $requested | API returned: $api"
        $script:TimerMatchLabel.Text = if ($holder.Error) { "UNVERIFIED: $($holder.Error)" } elseif ($mismatch) { 'MISMATCH: measured/API resolution differs from the request.' } elseif ($holder.Running) { 'MATCH: requested, API-returned and measured resolution agree.' } else { 'No holder request active. Measured resolution may be held by another process.' }
        $script:TimerMatchLabel.ForeColor = Get-StatusColor $(if ($holder.Error -or $mismatch) { 'WARN' } elseif ($holder.Running) { 'OK' } else { 'INFO' })
        $auto = Get-GsbTimerAutostart -StateDirectory $script:TimerStateDirectory -StartupPath $script:StartupPath
        $script:UpdatingAutostart = $true
        try {
            $script:AutostartCheck.CheckState = switch ($auto.Status) { 'Enabled' { 'Checked' } 'Invalid' { 'Indeterminate' } default { 'Unchecked' } }
        } finally { $script:UpdatingAutostart = $false }
        $script:AutostartLabel.Text = "Startup: $($auto.Status) | $scope$(if ($auto.Target100ns) { ' | Target: ' + $auto.Target100ns })$(if ($auto.Error) { ' | ' + $auto.Error })"
        $script:AutostartLabel.ForeColor = Get-StatusColor $(if ($auto.Status -eq 'Invalid') { 'WARN' } else { 'INFO' })
        $script:LiveTimerUnavailable = $false
    }
    catch {
        $script:LiveTimerUnavailable = $true
        $script:HolderError = $_.Exception.Message
        $script:TimerLiveLabel.Text = 'LIVE measured: unavailable'
        $script:HolderLabel.Text = 'Holder: unverified | Requested: unknown | API returned: unknown'
        $script:TimerMatchLabel.Text = "UNVERIFIED: live timer state unavailable. $script:HolderError"
        $script:TimerMatchLabel.ForeColor = Get-StatusColor 'WARN'
        $script:UpdatingAutostart = $true
        try { $script:AutostartCheck.CheckState = 'Indeterminate' }
        finally { $script:UpdatingAutostart = $false }
        $script:AutostartLabel.Text = 'Startup: unverified - inspect autostart for details'
        $script:AutostartLabel.ForeColor = Get-StatusColor 'WARN'
    }
    Update-OtherTimerScope
    Update-ActionControls
}

function Open-GuiSettings {
    param([string]$Uri)
    Start-Process $Uri -ErrorAction Stop
    New-GuiResult 'Windows settings launch requested. No setting was changed by the app.' 'Review'
}

function Open-GuiPath {
    param([string]$Path)
    if (-not $Path -or -not (Test-Path -LiteralPath $Path)) { throw 'The requested file or directory does not exist.' }
    Start-Process $Path -ErrorAction Stop
    New-GuiResult 'File opening requested. No system settings changed.' 'Review'
}

$script:Form = New-Object Windows.Forms.Form
$script:Form.Text = 'Gaming Status Bench'
$script:Form.StartPosition = 'CenterScreen'; $script:Form.MinimumSize = New-Object Drawing.Size(1060,740)
$script:Form.Size = New-Object Drawing.Size(1280,900)
$script:Form.Font = New-Object Drawing.Font('Segoe UI',9)
$script:Form.BackColor = $script:Colors.Background; $script:Form.ForeColor = $script:Colors.Text
$script:Form.AutoScaleMode = 'Dpi'
$script:ToolTips = New-Object Windows.Forms.ToolTip
$script:ToolTips.AutoPopDelay = 15000

$root = New-Object Windows.Forms.TableLayoutPanel
$root.Dock = 'Fill'; $root.ColumnCount = 1; $root.RowCount = 5
foreach ($height in @(48,30,26,50)) { [void]$root.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',$height))) }
[void]$root.RowStyles.Add((New-Object Windows.Forms.RowStyle('Percent',100)))
$script:Form.Controls.Add($root)
$toolbar = New-ActionRow
$root.Controls.Add($toolbar,0,0)
$brand = New-WorkspaceLabel 'Gaming Status Bench'
$brand.Font = New-Object Drawing.Font('Segoe UI',13,[Drawing.FontStyle]::Bold)
$toolbar.Controls.Add($brand)
$script:RunButton = New-ActionButton 'Run scan' { Start-GuiScan } '' $false 'Scan'
$toolbar.Controls.Add($script:RunButton)
$settingsButton = New-ActionButton 'Scan settings...' { [void]$script:SettingsDialog.ShowDialog($script:Form); New-GuiResult 'Scan settings selected. No system settings changed.' }
$toolbar.Controls.Add($settingsButton)
$script:AdminButton = New-ActionButton 'Restart as admin' { Restart-AsAdmin } 'Windows UAC confirmation is required. This does not elevate a running holder.'
$toolbar.Controls.Add($script:AdminButton)
$script:GuiPrivilegeLabel = New-WorkspaceLabel 'GUI: privilege pending'
$script:GuiPrivilegeLabel.AutoSize = $false; $script:GuiPrivilegeLabel.Size = New-Object Drawing.Size(154,32)
$script:GuiPrivilegeLabel.TextAlign = 'MiddleLeft'
$toolbar.Controls.Add($script:GuiPrivilegeLabel)
$script:ToolTips.SetToolTip($script:GuiPrivilegeLabel,'Current GUI process privileges. Loaded reports have their own scan-elevation value.')
$script:StatusLabel = New-WorkspaceLabel 'READY'
$toolbar.Controls.Add($script:StatusLabel)
$script:HostLabel = New-WorkspaceLabel "Current GUI elevated: $(Test-IsAdmin)"
$script:HostLabel.Dock = 'Fill'; $script:HostLabel.AutoEllipsis = $true
$root.Controls.Add($script:HostLabel,0,1)
$script:MeasurementStatus = New-WorkspaceLabel 'Measurements: no scan loaded'
$script:MeasurementStatus.Dock = 'Fill'; $script:MeasurementStatus.AutoSize = $false; $script:MeasurementStatus.AutoEllipsis = $true
$script:MeasurementStatus.Margin = New-Object Windows.Forms.Padding(8,0,8,0)
$root.Controls.Add($script:MeasurementStatus,0,2)
$script:ActionStatus = New-WorkspaceLabel 'Actions: idle'
$script:ActionStatus.Dock = 'Fill'; $script:ActionStatus.AutoSize = $false; $script:ActionStatus.AutoEllipsis = $true
$root.Controls.Add($script:ActionStatus,0,3)

$body = New-Object Windows.Forms.TableLayoutPanel
$body.Dock = 'Fill'; $body.ColumnCount = 2
[void]$body.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Absolute',172)))
[void]$body.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Percent',100)))
$root.Controls.Add($body,0,4)
$script:Navigation = New-Object Windows.Forms.ListBox
$script:Navigation.Dock = 'Fill'; $script:Navigation.BorderStyle = 'None'; $script:Navigation.IntegralHeight = $false
$script:Navigation.BackColor = $script:Colors.Surface; $script:Navigation.ForeColor = $script:Colors.Text
$script:Navigation.Font = New-Object Drawing.Font('Segoe UI',11)
$script:Navigation.ItemHeight = 36
foreach ($name in @('Overview','Timer','CPU','USB','Network','Display/GPU','Power/Game','Logs','Report JSON')) { [void]$script:Navigation.Items.Add($name) }
$body.Controls.Add($script:Navigation,0,0)
$script:Workspace = New-Object Windows.Forms.Panel
$script:Workspace.Dock = 'Fill'; $script:Workspace.Padding = New-Object Windows.Forms.Padding(8)
$body.Controls.Add($script:Workspace,1,0)
$script:DiagnosticLayout = New-Object Windows.Forms.TableLayoutPanel
$script:DiagnosticLayout.Dock = 'Fill'; $script:DiagnosticLayout.ColumnCount = 1; $script:DiagnosticLayout.RowCount = 3
[void]$script:DiagnosticLayout.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Percent',100)))
[void]$script:DiagnosticLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',80)))
[void]$script:DiagnosticLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',42)))
[void]$script:DiagnosticLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Percent',100)))
$script:Workspace.Controls.Add($script:DiagnosticLayout)
$script:ActionHost = New-Object Windows.Forms.Panel
$script:ActionHost.Dock = 'Fill'; $script:ActionHost.AutoScroll = $true
$script:DiagnosticLayout.Controls.Add($script:ActionHost,0,0)

$filters = New-ActionRow
$script:DiagnosticLayout.Controls.Add($filters,0,1)
$script:StatusFilter = New-Object Windows.Forms.ComboBox
$script:StatusFilter.DropDownStyle = 'DropDownList'; $script:StatusFilter.Width = 128
$script:StatusFilter.Margin = New-Object Windows.Forms.Padding(4,6,8,4)
$script:StatusFilter.Items.AddRange(@('All statuses','OK','WARN','FAIL','INFO','UNKNOWN')); $script:StatusFilter.SelectedIndex = 0
$filters.Controls.Add($script:StatusFilter)
$filters.Controls.Add((New-WorkspaceLabel 'Search'))
$script:SearchBox = New-WorkspaceTextBox $false
$script:SearchBox.Width = 220; $script:SearchBox.Margin = New-Object Windows.Forms.Padding(4,6,8,4)
$filters.Controls.Add($script:SearchBox)
$script:FindingCount = New-WorkspaceLabel '0 findings'; $filters.Controls.Add($script:FindingCount)

$split = New-Object Windows.Forms.SplitContainer
$split.Dock = 'Fill'; $split.Orientation = 'Horizontal'
$split.Size = New-Object Drawing.Size(900,460); $split.SplitterDistance = 240
$split.Panel1MinSize = 100; $split.Panel2MinSize = 130
$script:DiagnosticLayout.Controls.Add($split,0,2)
$script:FindingsList = New-Object Windows.Forms.ListView
$script:FindingsList.Dock = 'Fill'; $script:FindingsList.View = 'Details'
$script:FindingsList.FullRowSelect = $true; $script:FindingsList.MultiSelect = $false; $script:FindingsList.HideSelection = $false
$script:FindingsList.BackColor = $script:Colors.Background; $script:FindingsList.ForeColor = $script:Colors.Text
foreach ($column in @(@('Status',80),@('Area',126),@('Finding',280),@('Measured value',225),@('Decision',106))) { [void]$script:FindingsList.Columns.Add($column[0],$column[1]) }
$split.Panel1.Controls.Add($script:FindingsList)
$script:DetailTabs = New-Object Windows.Forms.TabControl
$script:DetailTabs.Dock = 'Fill'; $split.Panel2.Controls.Add($script:DetailTabs)
foreach ($entry in @(@('Diagnosis','DiagnosisBox'),@('Technical details','TechnicalBox'),@('FixCommands','CommandBox'))) {
    $page = New-Object Windows.Forms.TabPage
    $page.Text = $entry[0]; $page.BackColor = $script:Colors.Background; $page.Padding = New-Object Windows.Forms.Padding(4)
    $box = New-WorkspaceTextBox; $box.ReadOnly = $true; $box.WordWrap = $true; $box.ScrollBars = 'Vertical'; $box.Dock = 'Fill'
    $box.Font = New-Object Drawing.Font($(if ($entry[0] -eq 'Diagnosis') { 'Segoe UI' } else { 'Consolas' }),9)
    $page.Controls.Add($box); [void]$script:DetailTabs.TabPages.Add($page)
    Set-Variable -Scope Script -Name $entry[1] -Value $box
    if ($entry[1] -eq 'CommandBox') {
        $copy = New-ActionButton 'Copy selected commands' { Copy-SelectedCommands } 'Copies text only. Review the command shell and admin/reboot requirements before running anything.' $false 'SelectedCommands'
        $copy.Dock = 'Bottom'; $page.Controls.Add($copy)
    }
}
$script:LogBox = New-Object Windows.Forms.RichTextBox
$script:LogBox.Dock = 'Fill'; $script:LogBox.ReadOnly = $true
$script:LogBox.BackColor = $script:Colors.Background; $script:LogBox.ForeColor = $script:Colors.Text
$script:LogBox.Font = New-Object Drawing.Font('Consolas',9); $script:LogBox.Visible = $false
$script:Workspace.Controls.Add($script:LogBox)
$script:DetailsBox = New-WorkspaceTextBox
$script:DetailsBox.Dock = 'Fill'; $script:DetailsBox.ReadOnly = $true; $script:DetailsBox.Font = New-Object Drawing.Font('Consolas',9)
$script:DetailsBox.Visible = $false; $script:Workspace.Controls.Add($script:DetailsBox)

foreach ($section in @('Overview','Timer','CPU','USB','Network','Display/GPU','Power/Game')) {
    $layout = New-Object Windows.Forms.TableLayoutPanel
    $layout.Dock = 'Top'; $layout.AutoSize = $true; $layout.AutoSizeMode = 'GrowAndShrink'; $layout.ColumnCount = 1
    [void]$layout.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Percent',100)))
    $script:SectionPanels[$section] = $layout
}
$overview = $script:SectionPanels.Overview
$counts = New-ActionRow
foreach ($entry in @(@('OK','OkLabel'),@('WARN','WarnLabel'),@('FAIL','FailLabel'),@('INFO','InfoLabel'),@('UNKNOWN','UnknownLabel'))) {
    $label = New-WorkspaceLabel "$($entry[0]) 0"
    Set-SummaryLabel $label $label.Text $entry[0]
    Set-Variable -Scope Script -Name $entry[1] -Value $label
    $counts.Controls.Add($label)
}
$overview.Controls.Add($counts,0,0)
$row = New-ActionRow
$script:OpenHtmlButton = New-ActionButton 'Open HTML report' { Open-GuiPath $script:LastHtmlPath } '' $false 'Html'; $row.Controls.Add($script:OpenHtmlButton)
$script:OpenJsonButton = New-ActionButton 'Open JSON report' { Open-GuiPath $script:LastJsonPath } '' $false 'Json'; $row.Controls.Add($script:OpenJsonButton)
$row.Controls.Add((New-ActionButton 'Open report folder' { Open-GuiPath $script:OutputDir }))
$script:CopySummaryButton = New-ActionButton 'Copy summary' { Copy-Summary; New-GuiResult 'Last-scan summary copied. Nothing changed.' } '' $false 'Report'; $row.Controls.Add($script:CopySummaryButton)
$overview.Controls.Add($row,0,1)
foreach ($name in @('OverviewVerdict','OverviewTimer','OverviewDisplay')) {
    $label = New-WorkspaceLabel 'No scan loaded'; $label.Dock = 'Fill'
    Set-Variable -Scope Script -Name $name -Value $label
    $overview.Controls.Add($label,0,$overview.Controls.Count)
}

$timer = $script:SectionPanels.Timer
foreach ($entry in @(@('TimerLiveLabel','Live timer state: pending'),@('HolderLabel','Holder: pending'),@('TimerMatchLabel',''),@('TimerLabel','Last scan: none'),@('StartupHealthLabel','Startup check: not run'))) {
    $label = New-WorkspaceLabel $entry[1]; $label.Dock = 'Fill'
    Set-Variable -Scope Script -Name $entry[0] -Value $label
    $timer.Controls.Add($label,0,$timer.Controls.Count)
}
$script:OtherTimerScopeLabel = New-WorkspaceLabel 'Other GSB scope: not yet verified'
$script:OtherTimerScopeLabel.AutoSize = $false; $script:OtherTimerScopeLabel.AutoEllipsis = $true
$script:OtherTimerScopeLabel.MinimumSize = New-Object Drawing.Size(0,36); $script:OtherTimerScopeLabel.Dock = 'Fill'
$timer.Controls.Add($script:OtherTimerScopeLabel,0,$timer.Controls.Count)
$targetRow = New-ActionRow
$targetRow.Controls.Add((New-WorkspaceLabel 'Target (100 ns)'))
$script:TimerTarget = New-Object Windows.Forms.NumericUpDown
$script:TimerTarget.Minimum = 1; $script:TimerTarget.Maximum = 10000000; $script:TimerTarget.Value = $TimerTarget100ns
$script:TimerTarget.Width = 90; $script:TimerTarget.Margin = New-Object Windows.Forms.Padding(4,7,6,4)
$targetRow.Controls.Add($script:TimerTarget)
$script:TargetMsLabel = New-WorkspaceLabel (([double]$TimerTarget100ns / 10000.0).ToString('F4') + ' ms'); $targetRow.Controls.Add($script:TargetMsLabel)
$targetRow.Controls.Add((New-ActionButton 'Start holder' { Set-TimerHold $true } 'Starts an independent background process. Closing the GUI does not stop it.' $false 'HolderStart'))
$targetRow.Controls.Add((New-ActionButton 'Stop holder' { Set-TimerHold $false } 'Releases this holder request, not timer requests belonging to other processes.' $false 'HolderStop'))
$timer.Controls.Add($targetRow,0,$timer.Controls.Count)
$autoRow = New-ActionRow
$script:StartupScopeBox = New-Object Windows.Forms.ComboBox
$script:StartupScopeBox.DropDownStyle = 'DropDownList'; $script:StartupScopeBox.Width = 190
$script:StartupScopeBox.Items.AddRange(@('Current-user sign-in','Machine startup (SYSTEM)'))
$script:StartupScopeBox.SelectedIndex = $(if ((Get-GsbTimerPaths $script:TimerStateDirectory).Machine) { 1 } else { 0 })
if (-not $TimerStateDirectory) {
    $script:TimerStateDirectory = if ($script:StartupScopeBox.SelectedIndex -eq 1) { (Get-GsbMachineTimerPaths).Root } else { Join-Path $env:LOCALAPPDATA 'GamingStatusBench\Timer' }
}
$script:ToolTips.SetToolTip($script:StartupScopeBox,$(if ($script:TimerScopePinned) { 'Scope is fixed for this explicit custom holder directory.' } else { 'Machine startup runs in session 0 with protected scripts. Configuring it requires administrator approval; reading status does not.' }))
$autoRow.Controls.Add($script:StartupScopeBox)
$script:AutostartCheck = New-Object Windows.Forms.CheckBox
$script:AutostartCheck.ThreeState = $true
$script:AutostartCheck.Text = 'Enable startup'; $script:AutostartCheck.AutoSize = $true; $script:AutostartCheck.Margin = New-Object Windows.Forms.Padding(6,10,8,4)
$autoRow.Controls.Add($script:AutostartCheck)
$autoRow.Controls.Add((New-ActionButton 'Inspect autostart' { Inspect-GuiTimerAutostart }))
$autoRow.Controls.Add((New-ActionButton 'Check startup conflicts' { Check-GuiTimerStartup } 'Read-only inventory of timer tasks, Run entries, Startup folders, services and processes. Protected-task visibility requires elevation.'))
$autoRow.Controls.Add((New-ActionButton 'Update startup target' { Enable-GuiTimerAutostart } 'Updates the selected startup scope. Machine updates stop an existing managed holder; start it again afterward.' $false 'StartupConfigure'))
$script:AutostartLabel = New-WorkspaceLabel 'Autostart: pending'; $autoRow.Controls.Add($script:AutostartLabel)
$timer.Controls.Add($autoRow,0,$timer.Controls.Count)
$row = New-ActionRow
$row.Controls.Add((New-ActionButton 'Verify GUI timer policy' { Apply-ProcessTimerPolicy } 'Changes and reads back this GUI process policy only. The holder applies its own policy.'))
$row.Controls.Add((New-ActionButton 'Rescan without network' { Start-GuiScan -SkipNetwork } 'Collects all diagnostics, not a timer-only test. Scan wake tests request their own 0.5 ms resolution.' $false 'Scan'))
$row.Controls.Add((New-ActionButton 'Copy timer commands' { Copy-SectionCommands 'Timer' } '' $false 'Commands:Timer'))
$timer.Controls.Add($row,0,$timer.Controls.Count)
$row = New-ActionRow
$row.Controls.Add((New-WorkspaceLabel 'Boot/compatibility changes'))
$row.Controls.Add((New-ActionButton 'Enable legacy global mode' { Apply-GlobalTimerResolutionRequests } 'Admin confirmation and reboot required.' $true))
$row.Controls.Add((New-ActionButton 'Apply timer boot baseline' { Apply-BcdeditBaseline } 'Admin confirmation and reboot required. Not an automatic FPS fix.' $true))
$timer.Controls.Add($row,0,$timer.Controls.Count)

$cpu = $script:SectionPanels.CPU
$script:CpuStateLabel = New-WorkspaceLabel 'CPU state: no scan loaded'; $cpu.Controls.Add($script:CpuStateLabel,0,0)
$row = New-ActionRow
$script:CpuSet16Button = New-ActionButton 'Set boot limit: 16 threads' { Set-GuiCpuLimit $false } 'Only available for a fresh report confirming the supported 8C/16T target. Cannot enable BIOS SMT.' $true
$script:CpuRestoreButton = New-ActionButton 'Remove boot processor limit' { Set-GuiCpuLimit $true } 'Removes numproc only. Requires reboot; cannot enable BIOS SMT.' $true
$script:CopyCpuFixButton = New-ActionButton 'Copy CPU commands' { Copy-SectionCommands 'CPU' } '' $false 'Commands:CPU'
foreach ($button in @($script:CpuSet16Button,$script:CpuRestoreButton,$script:CopyCpuFixButton)) { $row.Controls.Add($button) }
$cpu.Controls.Add($row,0,1)
$row = New-ActionRow
$row.Controls.Add((New-ActionButton 'Disable matched USB power saving' { Apply-UsbPowerSavingOff } 'Writes only matched enabled WMI/registry entries; verifies each read-back. Reconnect/reboot may be needed.' $true))
$row.Controls.Add((New-ActionButton 'Copy USB commands' { Copy-SectionCommands 'USB' } '' $false 'Commands:USB'))
$script:SectionPanels.USB.Controls.Add($row,0,0)
$row = New-ActionRow
$script:NetworkLabel = New-WorkspaceLabel 'Network: no scan loaded'; $script:SectionPanels.Network.Controls.Add($script:NetworkLabel,0,0)
$row.Controls.Add((New-ActionButton 'Refresh DHCP and DNS' { Invoke-PreGameNetworkRefresh } 'Releases and renews DHCP, with two 6-second waits, then flushes DNS. Temporarily disconnects the network.'))
$row.Controls.Add((New-ActionButton 'Copy network commands' { Copy-SectionCommands 'Network' } '' $false 'Commands:Network'))
$row.Controls.Add((New-ActionButton 'Open network settings' { Open-GuiSettings 'ms-settings:network-status' }))
$script:SectionPanels.Network.Controls.Add($row,0,1)
$script:DisplayLabel = New-WorkspaceLabel 'Display/GPU: no scan loaded'; $script:SectionPanels['Display/GPU'].Controls.Add($script:DisplayLabel,0,0)
$row = New-ActionRow
$row.Controls.Add((New-ActionButton 'Open display settings' { Open-GuiSettings 'ms-settings:display' }))
$row.Controls.Add((New-ActionButton 'Open graphics settings' { Open-GuiSettings 'ms-settings:display-advancedgraphics' }))
$row.Controls.Add((New-ActionButton 'Copy display/GPU commands' { Copy-SectionCommands 'Display/GPU' } '' $false 'Commands:Display/GPU'))
$script:SectionPanels['Display/GPU'].Controls.Add($row,0,1)
$row = New-ActionRow
$row.Controls.Add((New-ActionButton 'Copy full power plan output' { Copy-PowerShowAll } 'Queries powercfg /qh and copies its output. Does not change the plan.'))
$row.Controls.Add((New-ActionButton 'Unhide advanced power settings' { Apply-PowerUnhideAll } 'Changes visibility only, preserving other Attributes bits and all active AC/DC values.' $true))
$row.Controls.Add((New-ActionButton 'Open power settings' { Open-GuiSettings 'ms-settings:powersleep' }))
$script:SectionPanels['Power/Game'].Controls.Add($row,0,0)
$row = New-ActionRow
$row.Controls.Add((New-ActionButton 'Disable capture and replay' { Set-GuiGameRegistry $true }))
$row.Controls.Add((New-ActionButton 'Enable Game Mode' { Set-GuiGameRegistry $false }))
$row.Controls.Add((New-ActionButton 'Open capture settings' { Open-GuiSettings 'ms-settings:gaming-gamedvr' }))
$row.Controls.Add((New-ActionButton 'Copy power/game commands' { Copy-SectionCommands 'Power/Game' } '' $false 'Commands:Power/Game'))
$script:SectionPanels['Power/Game'].Controls.Add($row,0,1)

$script:SettingsDialog = New-Object Windows.Forms.Form
$script:SettingsDialog.Text = 'Scan settings'; $script:SettingsDialog.Size = New-Object Drawing.Size(550,470)
$script:SettingsDialog.StartPosition = 'CenterParent'; $script:SettingsDialog.MinimizeBox = $false; $script:SettingsDialog.MaximizeBox = $false
$script:SettingsDialog.BackColor = $script:Colors.Background; $script:SettingsDialog.ForeColor = $script:Colors.Text
$script:SettingsDialog.Font = $script:Form.Font
$configLayout = New-Object Windows.Forms.TableLayoutPanel
$configLayout.Dock = 'Fill'; $configLayout.ColumnCount = 2; $configLayout.Padding = New-Object Windows.Forms.Padding(12)
[void]$configLayout.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Absolute',170)))
[void]$configLayout.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Percent',100)))
$script:SettingsDialog.Controls.Add($configLayout)
$script:GameExeBox = New-WorkspaceTextBox; $script:GameExeBox.Height = 68
$script:PingTargetBox = New-WorkspaceTextBox $false; $script:PingTargetBox.Text = '1.1.1.1,8.8.8.8'
$script:GamePingProfileBox = New-Object Windows.Forms.ComboBox
$script:GamePingProfileBox.DropDownStyle = 'DropDownList'; $script:GamePingProfileBox.Items.AddRange(@('none','cs2','valorant','apex','cod','bf6','fortnite','trackmania','tracknations','marvel-rivals','rainbow-six-siege','all')); $script:GamePingProfileBox.SelectedIndex = 0
$script:PingCountBox = New-Object Windows.Forms.NumericUpDown
$script:PingCountBox.Minimum = 1; $script:PingCountBox.Maximum = 100; $script:PingCountBox.Value = 8
$script:TimerSamplesBox = New-Object Windows.Forms.NumericUpDown
$script:TimerSamplesBox.Minimum = 10; $script:TimerSamplesBox.Maximum = 2000; $script:TimerSamplesBox.Value = 300; $script:TimerSamplesBox.Increment = 10
$script:NetworkBox = New-Object Windows.Forms.CheckBox
$script:NetworkBox.Text = 'Include network probes'; $script:NetworkBox.Checked = $true; $script:NetworkBox.AutoSize = $true
$rowIndex = 0
foreach ($entry in @(@('Game EXE paths',$script:GameExeBox),@('Ping targets',$script:PingTargetBox),@('Game ping profile',$script:GamePingProfileBox),@('Ping count',$script:PingCountBox),@('Wake-test samples',$script:TimerSamplesBox),@('Network tests',$script:NetworkBox))) {
    $configLayout.Controls.Add((New-WorkspaceLabel $entry[0]),0,$rowIndex)
    $entry[1].Dock = 'Fill'; $entry[1].Margin = New-Object Windows.Forms.Padding(4,6,4,10)
    $configLayout.Controls.Add($entry[1],1,$rowIndex)
    [void]$configLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',$(if ($rowIndex -eq 0) { 90 } else { 46 }))))
    $rowIndex++
}
$done = New-Object Windows.Forms.Button
$done.Text = 'Done'; $done.DialogResult = 'OK'; $done.Dock = 'Right'; $configLayout.Controls.Add($done,1,$rowIndex)
$script:SettingsDialog.AcceptButton = $done

$script:Navigation.Add_SelectedIndexChanged({
    $section = [string]$script:Navigation.SelectedItem
    $script:DiagnosticLayout.Visible = $section -notin @('Logs','Report JSON')
    $script:LogBox.Visible = $section -eq 'Logs'; $script:DetailsBox.Visible = $section -eq 'Report JSON'
    if (-not $script:DiagnosticLayout.Visible) {
        if ($script:LogBox.Visible) { $script:LogBox.BringToFront() } else { $script:DetailsBox.BringToFront() }
        return
    }
    $script:DiagnosticLayout.BringToFront()
    $script:ActionHost.Controls.Clear()
    $script:ActionHost.Controls.Add($script:SectionPanels[$section])
    if ($section -eq 'CPU') {
        Update-CpuStateLabel
    }
    Update-FindingsFilter
    Update-SectionLayout
})
$script:Workspace.Add_Resize({ Update-SectionLayout })
$script:StatusFilter.Add_SelectedIndexChanged({ Update-FindingsFilter })
$script:SearchBox.Add_TextChanged({ Update-FindingsFilter })
$script:FindingsList.Add_SelectedIndexChanged({
    if ($script:FindingsList.SelectedItems.Count -gt 0) { Show-FindingDetails $script:FindingsList.SelectedItems[0].Tag }
})
$script:TimerTarget.Add_ValueChanged({ $script:TargetMsLabel.Text = ([double]$script:TimerTarget.Value / 10000.0).ToString('F4') + ' ms' })
$script:StartupScopeBox.Add_SelectedIndexChanged({
    if (-not $script:TimerScopePinned) { $script:TimerStateDirectory = if ($script:StartupScopeBox.SelectedIndex -eq 1) { (Get-GsbMachineTimerPaths).Root } else { Join-Path $env:LOCALAPPDATA 'GamingStatusBench\Timer' } }
    $script:StartupPath = if ((Get-GsbTimerPaths $script:TimerStateDirectory).Machine) { '' } else { $script:UserStartupPathOverride }
    Update-LiveTimer
})
$script:AutostartCheck.Add_CheckStateChanged({
    if ($script:UpdatingAutostart) { return }
    $scope = if ($script:StartupScopeBox.SelectedIndex -eq 1) { 'machine timer startup' } else { 'timer at user sign-in' }
    if ($script:AutostartCheck.Checked) { Invoke-GuiAction "Enable $scope" { Enable-GuiTimerAutostart } }
    else { Invoke-GuiAction "Disable $scope" { Disable-GuiTimerAutostart } }
    Update-LiveTimer
})
$script:Form.Add_FormClosing({ param($sender,$e)
    if (($script:IsRunning -or $script:IsBusy) -and -not $script:AdminRelaunched) { $e.Cancel = $true; return }
    $script:LiveTimer.Stop()
    $script:SettingsDialog.Dispose()
    $script:ToolTips.Dispose()
})
$script:LiveTimer = New-Object Windows.Forms.Timer
$script:LiveTimer.Interval = 1000; $script:LiveTimer.Add_Tick({ Update-LiveTimer })
$script:HolderError = ''; $script:Navigation.SelectedItem = $InitialSection
Load-GuiPendingReboot
Update-MeasurementStatus
Update-LiveTimer
if ($SampleReportPath) {
    Update-ReportView (Get-Content -LiteralPath $SampleReportPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop) $false
}
else {
    $latest = Get-LatestReportJson
    if ($latest) {
        try { Update-ReportView (Get-Content -LiteralPath $latest -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop) $false }
        catch { Write-TerminalLog "Previous report could not be loaded: $($_.Exception.Message)" (Get-StatusColor 'WARN') }
    }
}
Write-TerminalLog "Ready. GUI elevated: $(Test-IsAdmin). Reports: $script:OutputDir" (Get-StatusColor 'INFO')
if (-not $NoShow) {
    $script:LiveTimer.Start()
    [void]$script:Form.ShowDialog()
    $script:LiveTimer.Dispose(); $script:Form.Dispose()
}
