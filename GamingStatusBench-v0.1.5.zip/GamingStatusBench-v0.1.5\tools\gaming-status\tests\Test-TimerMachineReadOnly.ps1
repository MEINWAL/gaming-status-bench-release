[CmdletBinding()]
param([string]$EvidenceDirectory='')
$ErrorActionPreference = 'Stop'
$source = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$project = [IO.Path]::GetFullPath((Join-Path $source '..\..'))
if (-not $EvidenceDirectory) { $EvidenceDirectory = Join-Path $project 'reports\ui-qa' }
New-Item -ItemType Directory -Path $EvidenceDirectory -Force | Out-Null
. (Join-Path $source 'TimerRuntime.ps1')
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
try { $admin=(New-Object Security.Principal.WindowsPrincipal($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) }
finally { $identity.Dispose() }
if ($admin) { throw 'Run this test without elevation to verify standard-user inspection.' }
$results = New-Object 'System.Collections.Generic.List[object]'
function Check-Machine {
    param([bool]$Condition,[string]$Name)
    if (-not $Condition) { throw "FAIL: $Name" }
    $results.Add([pscustomobject]@{Test=$Name;Status='PASS'})
    Write-Output "PASS: $Name"
}
$paths = Get-GsbMachineTimerPaths
$auto = Get-GsbMachineTimerAutostart
$holder = Get-GsbTimerHolderState $paths.Root
$initialMachineIdentity = [pscustomobject]@{ProcessId=$holder.State.ProcessId;ProcessStartTicks=$holder.State.ProcessStartTicks;Target100ns=$holder.State.Requested100ns}
Check-Machine ($auto.Status -eq 'Enabled' -and $holder.Running -and -not $holder.Error) 'Non-elevated process can inspect the running SYSTEM holder and protected task'
$inventoryDenied = $false
try { [void](Get-GsbLegacyTimerTasks) }
catch { $inventoryDenied = $_.Exception.Message -like 'Run as administrator*' }
Check-Machine $inventoryDenied 'Legacy machine-task inventory refuses a non-elevated all-clear'
foreach ($file in @($paths.Config,$paths.Holder,$paths.Runtime,(Join-Path $paths.Root 'TimerMachine.ps1'))) {
    $denied = $false; $stream = $null
    try { $stream=[IO.File]::Open($file,[IO.FileMode]::Open,[IO.FileAccess]::Write,[IO.FileShare]::ReadWrite) }
    catch [UnauthorizedAccessException] { $denied=$true }
    finally { if ($null -ne $stream) { $stream.Dispose() } }
    Check-Machine $denied ('Standard-user write access is denied: ' + [IO.Path]::GetFileName($file))
}
try {
    . (Join-Path $source 'GamingStatusGui.ps1') -NoShow -TimerStateDirectory $paths.Root -SampleReportPath (Join-Path $project 'sample-report.json')
    $ErrorActionPreference = 'Stop'
    $script:Form.Show(); [Windows.Forms.Application]::DoEvents()
    $script:Navigation.SelectedItem = 'Timer'
    [Windows.Forms.Application]::DoEvents(); Update-LiveTimer; Update-SectionLayout
    Check-Machine ($script:ActionHost.Controls.Count -eq 1 -and $script:ActionHost.Controls[0] -eq $script:SectionPanels.Timer -and @($script:FindingsList.Items | Where-Object {$_.Tag.Area -notin @('Timer','Kernel')}).Count -eq 0) 'Timer navigation renders the active timer actions and filtered findings'
    Check-Machine ($script:TimerHoldActive -and $script:HolderLabel.Text -like '*Machine / SYSTEM*5070*') 'Standard-user GUI displays machine scope, running holder and actual target'
    Check-Machine ($script:GuiPrivilegeLabel.Text -eq 'GUI: Standard user') 'Standard-user GUI keeps actual window privileges separate from an elevated sample scan'
    [void](Inspect-GuiTimerAutostart)
    Check-Machine ($script:TechnicalBox.Text -like '*coverage is INCOMPLETE without elevation*missing rows do not prove absence*') 'Startup inspection explicitly warns that protected legacy-task coverage is incomplete'
    Invoke-GuiAction 'Check startup conflicts' {Check-GuiTimerStartup}
    Check-Machine ($script:ActionStatus.Text -like 'Review:*Coverage: Partial*' -and $script:StartupHealthLabel.Text -like '*UNKNOWN*Partial*') 'Real non-elevated startup check reports incomplete visibility in the Timer workspace'
    $observations = @()
    for ($attempt=0; $attempt -lt 3; $attempt++) {
        $afterCheck=Get-GsbTimerHolderState $paths.Root
        $observations += [pscustomobject]@{CheckedUtc=[DateTime]::UtcNow.ToString('o');Holder=$afterCheck}
        if ($afterCheck.Running -and -not $afterCheck.Error) { break }
        Start-Sleep -Milliseconds 200
    }
    [pscustomobject]@{Before=$initialMachineIdentity;After=$observations} | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $EvidenceDirectory 'machine-readonly-holder-continuity.json') -Encoding UTF8
    Check-Machine ($afterCheck.Running -and -not $afterCheck.Error -and $afterCheck.State.ProcessId -eq $initialMachineIdentity.ProcessId -and $afterCheck.State.ProcessStartTicks -eq $initialMachineIdentity.ProcessStartTicks -and $afterCheck.State.Requested100ns -eq $initialMachineIdentity.Target100ns) 'Read-only GUI startup check leaves the running machine holder unchanged'
    $controlButtons=@($script:ActionButtons | Where-Object {$_.Tag.Gate -in @('HolderStart','HolderStop','StartupConfigure')})
    Check-Machine (@($controlButtons | Where-Object {$_.Enabled}).Count -eq 0 -and -not $script:AutostartCheck.Enabled) 'Machine write/control actions are disabled without elevation'
    $script:StartupScopeBox.SelectedIndex = 0
    Check-Machine (-not (Get-GsbTimerPaths $script:TimerStateDirectory).Machine -and $script:OtherTimerScopeBlocked -and $script:OtherTimerScopeLabel.Text -like 'CONFLICT:*machine / SYSTEM*' -and -not $script:AutostartCheck.Enabled -and @($controlButtons | Where-Object {$_.Tag.Gate -eq 'HolderStart' -and $_.Enabled}).Count -eq 0) 'Switching an explicit machine path to user scope uses the user path and blocks coexistence with the real SYSTEM holder'
    $script:StartupScopeBox.SelectedIndex = 1
    Check-Machine ((Get-GsbTimerPaths $script:TimerStateDirectory).Machine -and $script:TimerHoldActive -and $script:HolderLabel.Text -like '*Machine / SYSTEM*5070*') 'Switching back restores actual machine scope without changing the running holder'
    $bitmap=New-Object Drawing.Bitmap($script:Form.Width,$script:Form.Height)
    try {$script:Form.DrawToBitmap($bitmap,(New-Object Drawing.Rectangle(0,0,$bitmap.Width,$bitmap.Height)));$bitmap.Save((Join-Path $EvidenceDirectory 'machine-timer-standard-user.png'))}
    finally {$bitmap.Dispose()}
}
catch { $ErrorActionPreference = 'Stop'; throw }
finally {
    if ($null -ne (Get-Variable Form -Scope Script -ErrorAction SilentlyContinue)) {$script:Form.Close();$script:Form.Dispose()}
    $results | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $EvidenceDirectory 'machine-readonly-tests.json') -Encoding UTF8
}
