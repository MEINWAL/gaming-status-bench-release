[CmdletBinding()]
param(
    [string]$Root = "",
    [string]$ZipPath = "",
    [string]$Sha256Path = "",
    [switch]$Quiet
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"

if (-not $Root) {
    $Root = $PSScriptRoot
}
$Root = [System.IO.Path]::GetFullPath($Root)

function Write-VerifyLine {
    param(
        [string]$Status,
        [string]$Message
    )
    if (-not $Quiet) {
        Write-Host ("[{0}] {1}" -f $Status, $Message)
    }
}

function Assert-File {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "Missing file: $Path"
    }
}

function Assert-PowerShellParses {
    param([string]$Path)
    $errors = $null
    [void][System.Management.Automation.PSParser]::Tokenize((Get-Content -LiteralPath $Path -Raw), [ref]$errors)
    if ($errors.Count -gt 0) {
        $message = ($errors | ForEach-Object { "$($_.Message) at line $($_.Token.StartLine)" }) -join "; "
        throw "PowerShell parse failed for ${Path}: $message"
    }
}

$requiredFiles = @(
    "LICENSE",
    "README.md",
    "PRIVACY.md",
    "sample-report.json",
    "Run-GamingStatus-GUI.bat",
    "Run-GamingStatus.bat",
    "tools\gaming-status\GamingStatus.ps1",
    "tools\gaming-status\GamingStatusGui.ps1",
    "tools\gaming-status\TimerRuntime.ps1",
    "tools\gaming-status\TimerHolder.ps1",
    "tools\gaming-status\TimerMachine.ps1",
    "tools\gaming-status\TimerStartupDiagnostics.ps1",
    "tools\gaming-status\Manage-TimerStartup.ps1",
    "tools\gaming-status\GuiActions.ps1",
    "tools\gaming-status\GuiWorkspace.ps1",
    "tools\gaming-status\tests\Test-GamingStatusWorkspace.ps1",
    "tools\gaming-status\tests\Test-GuiActionFeedback.ps1",
    "tools\gaming-status\tests\Test-TimerSignIn.ps1",
    "tools\gaming-status\tests\Test-TimerMachineStartup.ps1",
    "tools\gaming-status\tests\Test-TimerMachineReadOnly.ps1",
    "tools\gaming-status\tests\Test-TimerStartupDiagnostics.ps1",
    "tools\release\Build-GamingStatusRelease.ps1"
)

foreach ($relative in $requiredFiles) {
    Assert-File (Join-Path $Root $relative)
    if ($relative -like '*.ps1') { Assert-PowerShellParses (Join-Path $Root $relative) }
}
Write-VerifyLine "OK" "Required package files are present."

$collectorPath = Join-Path $Root "tools\gaming-status\GamingStatus.ps1"
$guiPath = Join-Path $Root "tools\gaming-status\GamingStatusGui.ps1"
$releaseBuildPath = Join-Path $Root "tools\release\Build-GamingStatusRelease.ps1"
Assert-PowerShellParses $collectorPath
Assert-PowerShellParses $guiPath
Assert-PowerShellParses $releaseBuildPath
Write-VerifyLine "OK" "PowerShell scripts parse successfully."

$collectorText = Get-Content -LiteralPath $collectorPath -Raw
$version = ""
if ($collectorText -match '\$script:ToolVersion\s*=\s*"([^"]+)"') {
    $version = $matches[1]
}
else {
    throw "Could not read ToolVersion from GamingStatus.ps1."
}

$sample = Get-Content -LiteralPath (Join-Path $Root "sample-report.json") -Raw | ConvertFrom-Json
if ($sample.Tool -ne "GamingStatusBench") {
    throw "sample-report.json does not look like a GamingStatusBench report."
}
if (-not $sample.ReportSchemaVersion) {
    throw "sample-report.json is missing ReportSchemaVersion."
}
if ($sample.Version -ne $version) { throw 'Sample report version does not match the collector.' }
Write-VerifyLine "OK" "sample-report.json parses and includes schema metadata."

$exeFiles = @(Get-ChildItem -LiteralPath $Root -Recurse -File -Filter "*.exe" -ErrorAction SilentlyContinue)
if ($exeFiles.Count -gt 0) {
    throw "Unexpected EXE file(s) found in package: $($exeFiles.FullName -join ', ')"
}
Write-VerifyLine "OK" "No EXE wrapper found."

$zipHash = $null
if ($ZipPath) {
    if (-not [System.IO.Path]::IsPathRooted($ZipPath)) {
        $ZipPath = Join-Path $Root $ZipPath
    }
    Assert-File $ZipPath
    $zipHash = (Get-FileHash -LiteralPath $ZipPath -Algorithm SHA256).Hash.ToLowerInvariant()

    if (-not $Sha256Path) {
        $Sha256Path = "$ZipPath.sha256.txt"
    }
    if (-not [System.IO.Path]::IsPathRooted($Sha256Path)) {
        $Sha256Path = Join-Path $Root $Sha256Path
    }
    Assert-File $Sha256Path
    $shaText = Get-Content -LiteralPath $Sha256Path -Raw
    if ($shaText -notmatch "(?i)$zipHash") {
        throw "ZIP SHA256 does not match ${Sha256Path}. Calculated: $zipHash"
    }
    Write-VerifyLine "OK" "ZIP SHA256 matches checksum file."
}

$result = [pscustomobject]@{
    Status = "OK"
    Root = $Root
    Version = $version
    ReportSchemaVersion = [string]$sample.ReportSchemaVersion
    ZipPath = if ($ZipPath) { [System.IO.Path]::GetFullPath($ZipPath) } else { "" }
    ZipSha256 = if ($zipHash) { $zipHash } else { "" }
    CheckedAt = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss zzz")
}

if (-not $Quiet) {
    Write-Host ""
    Write-Host (($result | Format-List | Out-String).TrimEnd())
}

return $result
