[CmdletBinding()]
param(
    [string]$EvidenceDirectory = '',
    [switch]$RelaunchProbe,
    [string]$OutputDir = '',
    [string]$SampleReportPath = '',
    [string]$TimerStateDirectory = '',
    [string]$StartupPath = '',
    [uint32]$TimerTarget100ns = 5070,
    [string]$InitialSection = 'Overview'
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
$source = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$project = [IO.Path]::GetFullPath((Join-Path $source '..\..'))
if ($RelaunchProbe) {
    try {
        . (Join-Path $source 'GamingStatusGui.ps1') -NoShow -OutputDir $OutputDir -SampleReportPath $SampleReportPath -TimerStateDirectory $TimerStateDirectory -StartupPath $StartupPath -TimerTarget100ns $TimerTarget100ns -InitialSection $InitialSection
        $ErrorActionPreference = 'Stop'
        [pscustomobject]@{OutputDir=$script:OutputDir;StateDirectory=(Get-GsbTimerPaths $script:TimerStateDirectory).Root;Machine=(Get-GsbTimerPaths $script:TimerStateDirectory).Machine;StartupPath=$script:StartupPath;UserStartupPathOverride=$script:UserStartupPathOverride;AutostartLabel=$script:AutostartLabel.Text;Target100ns=$script:TimerTarget.Value;TargetLabel=$script:TargetMsLabel.Text;Section=[string]$script:Navigation.SelectedItem;InitialSamplePath=$script:InitialSamplePath;ReportStale=$script:MeasurementsStale;HolderRunning=$script:TimerHoldActive} | ConvertTo-Json -Depth 4
    }
    catch { $ErrorActionPreference = 'Stop'; throw }
    finally {
        foreach ($name in @('LiveTimer','SettingsDialog','ToolTips','Form')) {
            $variable = Get-Variable $name -Scope Script -ErrorAction SilentlyContinue
            if ($null -ne $variable -and $null -ne $variable.Value) { $variable.Value.Dispose() }
        }
    }
    return
}
$temporary = Join-Path $env:TEMP ('GSB action QA ' + [guid]::NewGuid())
if (-not $EvidenceDirectory) { $EvidenceDirectory = Join-Path $project 'reports\ui-qa' }
New-Item -ItemType Directory -Path $temporary,$EvidenceDirectory -Force | Out-Null
$registry = 'HKCU:\Software\GamingStatusBench-QA-' + [guid]::NewGuid()
New-Item -Path $registry -Force | Out-Null
New-ItemProperty -LiteralPath $registry -Name Attributes -Value 17 -PropertyType DWord | Out-Null
New-ItemProperty -LiteralPath $registry -Name UsbEnabled -Value 1 -PropertyType DWord | Out-Null
$clipboard = [System.Windows.Forms.Clipboard]::GetDataObject()
$checks = New-Object 'System.Collections.Generic.List[object]'
function Check {
    param([bool]$Condition,[string]$Name)
    if (-not $Condition) { throw "FAIL: $Name" }
    $checks.Add([pscustomobject]@{ Test=$Name; Status='PASS' })
    Write-Output "PASS: $Name"
}
try {
    . (Join-Path $source 'GamingStatusGui.ps1') -NoShow -OutputDir $temporary -SampleReportPath (Join-Path $project 'sample-report.json') -TimerStateDirectory $temporary -StartupPath (Join-Path $temporary 'unused.bat')
    $ErrorActionPreference = 'Stop'
    $script:Form.Show()
    $script:MockExit = 0; $script:MockBoot = "disabledynamictick Yes`r`nnumproc 16"
    $script:Trace = New-Object 'System.Collections.Generic.List[string]'
    function Test-IsAdmin { return $true }
    function Confirm-GuiChange { return $false }
    Invoke-GuiAction 'Cancel test' { Apply-GlobalTimerResolutionRequests }
    Check ($script:ActionStatus.Text -like 'Cancelled:*') 'Cancelled confirmation is not reported as applied'
    function Confirm-GuiChange { return $true }
    function Invoke-GuiProcess {
        param([string]$FilePath,[string[]]$Arguments)
        $script:Trace.Add($FilePath + ' ' + ($Arguments -join ' '))
        if ($FilePath -eq 'bcdedit.exe' -and $Arguments[0] -eq '/enum') { return [pscustomobject]@{ ExitCode=0; Output=$script:MockBoot; Error='' } }
        if ($FilePath -eq 'bcdedit.exe' -and $Arguments[0] -eq '/deletevalue' -and $script:MockExit -eq 0) { $script:MockBoot = 'disabledynamictick Yes' }
        if ($FilePath -eq 'bcdedit.exe' -and $Arguments[0] -eq '/set' -and $script:MockExit -eq 0) { $script:MockBoot = "disabledynamictick Yes`r`nnumproc 16" }
        [pscustomobject]@{ ExitCode=$script:MockExit; Output='QA command output'; Error='QA simulated error' }
    }
    $script:MockExit = 5
    Invoke-GuiAction 'Command failure' { [void](Invoke-CheckedGuiProcess 'reg.exe' @('QA')); New-GuiResult 'Should never be reported.' }
    Check ($script:ActionStatus.Text -like 'Failed:*' -and $script:ActionStatus.Text -notlike '*Should never*') 'Non-zero command exit prevents success feedback'
    $script:MockExit = 0
    $cpu = [pscustomobject]@{ Set16Allowed=$true; RestoreAllowed=$true; BcdNumProc=16 }
    $script:LastReport.Sections | Add-Member -MemberType NoteProperty -Name CpuScheduler -Value $cpu -Force
    $script:MeasurementsStale = $false
    Invoke-GuiAction 'Remove simulated boot limit' { Set-GuiCpuLimit $true }
    Check ($script:ActionStatus.Text -like 'Reboot required:*' -and $script:MeasurementsStale) 'Verified boot write is reboot-required and measurements become stale'
    Check (Test-Path -LiteralPath (Join-Path $temporary 'pending-reboot.json')) 'Reboot warning is persisted with the current boot timestamp'
    $receiptPathsReader = ${function:Get-GuiRebootReceiptPaths}
    $originalDirectory = $script:TimerStateDirectory
    try {
        $script:TimerStateDirectory = Join-Path $env:LOCALAPPDATA 'GamingStatusBench\Timer'
        $userReceipt = (Get-GuiRebootReceiptPaths).Current
        $script:TimerStateDirectory = (Get-GsbMachineTimerPaths).Root
        Check ((Get-GuiRebootReceiptPaths).Current -eq $userReceipt -and $userReceipt -notlike '*TimerMachine*') 'User and machine timer modes share a writable, scope-independent GUI reboot receipt'
        $script:TimerStateDirectory = $originalDirectory
        $script:QaRebootReceipt = Join-Path $temporary 'pending-reboot.json'
        $script:QaLegacyReceipt = Join-Path $temporary 'legacy-pending-reboot.json'
        Write-GsbTimerJson $script:QaLegacyReceipt ([pscustomobject]@{Action='Expired QA change';BootUtc='2000-01-01T00:00:00.0000000Z'})
        function Get-GuiRebootReceiptPaths { [pscustomobject]@{Current=$script:QaRebootReceipt;Legacy=@($script:QaLegacyReceipt)} }
        Load-GuiPendingReboot
        Update-MeasurementStatus
        Check ($script:PendingReboot.Action -eq 'Remove simulated boot limit' -and -not $script:RebootStateError -and (Test-Path -LiteralPath $script:QaLegacyReceipt)) 'Expired legacy reboot receipt is ignored without deleting a potentially protected file'
        Write-GsbTimerJson $script:QaLegacyReceipt ([pscustomobject]@{Action='Malformed QA change'})
        Load-GuiPendingReboot
        Update-MeasurementStatus
        Check ($script:PendingReboot.Action -eq 'Remove simulated boot limit' -and $script:RebootStateError -and $script:MeasurementStatus.Text -like '*REBOOT STATE UNVERIFIED*') 'Malformed reboot receipt visibly reports unverified state while preserving known reboot requirements'
    }
    finally {
        Set-Item Function:Get-GuiRebootReceiptPaths $receiptPathsReader
        $script:TimerStateDirectory = $originalDirectory
        Load-GuiPendingReboot
        Update-MeasurementStatus
    }
    Invoke-GuiAction 'Stale CPU guard' { Set-GuiCpuLimit $false }
    Check ($script:ActionStatus.Text -like 'Failed:*fresh scan*') 'Stale CPU snapshot cannot authorize a new cap'

    function Get-PowerSettingRegistryRows { return @([pscustomobject]@{ Path=$registry; Attributes=17; SettingGuid='QA setting'; Hidden=$true }) }
    Invoke-GuiAction 'Power visibility test' { Apply-PowerUnhideAll }
    Check ($script:ActionStatus.Text -like 'Verified:*' -and (Get-ItemPropertyValue -LiteralPath $registry -Name Attributes) -eq 16) 'Actual temporary registry write clears only the hidden bit and verifies read-back'
    function Get-UsbPowerSavingRows {
        return @([pscustomobject]@{ Backend='Registry'; RegistryPath=$registry; Name='UsbEnabled'; TargetValue=0; Enable=$true; InstanceName='QA USB'; DisplayPath=$registry })
    }
    Invoke-GuiAction 'USB registry test' { Apply-UsbPowerSavingOff }
    Check ($script:ActionStatus.Text -like 'Verified:*' -and (Get-ItemPropertyValue -LiteralPath $registry -Name UsbEnabled) -eq 0) 'Actual temporary USB-style flag write verifies read-back'
    function Get-UsbPowerSavingRows {
        return @([pscustomobject]@{ Backend='Registry'; RegistryPath=($registry+'\missing'); Name='UsbEnabled'; TargetValue=0; Enable=$true; InstanceName='QA missing'; DisplayPath=$registry })
    }
    Invoke-GuiAction 'USB failure test' { Apply-UsbPowerSavingOff }
    Check ($script:ActionStatus.Text -like 'Failed:*failed verification*') 'USB write/read-back failure is not reported as success'
    function Wait-GuiSeconds { param([int]$Seconds,[string]$Reason) $script:Trace.Add("wait $Seconds") }
    function Get-NetIPConfiguration { return @([pscustomobject]@{ IPv4DefaultGateway=[pscustomobject]@{ NextHop='192.0.2.1' }; IPv4Address=[pscustomobject]@{ IPAddress='192.0.2.2' } }) }
    $script:Trace.Clear()
    Invoke-GuiAction 'Network sequence test' { Invoke-PreGameNetworkRefresh }
    Check (($script:Trace -join '|') -eq 'ipconfig.exe /release|wait 6|ipconfig.exe /renew|wait 6|ipconfig.exe /flushdns') 'Network refresh preserves exact release/wait/renew/wait/flush order'
    Check ($script:ActionStatus.Text -like 'Verified:*' -and $script:MeasurementsStale) 'Network result requires a verified address and gateway and marks scan stale'
    $script:Trace.Clear(); $script:MockExit = 1
    Invoke-GuiAction 'Network recovery test' { Invoke-PreGameNetworkRefresh }
    Check (($script:Trace -join '|') -like '*ipconfig.exe /renew*ipconfig.exe /flushdns*' -and $script:ActionStatus.Text -like 'Failed:*') 'Renewal and DNS flush are attempted after release failure; result remains failed'
    $script:MockExit = 0
    Invoke-GuiAction 'Copy plan test' { Copy-PowerShowAll }
    Check ($script:ActionStatus.Text -like 'Verified:*copied*' -and [Windows.Forms.Clipboard]::GetText() -eq 'QA command output') 'Power plan copy confirms clipboard content and does not apply values'
    $script:CopySummaryButton.PerformClick()
    Check ($script:ActionStatus.Text -like 'Verified:*summary copied*' -and [Windows.Forms.Clipboard]::GetText() -like "Gaming Status Bench`r`nMeasurements:*JSON:*HTML:*") 'Summary copy verifies actual clipboard contents before success feedback'
    $clipboardWriter = ${function:Set-VerifiedGuiClipboardText}
    try {
        function Set-VerifiedGuiClipboardText { throw 'QA clipboard read-back failed' }
        $logLength = $script:LogBox.Text.Length
        $script:CopySummaryButton.PerformClick()
        Check ($script:ActionStatus.Text -like 'Failed:*QA clipboard read-back failed*' -and $script:LogBox.Text.Substring($logLength) -notlike '*summary copied to clipboard*') 'Failed clipboard verification cannot report summary copy success'
    }
    finally { Set-Item Function:Set-VerifiedGuiClipboardText $clipboardWriter }

    function Start-Process { throw (New-Object ComponentModel.Win32Exception(1223)) }
    Invoke-GuiAction 'Restart as admin' { Restart-AsAdmin }
    Check ($script:ActionStatus.Text -like 'Cancelled:*' -and -not $script:AdminRelaunched -and -not $script:Form.IsDisposed) 'UAC cancellation is explicit and keeps the current window open'
    function Start-Process { throw 'QA relaunch failure' }
    Invoke-GuiAction 'Restart as admin' { Restart-AsAdmin }
    Check ($script:ActionStatus.Text -like 'Failed:*QA relaunch failure*' -and -not $script:AdminRelaunched) 'Admin launch failure is not reported as requested or verified'
    Remove-Item Function:Start-Process

    $script:Navigation.SelectedItem = 'CPU'
    $script:SelectedFinding = $script:LastReport.Findings | Where-Object {$_.Area -eq 'CPU'} | Select-Object -First 1
    Show-FindingDetails $script:SelectedFinding
    $copySelectedButton = $script:ActionButtons | Where-Object {$_.Tag.Gate -eq 'SelectedCommands'}
    Check $copySelectedButton.Enabled 'Command copy is available for a selected finding with runnable commands'
    Check ($script:DiagnosisBox.Text -like '*Measured:*Recommendation:*' -and $script:TechnicalBox.Text -like '*FixCommands*' -and $script:CommandBox.Text -like '*bcdedit*') 'Finding diagnosis, technical data and commands occupy separate detail views'
    $script:Trace.Clear()
    Invoke-GuiAction 'Copy selected commands' { Copy-SelectedCommands }
    Check ($script:ActionStatus.Text -like 'Verified:*Nothing executed*' -and [Windows.Forms.Clipboard]::GetText() -like '*bcdedit /deletevalue*' -and $script:Trace.Count -eq 0) ("Command copy verifies clipboard contents without executing a system command. Status: $($script:ActionStatus.Text); traced commands: $($script:Trace.Count); clipboard: $([Windows.Forms.Clipboard]::GetText())")
    Show-FindingDetails $null
    Check (-not $copySelectedButton.Enabled) 'Command copy is unavailable when no finding is selected'
    $emptyFinding = $script:LastReport.Findings | Where-Object {@(Get-FindingCommands $_).Count -eq 0} | Select-Object -First 1
    Show-FindingDetails $emptyFinding
    Check (-not $copySelectedButton.Enabled -and $script:CommandBox.Text -eq 'No runnable commands for this finding.') 'Finding without runnable commands disables copy with explicit detail text'
    $unsafeFinding = $script:LastReport.Findings | Where-Object {$_.Area -eq 'CPU'} | Select-Object -First 1
    $unsafeFinding = $unsafeFinding | ConvertTo-Json -Depth 10 | ConvertFrom-Json
    $unsafeFinding.FixCommands = @('bcdedit /set {current} numproc 16')
    $script:MeasurementsStale = $true
    Show-FindingDetails $unsafeFinding
    Check (-not $copySelectedButton.Enabled) 'Stale report cannot enable copying a boot-cap command that the existing safety filter rejects'
    $script:Navigation.SelectedItem = 'Display/GPU'
    $displayCopy = $script:ActionButtons | Where-Object {$_.Tag.Gate -eq 'Commands:Display/GPU'}
    $displayCommands = @(foreach ($finding in @(Get-SectionFindings 'Display/GPU')) {Get-FindingCommands $finding})
    Check ($displayCopy.Enabled -eq ($displayCommands.Count -gt 0)) 'Section command-copy availability matches actual runnable command count'
    $script:Navigation.SelectedItem = 'Logs'
    Check ($script:LogBox.Visible -and -not $script:DiagnosticLayout.Visible -and $script:LogBox.Text -like '*QA relaunch failure*') 'Dedicated Logs view retains action failures'
    $script:Navigation.SelectedItem = 'Report JSON'
    Check ($script:DetailsBox.Visible -and -not $script:DiagnosticLayout.Visible -and $script:DetailsBox.Text -like '*ReportSchemaVersion*') 'Dedicated Report JSON view shows the loaded report'

    $startupReader=${function:Get-GsbTimerStartupDiagnostics}
    try {
        $script:Navigation.SelectedItem='Timer'
        function Get-GsbTimerStartupDiagnostics {
            [pscustomobject]@{Status='UNKNOWN';Summary='Coverage incomplete';CheckedUtc='2026-10-04T00:00:00Z';Coverage=[pscustomobject]@{Status='Partial'};Issues=@([pscustomobject]@{Code='InventoryIncomplete';Value='Protected tasks may be hidden';Note='Missing rows do not prove absence.';Action='Run elevated.'})}
        }
        $script:Trace.Clear()
        Invoke-GuiAction 'Check startup conflicts' {Check-GuiTimerStartup}
        Check ($script:ActionStatus.Text -like 'Review:*Partial*' -and $script:StartupHealthLabel.Text -like '*UNKNOWN*Partial*' -and $script:DiagnosisBox.Text -like '*Missing rows do not prove absence*' -and $script:Trace.Count -eq 0) 'Startup check shows incomplete visibility as review without executing a change'
        function Get-GsbTimerStartupDiagnostics {throw 'QA inventory query failed'}
        Invoke-GuiAction 'Check startup conflicts' {Check-GuiTimerStartup}
        Check ($script:ActionStatus.Text -like 'Failed:*QA inventory query failed*' -and $script:StartupHealthLabel.Text -like '*UNKNOWN*' -and $script:TechnicalBox.Text -eq 'QA inventory query failed' -and $script:CommandBox.Text -eq '') 'Failed startup recheck clears prior commands and cannot retain a healthy label'
    }
    finally {Set-Item Function:Get-GsbTimerStartupDiagnostics $startupReader}

    $resolutionReader = ${function:Get-GsbTimerResolution}
    $holderReader = ${function:Get-GsbTimerHolderState}
    try {
        $script:Navigation.SelectedItem = 'Timer'
        $script:FakeMeasured = 5000; $script:FakeReturned = 5070; $script:FailQuery = $false
        function Get-GsbTimerResolution {
            if ($script:FailQuery) { throw 'QA live query failure' }
            [pscustomobject]@{Lowest100ns=5000;Highest100ns=156250;Current100ns=$script:FakeMeasured;CurrentMs=$script:FakeMeasured/10000.0}
        }
        function Get-GsbTimerHolderState {
            param([string]$StateDirectory)
            [pscustomobject]@{Running=$true;Error='';State=[pscustomobject]@{ProcessId=123;Requested100ns=5070;RequestedMs=0.507;Returned100ns=$script:FakeReturned}}
        }
        Update-LiveTimer
        Check ($script:TimerMatchLabel.Text -like 'MISMATCH:*' -and $script:TimerLiveLabel.Text -like '*5000*' -and $script:HolderLabel.Text -like '*Requested: 5070*API returned: 5070*') 'Measured mismatch is explicit and does not replace the requested value'
        $script:FakeMeasured=5070; $script:FakeReturned=5000
        Update-LiveTimer
        Check ($script:TimerMatchLabel.Text -like 'MISMATCH:*' -and $script:HolderLabel.Text -like '*API returned: 5000*') 'API-returned mismatch is shown independently of measured resolution'
        $script:FakeReturned=5070
        Update-LiveTimer
        Check ($script:TimerMatchLabel.Text -like 'MATCH:*' -and $script:TimerMatchLabel.ForeColor.ToArgb() -eq (Get-StatusColor 'OK').ToArgb()) 'Matching timer measurements have explicit text and consistent status color'
        $script:FailQuery=$true
        Update-LiveTimer
        $holderControls=@($script:ActionButtons | Where-Object {$_.Tag.Gate -in @('HolderStart','HolderStop')})
        Check ($script:LiveTimerUnavailable -and $script:TimerLiveLabel.Text -eq 'LIVE measured: unavailable' -and $script:HolderLabel.Text -notlike '*5070*' -and $script:TimerMatchLabel.Text -like 'UNVERIFIED:*QA live query failure*' -and $script:AutostartCheck.CheckState -eq 'Indeterminate') 'Live query failure clears old measurements and shows unverified state'
        Check (@($holderControls | Where-Object {$_.Enabled}).Count -eq 0 -and -not $script:TimerTarget.Enabled) 'Unavailable live state disables conflicting holder controls'
        $script:FailQuery=$false
        Update-LiveTimer
        Check (-not $script:LiveTimerUnavailable -and $script:TimerMatchLabel.Text -like 'MATCH:*' -and @($holderControls | Where-Object {$_.Tag.Gate -eq 'HolderStop' -and $_.Enabled}).Count -eq 1) 'Fresh verification restores live state and appropriate controls'
    }
    finally {
        Set-Item Function:Get-GsbTimerResolution $resolutionReader
        Set-Item Function:Get-GsbTimerHolderState $holderReader
        Update-LiveTimer
    }

    $holderReader = ${function:Get-GsbTimerHolderState}
    $autostartReader = ${function:Get-GsbTimerAutostart}
    $originalScope = $script:StartupScopeBox.SelectedIndex
    try {
        $script:StateDirectoryBeforeScopeTest = $script:TimerStateDirectory
        $script:StartupScopeBox.SelectedIndex = 0
        $script:TimerStateDirectory = (Get-GsbTimerPaths (Join-Path $env:LOCALAPPDATA 'GamingStatusBench\Timer')).Root
        $script:ScopeOwnRunning = $false; $script:ScopeOwnStartup = 'Disabled'
        $script:ScopeOtherRunning = $true; $script:ScopeOtherStartup = 'Enabled'; $script:ScopeOtherQueryFails = $false
        function Get-GsbTimerAutostart {
            param([string]$StateDirectory,[string]$StartupPath)
            $own = $StateDirectory -eq $script:TimerStateDirectory
            if (-not $own -and $script:ScopeOtherQueryFails) { throw 'QA other-scope access denied' }
            [pscustomobject]@{Status=$(if ($own) { $script:ScopeOwnStartup } else { $script:ScopeOtherStartup });Error='';Target100ns=5070}
        }
        function Get-GsbTimerHolderState {
            param([string]$StateDirectory)
            [pscustomobject]@{Running=$(if ($StateDirectory -eq $script:TimerStateDirectory) { $script:ScopeOwnRunning } else { $script:ScopeOtherRunning });Error='';State=[pscustomobject]@{ProcessId=123;Requested100ns=5070;RequestedMs=0.507;Returned100ns=5070}}
        }
        $startButton = $script:ActionButtons | Where-Object {$_.Tag.Gate -eq 'HolderStart'}
        $stopButton = $script:ActionButtons | Where-Object {$_.Tag.Gate -eq 'HolderStop'}
        $configureButton = $script:ActionButtons | Where-Object {$_.Tag.Gate -eq 'StartupConfigure'}
        Update-LiveTimer
        Check ($script:OtherTimerScopeBlocked -and -not $startButton.Enabled -and -not $configureButton.Enabled -and -not $script:AutostartCheck.Enabled -and $script:OtherTimerScopeLabel.Text -like 'CONFLICT:*machine / SYSTEM*') 'Active machine scope disables user start and startup enable with a visible conflict reason'
        $previousSize = $script:Form.Size
        try {
            $script:Form.Size = New-Object Drawing.Size(1060,740)
            [Windows.Forms.Application]::DoEvents(); Update-SectionLayout; [Windows.Forms.Application]::DoEvents()
            $labelBounds = $script:OtherTimerScopeLabel.RectangleToScreen($script:OtherTimerScopeLabel.ClientRectangle)
            $hostBounds = $script:ActionHost.RectangleToScreen($script:ActionHost.ClientRectangle)
            Check ($hostBounds.Contains($labelBounds)) 'Scope conflict explanation stays visible above Start at minimum window size'
            $bitmap = New-Object Drawing.Bitmap($script:Form.Width,$script:Form.Height)
            try { $script:Form.DrawToBitmap($bitmap,(New-Object Drawing.Rectangle(0,0,$bitmap.Width,$bitmap.Height))); $bitmap.Save((Join-Path $EvidenceDirectory 'user-machine-conflict-1060.png')) }
            finally { $bitmap.Dispose() }
        }
        finally { $script:Form.Size = $previousSize }
        $script:ScopeOwnRunning = $true; $script:ScopeOwnStartup = 'Enabled'
        Update-LiveTimer
        Check ($stopButton.Enabled -and $script:AutostartCheck.Enabled -and $script:AutostartCheck.Checked) 'Other-scope conflict still permits stopping the selected holder and disabling its startup'
        $script:ScopeOwnRunning = $false; $script:ScopeOwnStartup = 'Disabled'; $script:ScopeOtherQueryFails = $true
        Update-LiveTimer
        Check ($script:OtherTimerScopeBlocked -and -not $startButton.Enabled -and -not $script:AutostartCheck.Enabled -and $script:OtherTimerScopeLabel.Text -like 'UNVERIFIED:*QA other-scope access denied*' -and -not $script:LiveTimerUnavailable -and $script:TimerLiveLabel.Text -notlike '*unavailable*') 'Unknown other-scope state blocks starts without discarding verified live measurements'
        $script:ScopeOtherQueryFails = $false; $script:ScopeOtherRunning = $false; $script:ScopeOtherStartup = 'Invalid'
        Update-LiveTimer
        Check ($script:OtherTimerScopeBlocked -and -not $startButton.Enabled -and $script:OtherTimerScopeLabel.Text -like 'UNVERIFIED:*Invalid*') 'Invalid other-scope startup cannot be treated as safely disabled'
        $script:ScopeOtherStartup = 'Disabled'
        Update-LiveTimer
        Check (-not $script:OtherTimerScopeBlocked -and $startButton.Enabled -and $configureButton.Enabled -and $script:AutostartCheck.Enabled) 'Verified disabled other scope restores available user controls'
        $script:TimerStateDirectory = $script:StateDirectoryBeforeScopeTest; $script:ScopeOtherRunning = $true; $script:ScopeOtherStartup = 'Enabled'
        Update-LiveTimer
        Check (-not $script:OtherTimerScopeBlocked -and $startButton.Enabled -and $script:OtherTimerScopeLabel.Text -like '*custom holder directory*') 'Isolated QA/custom directories remain independent of managed-scope availability'
    }
    finally {
        Set-Item Function:Get-GsbTimerHolderState $holderReader
        Set-Item Function:Get-GsbTimerAutostart $autostartReader
        $script:TimerStateDirectory = $script:StateDirectoryBeforeScopeTest
        $script:StartupScopeBox.SelectedIndex = $originalScope
        Update-LiveTimer
    }

    $guiScriptPath = $script:GuiScriptPath
    $originalDirectory = $script:TimerStateDirectory
    $originalTarget = $script:TimerTarget.Value
    $originalStartupPath = $script:StartupPath
    $originalUserStartupPathOverride = $script:UserStartupPathOverride
    $originalOutputDir = $script:OutputDir
    $originalSamplePath = $script:InitialSamplePath
    try {
        $script:GuiScriptPath = Join-Path $source 'tests\Test-GuiActionFeedback.ps1'
        $script:UserStartupPathOverride = Join-Path $temporary 'startup & timer.bat'
        $script:TimerTarget.Value = 6000
        $script:Navigation.SelectedItem = 'Display/GPU'
        $script:OutputDir = $temporary + '\'
        foreach ($case in @(@('Custom',((Join-Path $temporary 'scope & holder') + '\')),@('User',((Join-Path $env:LOCALAPPDATA 'GamingStatusBench\Timer') + '\')),@('Machine',((Get-GsbMachineTimerPaths).Root + '\')))) {
            $script:TimerStateDirectory = $case[1]
            $machine = (Get-GsbTimerPaths $case[1]).Machine
            $script:StartupPath = if ($machine) { '' } else { $script:UserStartupPathOverride }
            $beforeProbe = Get-GsbTimerHolderState $case[1]
            $beforeAutostart = if ($machine) { Get-GsbMachineTimerAutostart } else { $null }
            $psi = New-Object Diagnostics.ProcessStartInfo
            $psi.FileName = Join-Path $PSHOME 'powershell.exe'
            $psi.Arguments = (Get-GuiRelaunchArguments) + ' -RelaunchProbe'
            $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
            $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true
            $probeProcess = [Diagnostics.Process]::Start($psi)
            try {
                $stdout = $probeProcess.StandardOutput.ReadToEndAsync(); $stderr = $probeProcess.StandardError.ReadToEndAsync()
                if (-not $probeProcess.WaitForExit(30000)) { $probeProcess.Kill(); $probeProcess.WaitForExit(); throw 'Relaunch argument probe timed out.' }
                $probeProcess.WaitForExit()
                if ($probeProcess.ExitCode -ne 0) { throw "Relaunch argument probe failed: $($stderr.Result)" }
                $probe = $stdout.Result | ConvertFrom-Json -ErrorAction Stop
                Check ($probe.StateDirectory -eq (Get-GsbTimerPaths $case[1]).Root -and $probe.Machine -eq $machine -and $probe.OutputDir -eq $script:OutputDir -and $probe.StartupPath -eq $script:StartupPath -and $probe.UserStartupPathOverride -eq $script:UserStartupPathOverride) "$($case[0]) relaunch preserves actual scope and explicit paths, including spaces and ampersands"
                Check ($probe.Target100ns -eq 6000 -and $probe.TargetLabel -eq ((6000 / 10000.0).ToString('F4') + ' ms') -and $probe.Section -eq 'Display/GPU') "$($case[0]) relaunch preserves selected timer target, converted label and section"
                $afterProbe = Get-GsbTimerHolderState $case[1]
                $unchanged = $afterProbe.Running -eq $beforeProbe.Running
                if ($null -eq $beforeProbe.State) { $unchanged = $unchanged -and $null -eq $afterProbe.State }
                else { $unchanged = $unchanged -and $null -ne $afterProbe.State -and $afterProbe.State.ProcessId -eq $beforeProbe.State.ProcessId -and $afterProbe.State.Requested100ns -eq $beforeProbe.State.Requested100ns }
                Check ($probe.ReportStale -and $probe.InitialSamplePath -eq (Join-Path $project 'sample-report.json') -and $unchanged) "$($case[0]) relaunch retains stale report status without starting or changing a holder"
                if ($machine) { Check ($probe.AutostartLabel -like "Startup: $($beforeAutostart.Status)*Machine / SYSTEM*") 'Machine relaunch inspects its actual task, not the preserved user BAT override' }
            }
            finally { $probeProcess.Dispose() }
        }
        $script:InitialSamplePath = Join-Path $temporary 'missing-report-for-initialization.json'
        $psi.Arguments = (Get-GuiRelaunchArguments) + ' -RelaunchProbe'
        $failedProbe = [Diagnostics.Process]::Start($psi)
        try {
            $stdout = $failedProbe.StandardOutput.ReadToEndAsync(); $stderr = $failedProbe.StandardError.ReadToEndAsync()
            if (-not $failedProbe.WaitForExit(30000)) { $failedProbe.Kill(); $failedProbe.WaitForExit(); throw 'Expected initialization-failure probe timed out.' }
            $failedProbe.WaitForExit()
            Check ($failedProbe.ExitCode -ne 0 -and $stderr.Result -like '*missing-report-for-initialization.json*') 'Native GUI initialization errors propagate as a non-zero test-process exit'
        }
        finally { $failedProbe.Dispose() }
    }
    finally {
        $script:GuiScriptPath = $guiScriptPath
        $script:TimerStateDirectory = $originalDirectory
        $script:StartupPath = $originalStartupPath
        $script:UserStartupPathOverride = $originalUserStartupPathOverride
        $script:OutputDir = $originalOutputDir
        $script:InitialSamplePath = $originalSamplePath
        $script:TimerTarget.Value = $originalTarget
        Update-LiveTimer
    }
    $script:Form.Add_FormClosing({
        $script:RelaunchCloseStatus = $script:ActionStatus.Text
        $script:RelaunchCloseLog = $script:LogBox.Text
    })
    function Start-Process {
        param([string]$FilePath,[string]$ArgumentList,[string]$Verb)
        $script:RelaunchCommand = [pscustomobject]@{FilePath=$FilePath;Arguments=$ArgumentList;Verb=$Verb}
    }
    $expectedRelaunchArguments = Get-GuiRelaunchArguments
    Invoke-GuiAction 'Restart as admin' { Restart-AsAdmin }
    Check ($script:AdminRelaunched -and $script:Form.IsDisposed -and $script:RelaunchCloseStatus -like 'Review:*launch requested*' -and $script:RelaunchCloseLog -like '*Review:*launch requested*') 'Successful mocked admin launch records review feedback before closing, never claims verified elevation'
    Check ($script:RelaunchCommand.FilePath -eq (Join-Path $PSHOME 'powershell.exe') -and $script:RelaunchCommand.Verb -eq 'RunAs' -and $script:RelaunchCommand.Arguments -eq $expectedRelaunchArguments) 'Admin launch uses the trusted PowerShell path and the preserved GUI arguments'
}
catch { $ErrorActionPreference = 'Stop'; throw }
finally {
    if ($null -ne (Get-Variable Form -Scope Script -ErrorAction SilentlyContinue)) { $script:Form.Close(); $script:Form.Dispose() }
    if ($clipboard) { [Windows.Forms.Clipboard]::SetDataObject($clipboard,$true) }
    $checks | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $EvidenceDirectory 'action-tests.json') -Encoding UTF8
    Remove-Item -LiteralPath $registry -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $temporary -Recurse -Force -ErrorAction SilentlyContinue
}
