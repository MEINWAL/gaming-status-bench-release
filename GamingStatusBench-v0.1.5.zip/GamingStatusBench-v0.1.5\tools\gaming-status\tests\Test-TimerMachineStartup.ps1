[CmdletBinding()]
param([switch]$Prepare,[string]$ResultPath='')
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot '..\TimerRuntime.ps1')
$paths = Get-GsbMachineTimerPaths
$baselinePath = Join-Path $paths.Root 'boot-test-baseline.json'
$boot = (Get-CimInstance Win32_OperatingSystem).LastBootUpTime.ToUniversalTime().ToString('o')
if ($Prepare) {
    Assert-GsbTimerAdministrator
    $baseline = [ordered]@{PreparedUtc=[DateTime]::UtcNow.ToString('o');BootUtc=$boot;Target100ns=5070}
    Write-GsbTimerJson $baselinePath $baseline
    Set-GsbMachineFileOwner $baselinePath
    [pscustomobject]$baseline
    return
}
$result = [ordered]@{Status='PENDING';Reason='';CheckedUtc=[DateTime]::UtcNow.ToString('o');CurrentBootUtc=$boot}
$auto = Get-GsbMachineTimerAutostart
$holder = Get-GsbTimerHolderState $paths.Root
$result.Autostart = $auto; $result.Holder = $holder
if ($auto.Status -ne 'Enabled') { $result.Reason = 'Protected SYSTEM startup task did not verify.' }
elseif (-not (Test-Path -LiteralPath $baselinePath)) { $result.Reason = 'No pre-reboot baseline has been recorded.' }
else {
    $baseline = Get-Content -LiteralPath $baselinePath -Raw | ConvertFrom-Json
    $result.Baseline = $baseline
    if ($baseline.BootUtc -eq $boot) { $result.Reason = 'A new Windows boot after preparation has not occurred.' }
    elseif (-not $holder.Running) { $result.Reason = 'No verified running machine holder after boot.' }
    elseif ($holder.State.BootUtc -ne $boot -or $holder.State.LogonIdentity.UserSid -ne 'S-1-5-18' -or $holder.State.SessionId -ne 0 -or $holder.State.LaunchKind -ne 'MachineTask') { $result.Reason = 'Holder identity/session/boot did not verify.' }
    elseif ($holder.State.Requested100ns -ne $baseline.Target100ns -or -not $holder.State.PolicyVerified) { $result.Reason = 'Timer target or process policy did not verify.' }
    elseif ([DateTime]::Parse($holder.State.StartedUtc).ToUniversalTime() -gt [DateTime]::Parse($boot).AddMinutes(3)) { $result.Reason = 'Holder started too late to establish automatic boot execution; inspect Task Scheduler history.' }
    elseif (@(Get-GsbLegacyTimerEntries).Count -gt 0 -or (Test-Path -LiteralPath (Get-GsbTimerPaths (Join-Path $env:LOCALAPPDATA 'GamingStatusBench\Timer')).Startup)) { $result.Reason = 'Another recognized timer startup remains.' }
    else { $result.Status='PASS'; $result.Reason='Protected task automatically launched a verified SYSTEM/session-0 holder after a new Windows boot. This check does not prove absence of other protected timer tasks.' }
}
if ($ResultPath) { Write-GsbTimerJson $ResultPath $result }
[pscustomobject]$result
