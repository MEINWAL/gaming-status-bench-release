[CmdletBinding()]
param(
    [ValidateSet('InstallMachine','Inspect','Start','Stop','DisableMachine')][string]$Action = 'Inspect',
    [uint32]$Target100ns = 5070,
    [switch]$ReplaceLegacy,
    [switch]$StartNow,
    [switch]$TestLifecycle,
    [string]$ResultPath = ''
)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'TimerRuntime.ps1')
$result = [ordered]@{Status='Failed';Action=$Action;CheckedUtc=[DateTime]::UtcNow.ToString('o');Error=''}
try {
    switch ($Action) {
        'InstallMachine' {
            $auto = Enable-GsbMachineTimerAutostart -Target100ns $Target100ns -ReplaceLegacy:$ReplaceLegacy
            $result.BackupDirectory = $auto.BackupDirectory
            & (Join-Path $PSScriptRoot 'tests\Test-TimerMachineStartup.ps1') -Prepare | Out-Null
            if ($StartNow -or $TestLifecycle) { $result.Holder = Start-GsbMachineTimer $Target100ns }
        }
        'Start' { $result.Holder = Start-GsbMachineTimer $Target100ns }
        'Stop' { [void](Stop-GsbTimerHolder (Get-GsbMachineTimerPaths).Root) }
        'DisableMachine' { [void](Disable-GsbMachineTimerAutostart) }
    }
    if ($TestLifecycle) {
        $first = Get-GsbTimerHolderState (Get-GsbMachineTimerPaths).Root
        if (-not $first.Running) { throw 'Machine lifecycle test requires a running holder.' }
        $repeat = Start-GsbMachineTimer $Target100ns
        if ($repeat.State.ProcessId -ne $first.State.ProcessId) { throw 'Repeated start created another holder.' }
        Start-ScheduledTask -TaskName 'GamingStatusBench-Timer-Machine'
        Start-Sleep -Seconds 2
        if ((Get-GsbTimerHolderState (Get-GsbMachineTimerPaths).Root).State.ProcessId -ne $first.State.ProcessId) { throw 'Task repeat changed the holder PID.' }
        [void](Stop-GsbTimerHolder (Get-GsbMachineTimerPaths).Root)
        $stopped = Get-GsbTimerHolderState (Get-GsbMachineTimerPaths).Root
        if ($stopped.Running -or $stopped.State.ReleaseStatus -ne 0) { throw 'Machine timer release did not verify.' }
        $result.LifecycleTests = @('SYSTEM/session 0 start','Repeated start reuses one PID','Scheduler repeat does not duplicate holder','Stop releases the matching request')
        $result.Holder = Start-GsbMachineTimer $Target100ns
    }
    $result.Autostart = Get-GsbMachineTimerAutostart
    $result.LegacyRunEntries = @(Get-GsbLegacyTimerEntries)
    $result.TimerProcesses = @(Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'SetTimerResolution.exe' -or ($null -ne $_.CommandLine -and $_.CommandLine -match 'TimerHolder\.ps1') } | Select-Object Name,ProcessId,SessionId,CreationDate,ExecutablePath,CommandLine)
    $result.Resolution = Get-GsbTimerResolution
    if ($result.Autostart.Status -eq 'Invalid') { throw $result.Autostart.Error }
    $result.Status = 'Verified'
}
catch { $result.Error = $_.Exception.ToString() }
if ($ResultPath) { Write-GsbTimerJson $ResultPath $result }
[pscustomobject]$result
if ($result.Status -ne 'Verified') { exit 1 }
