[CmdletBinding()]
param([string]$EvidenceDirectory='')
Set-StrictMode -Version 2.0
$ErrorActionPreference='Stop'
$source=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
. (Join-Path $source 'TimerStartupDiagnostics.ps1')
$checks=New-Object 'System.Collections.Generic.List[object]'
function Check {
    param([bool]$Condition,[string]$Name)
    if(-not $Condition){throw "FAIL: $Name"}
    $checks.Add([pscustomobject]@{Test=$Name;Status='PASS'})
    Write-Output "PASS: $Name"
}
function New-Inventory {
    [pscustomobject]@{CheckedUtc=[DateTime]::UtcNow.ToString('o');IsAdmin=$true;StartupEntries=@();Processes=@();Managed=@();Resolution=[pscustomobject]@{Current100ns=5070};BootUtc=[DateTime]::UtcNow.AddMinutes(-10).ToString('o');Sources=@([pscustomobject]@{Name='Scheduled tasks';Status='Complete';MatchedRows=0;Error=''})}
}
function New-Managed {
    [pscustomobject]@{Scope='Machine';Autostart=[pscustomobject]@{Status='Enabled';Target100ns=5070;Error=''};Holder=[pscustomobject]@{Running=$true;Error='';State=[pscustomobject]@{Requested100ns=5070;Returned100ns=5070;SessionId=0;LogonIdentity=[pscustomobject]@{UserSid='S-1-5-18'}}};ConfigWrittenUtc=[DateTime]::UtcNow.AddHours(-1).ToString('o')}
}
try {
    $inventory=New-Inventory
    $result=New-GsbTimerStartupAssessment $inventory
    Check ($result.Status -eq 'OK' -and $result.Issues.Count -eq 0) 'Empty complete scoped inventory is handled without StrictMode errors'
    $inventory.IsAdmin=$false
    $result=New-GsbTimerStartupAssessment $inventory
    Check ($result.Status -eq 'UNKNOWN' -and $result.Coverage.Status -eq 'Partial' -and $result.Issues.Code -contains 'InventoryIncomplete') 'Non-admin empty inventory never gives an all-clear'
    $inventory=New-Inventory; $inventory.Sources[0].Status='Failed';$inventory.Sources[0].Error='Access denied'
    $result=New-GsbTimerStartupAssessment $inventory
    Check ($result.Status -eq 'UNKNOWN' -and $result.Coverage.Sources[0].Error -eq 'Access denied') 'Access-denied source failure is retained and prevents an all-clear'
    $old=New-GsbTimerStartupEntry 'Scheduled task' '\TimerResolution_0_5110ms' 'Machine' $true 'Running' 'powershell.exe -File "C:\ProgramData\TimerResolution\Set-TimerResolution.ps1" -Desired100ns 5110' 'SYSTEM' 'Highest'
    $gsb=New-GsbTimerStartupEntry 'Scheduled task' '\GamingStatusBench-Timer-Machine' 'Machine' $true 'Running' 'powershell.exe -File "C:\ProgramData\GamingStatusBench\TimerMachine\TimerHolder.ps1" -ConfigPath "C:\ProgramData\GamingStatusBench\TimerMachine\config.json"' 'SYSTEM' 'Highest'
    $inventory=New-Inventory; $inventory.StartupEntries=@($old,$gsb); $inventory.Managed=@(New-Managed)
    $inventory.Processes=@(
        [pscustomobject]@{Name='powershell.exe';ProcessId=2568;SessionId=0;Target100ns=5110;Recognition='Known launcher'},
        [pscustomobject]@{Name='powershell.exe';ProcessId=2656;SessionId=0;Target100ns=$null;Recognition='Known launcher'}
    )
    $result=New-GsbTimerStartupAssessment $inventory
    Check ($result.Status -eq 'WARN' -and $result.Issues.Code -contains 'MultipleStartupEntries' -and $result.Issues.Code -contains 'MultipleTimerProcesses' -and $result.Issues.Code -contains 'DifferentTimerTargets') 'SYSTEM 5110 task plus GSB 5070 holder reproduces the reported conflict'
    Check ($result.StartupEntries[1].Target100ns -eq 5070 -and $result.ReadOnly) 'Managed target is read from configuration; diagnosis is read-only'
    $old.Enabled=$false;$old.State='Disabled';$inventory.Processes=@($inventory.Processes[1])
    $result=New-GsbTimerStartupAssessment $inventory
    Check ($result.Status -eq 'OK' -and $result.StartupEntries.Count -eq 2 -and $result.ActiveStartupCount -eq 1) 'Disabled old task remains visible but is not counted as an active conflict'
    $inventory.Managed[0].Holder.State.Returned100ns=5000
    $result=New-GsbTimerStartupAssessment $inventory
    Check ($result.Issues.Code -contains 'RequestedMeasuredMismatch') 'API-returned mismatch is separate from the configured target'
    $inventory.Managed[0].Holder.State.Returned100ns=5070;$inventory.Resolution.Current100ns=5000
    $result=New-GsbTimerStartupAssessment $inventory
    Check ($result.Issues.Code -contains 'RequestedMeasuredMismatch') 'Live measured mismatch is detected even when the holder API return matches'
    $inventory.Resolution.Current100ns=5070;$inventory.Managed[0].Autostart.Target100ns=5110
    $result=New-GsbTimerStartupAssessment $inventory
    Check ($result.Issues.Code -contains 'StartupRuntimeTargetMismatch') 'Changed startup target is not mistaken for the running target'
    $inventory=New-Inventory;$inventory.Managed=@(New-Managed);$inventory.Managed[0].Holder.Running=$false
    $result=New-GsbTimerStartupAssessment $inventory
    Check ($result.Issues.Code -contains 'MachineStartupNotRunning') 'Configured-before-boot startup with no holder after grace period is flagged'
    $inventory.Managed[0].Holder.State | Add-Member -NotePropertyName Status -NotePropertyValue 'Stopped'
    $inventory.Managed[0].Holder.State | Add-Member -NotePropertyName BootUtc -NotePropertyValue $inventory.BootUtc
    $result=New-GsbTimerStartupAssessment $inventory
    Check ($result.Status -eq 'OK') 'Recorded intentional stop in this boot is not called a failed startup'
    $inventory.Managed[0].Holder.State.Status='Running'
    $inventory.Managed[0].ConfigWrittenUtc=[DateTime]::UtcNow.ToString('o')
    $result=New-GsbTimerStartupAssessment $inventory
    Check ($result.Status -eq 'OK') 'Installation after the current boot is not called a failed boot launch'
    $inventory.Managed[0].Holder.Error='Heartbeat stale'
    $result=New-GsbTimerStartupAssessment $inventory
    Check ($result.Status -eq 'UNKNOWN' -and $result.Issues.Code -contains 'ManagedHolderUnverified') 'Stale heartbeat/error cannot become a healthy running-holder result'
    $inventory=New-Inventory;$inventory.Managed=@(New-Managed);$inventory.Managed[0].Autostart.Status='Invalid';$inventory.Managed[0].Autostart.Error='Task identity changed'
    $result=New-GsbTimerStartupAssessment $inventory
    Check ($result.Issues.Code -contains 'ManagedStartupInvalid') 'Invalid startup identity/integrity is reported with its error'
    $inventory.Managed[0].Autostart.Status='Enabled';$inventory.Managed[0].Holder.State.SessionId=1
    $result=New-GsbTimerStartupAssessment $inventory
    Check ($result.Issues.Code -contains 'MachineHolderWrongIdentity') 'A user-session holder cannot verify machine/SYSTEM startup'
    $inventory=New-Inventory;$inventory.StartupEntries=@(New-GsbTimerStartupEntry 'Run' 'TimerResolution custom' 'User' $true 'Configured' 'custom.exe --encoded unknown')
    $result=New-GsbTimerStartupAssessment $inventory
    Check ($result.Issues.Code -contains 'UnrecognizedTimerStartup' -and $null -eq $result.StartupEntries[0].Target100ns) 'Unrecognized timer entry is reviewed without inventing a target'
    Check ((Get-GsbTimerCommandInfo '"C:\Timer\SetTimerResolution.exe" --resolution=5110').Target100ns -eq 5110) 'Third-party resolution argument is read without executing it'
    Check ($null -eq (Get-GsbTimerCommandInfo 'C:\tools\notSetTimerResolution.exe')) 'Similar executable names do not match a known timer launcher'
    $approval=New-Inventory;$approval.StartupEntries=@(New-GsbTimerStartupEntry 'Run' 'Timer entry' 'User' $null 'Configured; execution approval unverified' 'C:\tools\SetTimerResolution.exe --resolution 5070')
    $approvalResult=New-GsbTimerStartupAssessment $approval
    Check ($approvalResult.Status -eq 'UNKNOWN' -and $approvalResult.UnverifiedStartupCount -eq 1 -and $approvalResult.Issues.Code -contains 'StartupExecutionUnverified') 'Run or Startup entry presence is not mistaken for verified execution approval'
    $taskRunner=Join-Path $env:ProgramData 'TimerResolution\Set-TimerResolution.ps1'
    function Get-ScheduledTask {
        @(
            [pscustomobject]@{TaskPath='\';TaskName='Unrelated COM handler';Actions=@([pscustomobject]@{ClassId='QA'});Settings=[pscustomobject]@{Enabled=$true};Principal=[pscustomobject]@{UserId='SYSTEM';RunLevel='Highest'};State='Ready'},
            [pscustomobject]@{TaskPath='\';TaskName='TimerResolution_0_5110ms';Actions=@([pscustomobject]@{Execute='powershell.exe';Arguments=('-File "'+$taskRunner+'" -Desired100ns 5110')});Settings=[pscustomobject]@{Enabled=$true};Principal=[pscustomobject]@{UserId='SYSTEM';RunLevel='Highest'};State='Running'},
            [pscustomobject]@{TaskPath='\';TaskName='TimerResolution multiple actions';Actions=@([pscustomobject]@{ClassId='QA'},[pscustomobject]@{Execute='powershell.exe';Arguments=('-File "'+$taskRunner+'" -Desired100ns 5110')});Settings=[pscustomobject]@{Enabled=$true};Principal=[pscustomobject]@{UserId='SYSTEM';RunLevel='Highest'};State='Ready'}
        )
    }
    $tasks=@(Get-GsbTimerTaskInventory)
    Check ($tasks.Count -eq 2 -and $tasks[0].Target100ns -eq 5110) 'Task inventory tolerates unrelated and mixed COM-handler actions'
    Remove-Item Function:Get-ScheduledTask
    function Get-CimInstance {
        @(
            [pscustomobject]@{Name='SetTimerResolution.exe';ProcessId=50;SessionId=0;CommandLine=$null;ExecutablePath=$null},
            [pscustomobject]@{Name='powershell.exe';ProcessId=51;SessionId=0;CommandLine=$null;ExecutablePath=$null},
            [pscustomobject]@{Name='unrelated.exe';ProcessId=52;SessionId=0;CommandLine=$null;ExecutablePath=$null}
        )
    }
    $processRows=@(Get-GsbTimerProcessInventory)
    Check ($processRows.Count -eq 2 -and $processRows[0].Recognition -eq 'Known launcher' -and -not $processRows[0].CommandLineVisible -and $processRows[1].Recognition -eq 'Uninspectable PowerShell process') 'Unreadable process arguments preserve dedicated launcher identity and unknown PowerShell visibility'
    Remove-Item Function:Get-CimInstance
    $linked=New-Inventory;$linked.IsAdmin=$false;$linked.Processes=@($processRows[1]);$linked.Managed=@(New-Managed)
    $linked.Managed[0].Holder.State | Add-Member -NotePropertyName ProcessId -NotePropertyValue 51
    $linkedResult=New-GsbTimerStartupAssessment $linked
    Check ($linkedResult.Status -eq 'UNKNOWN' -and $linkedResult.KnownTimerProcessCount -eq 1 -and $linkedResult.Processes[0].Recognition -eq 'Verified GSB holder' -and -not $linkedResult.Processes[0].CommandLineVisible) 'Verified GSB state identifies its own hidden process without claiming complete visibility'
    $json=$result | ConvertTo-Json -Depth 10 | ConvertFrom-Json
    Check ($json.Issues -is [array] -and $json.StartupEntries -is [array] -and $json.Processes -is [array] -and $json.Managed -is [array]) 'Diagnostic collection fields stay JSON arrays for zero and one items'
    $inventory=New-Inventory;$inventory.StartupEntries=@($gsb);$inventory.Managed=@(New-Managed)
    $inventory.StartupEntries[0].Enabled=$false;$inventory.StartupEntries[0].State='Running'
    $result=New-GsbTimerStartupAssessment $inventory
    Check ($result.ActiveStartupCount -eq 1) 'Disabled task with a still-running instance is not treated as inactive'
    $text=Get-Content -LiteralPath (Join-Path $source 'TimerStartupDiagnostics.ps1') -Raw
    $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseInput($text,[ref]$tokens,[ref]$errors)
    $writes=@($ast.FindAll({param($node) $node -is [Management.Automation.Language.CommandAst] -and $node.GetCommandName() -match '^(?:Start|Stop|Enable|Disable|Unregister|Register)-ScheduledTask$|^Stop-Process$|^(?:Set|Remove|New)-ItemProperty$|^Set-GsbProcessTimerPolicy$'},$true))
    Check ($errors.Count -eq 0 -and $writes.Count -eq 0 -and $text -notmatch '\]::NtSetTimerResolution\(') 'Checker contains no timer request, policy write, task mutation or process-stop operation'
}
finally {
    if($EvidenceDirectory){New-Item -ItemType Directory -Path $EvidenceDirectory -Force | Out-Null; $checks | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $EvidenceDirectory 'timer-startup-diagnostics-tests.json') -Encoding UTF8}
}
