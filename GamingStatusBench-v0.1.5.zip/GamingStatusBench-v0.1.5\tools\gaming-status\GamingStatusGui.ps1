[CmdletBinding()]
param(
    [string]$OutputDir = "",
    [switch]$NoShow,
    [string]$SampleReportPath = "",
    [string]$TimerStateDirectory = "",
    [string]$StartupPath = "",
    [ValidateRange(1,10000000)][uint32]$TimerTarget100ns = 5070,
    [ValidateSet('Overview','Timer','CPU','USB','Network','Display/GPU','Power/Game','Logs','Report JSON')][string]$InitialSection = 'Overview'
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = "Continue"

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$script:CollectorPath = Join-Path $PSScriptRoot "GamingStatus.ps1"
$script:GuiScriptPath = $PSCommandPath
$script:InitialSamplePath = $SampleReportPath
if (-not $OutputDir) {
    $OutputDir = Join-Path $PSScriptRoot "..\..\reports"
}
$script:OutputDir = [System.IO.Path]::GetFullPath($OutputDir)
$script:LastJsonPath = $null
$script:LastHtmlPath = $null
$script:LastReport = $null
$script:IsRunning = $false
$script:ScanTimer = $null
$script:TimerHoldActive = $false
$script:TimerHoldCurrentMs = $null
$script:ProcessTimerPolicyApplied = $false
$script:ProcessTimerPolicyError = $null
$script:CpuSet16Button = $null
$script:CpuRestoreButton = $null
$script:CopyCpuFixButton = $null

if (-not (Test-Path $script:OutputDir)) {
    New-Item -ItemType Directory -Path $script:OutputDir -Force | Out-Null
}

function Test-IsAdmin {
    try {
        $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object Security.Principal.WindowsPrincipal($identity)
        return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    }
    catch {
        return $false
    }
}

function Quote-Arg {
    param([string]$Value)
    ConvertTo-GsbProcessArgument $Value
}

function Get-StatusColor {
    param([string]$Status)
    switch ($Status) {
        "OK" { return [Drawing.Color]::FromArgb(64, 224, 126) }
        "WARN" { return [Drawing.Color]::FromArgb(247, 199, 91) }
        "FAIL" { return [Drawing.Color]::FromArgb(255, 94, 94) }
        "INFO" { return [Drawing.Color]::FromArgb(99, 208, 255) }
        default { return [Drawing.Color]::FromArgb(190, 176, 255) }
    }
}

function Set-FlatButtonStyle {
    param(
        [System.Windows.Forms.Button]$Button,
        [Drawing.Color]$Accent
    )
    $Button.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $Button.FlatAppearance.BorderColor = $Accent
    $Button.FlatAppearance.MouseOverBackColor = [Drawing.Color]::FromArgb(28, 44, 38)
    $Button.FlatAppearance.MouseDownBackColor = [Drawing.Color]::FromArgb(42, 68, 55)
    $Button.BackColor = [Drawing.Color]::FromArgb(10, 14, 13)
    $Button.ForeColor = $Accent
    $Button.Font = New-Object Drawing.Font("Consolas", 9.5, [Drawing.FontStyle]::Bold)
    $Button.Height = 34
}

function Write-TerminalLog {
    param(
        [string]$Text,
        [Drawing.Color]$Color = [Drawing.Color]::FromArgb(170, 244, 198)
    )

    if ($null -eq $script:LogBox) { return }
    $script:LogBox.SelectionStart = $script:LogBox.TextLength
    $script:LogBox.SelectionLength = 0
    $script:LogBox.SelectionColor = $Color
    $script:LogBox.AppendText("[$((Get-Date).ToString('HH:mm:ss'))] $Text`r`n")
    $script:LogBox.SelectionColor = $script:LogBox.ForeColor
    $script:LogBox.ScrollToCaret()
}

function Get-GameExePathsFromText {
    param([string]$Text)

    $items = @()
    foreach ($part in ($Text -split "[`r`n;]+")) {
        $trimmed = $part.Trim()
        if ($trimmed) {
            $items += $trimmed
        }
    }
    return $items
}

function Get-PingTargetsFromText {
    param([string]$Text)

    $items = @()
    foreach ($part in ($Text -split "[,;`r`n ]+")) {
        $trimmed = $part.Trim()
        if ($trimmed) {
            $items += $trimmed
        }
    }
    return $items
}

function Get-GamePingProfileFromText {
    param([string]$Text)

    $trimmed = ([string]$Text).Trim()
    if (-not $trimmed -or $trimmed -eq "none") {
        return @()
    }
    return @($trimmed -split "[,;`r`n]+" | ForEach-Object { $_.Trim() } | Where-Object { $_ })
}

function Get-LatestReportJson {
    $latest = Get-ChildItem -Path $script:OutputDir -Filter "gaming-status-*.json" -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime |
        Select-Object -Last 1
    if ($latest) { return $latest.FullName }
    return $null
}

function Open-Path {
    param([string]$Path)
    if ($Path -and (Test-Path $Path)) {
        Start-Process $Path
    }
}

function Get-JsonValue {
    param(
        [object]$Object,
        [string[]]$Path
    )

    $current = $Object
    foreach ($part in $Path) {
        if ($null -eq $current) { return $null }
        $prop = $current.PSObject.Properties[$part]
        if ($null -eq $prop) { return $null }
        $current = $prop.Value
    }
    return $current
}

function Get-ObjectsWithProperty {
    param(
        [object]$Value,
        [string]$PropertyName
    )

    return @($Value | Where-Object {
        $null -ne $_ -and $null -ne $_.PSObject.Properties[$PropertyName]
    })
}

function Set-SummaryLabel {
    param(
        [System.Windows.Forms.Label]$Label,
        [string]$Text,
        [string]$Status
    )
    $Label.Text = $Text
    $Label.ForeColor = Get-StatusColor $Status
}

function Start-GuiScan {
    param([switch]$SkipNetwork)
    if ($script:IsRunning -or $script:IsBusy) { return }
    if (-not (Test-Path $script:CollectorPath)) {
        [System.Windows.Forms.MessageBox]::Show("Collector not found:`n$script:CollectorPath", "Gaming Status Bench", "OK", "Error") | Out-Null
        return
    }

    $script:IsRunning = $true
    Set-GuiMeasurementsStale
    Set-ScanControlsEnabled $false
    $script:StatusLabel.Text = "SCAN RUNNING"
    $script:StatusLabel.ForeColor = [Drawing.Color]::FromArgb(247, 199, 91)
    Write-TerminalLog "scan started"
    $script:ActionStatus.Text = 'Running: collecting diagnostics. Wake probes request their own 0.5 ms timer.'
    $script:ActionStatus.ForeColor = Get-StatusColor 'INFO'
    $previousFiles = @{}
    foreach ($file in @(Get-ChildItem -LiteralPath $script:OutputDir -Filter 'gaming-status-*.json')) { $previousFiles[$file.FullName] = $file.LastWriteTimeUtc.Ticks }

    $gamePaths = @(Get-GameExePathsFromText $script:GameExeBox.Text)
    $pingTargets = @(Get-PingTargetsFromText $script:PingTargetBox.Text)
    $gamePingProfiles = @(Get-GamePingProfileFromText $script:GamePingProfileBox.Text)
    $pingCount = [int]$script:PingCountBox.Value
    $timerSamples = [int]$script:TimerSamplesBox.Value
    $networkEnabled = $script:NetworkBox.Checked -and -not $SkipNetwork

    $procArgs = @(
        "-NoProfile",
        "-ExecutionPolicy", "Bypass",
        "-File", (Quote-Arg $script:CollectorPath),
        "-OutputDir", (Quote-Arg $script:OutputDir),
        "-PingCount", $pingCount,
        "-TimerSampleCount", $timerSamples,
        "-Quiet"
    )

    if (-not $networkEnabled) {
        $procArgs += "-NoNetworkBenchmark"
    }

    if ($pingTargets.Count -gt 0) {
        $procArgs += "-PingTarget"
        $procArgs += (Quote-Arg ($pingTargets -join ","))
    }

    if ($gamePingProfiles.Count -gt 0) {
        $procArgs += "-GamePingProfile"
        $procArgs += (Quote-Arg ($gamePingProfiles -join ","))
    }

    if ($gamePaths.Count -gt 0) {
        $procArgs += "-GameExePath"
        $procArgs += (Quote-Arg ($gamePaths -join ";"))
    }

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = "powershell.exe"
    $psi.Arguments = ($procArgs -join " ")
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true

    try {
        $process = [Diagnostics.Process]::Start($psi)
    }
    catch {
        $script:IsRunning = $false
        Set-ScanControlsEnabled $true
        $script:StatusLabel.Text = "SCAN ERROR"
        $script:StatusLabel.ForeColor = Get-StatusColor "FAIL"
        $script:ActionStatus.Text = "Failed: scan could not start. $($_.Exception.Message)"
        $script:ActionStatus.ForeColor = Get-StatusColor 'FAIL'
        Write-TerminalLog "failed to start scan: $($_.Exception.Message)" (Get-StatusColor "FAIL")
        return
    }

    Write-TerminalLog "process started pid=$($process.Id)"

    $script:ScanTimer = New-Object System.Windows.Forms.Timer
    $script:ScanTimer.Interval = 350
    $script:ScanTimer.Tag = [pscustomobject]@{
        Process = $process
        StdOut = $process.StandardOutput.ReadToEndAsync()
        StdErr = $process.StandardError.ReadToEndAsync()
        PreviousFiles = $previousFiles
        CommandLine = "powershell.exe $($psi.Arguments)"
        Tick = 0
        Started = Get-Date
        TimedOut = $false
        TimeoutSeconds = 120
    }
    $script:ScanTimer.Add_Tick({
        param($sender, $eventArgs)

        $state = $sender.Tag
        $state.Tick = [int]$state.Tick + 1
        if (($state.Tick % 6) -eq 0) {
            $script:StatusLabel.Text = "SCAN RUNNING" + ("." * (($state.Tick / 6) % 4))
        }

        if (-not $state.Process.HasExited) {
            $elapsed = ((Get-Date) - $state.Started).TotalSeconds
            if ($elapsed -gt $state.TimeoutSeconds -and -not $state.TimedOut) {
                $state.TimedOut = $true
                Write-TerminalLog "scan timeout after $([int]$elapsed)s; stopping collector pid=$($state.Process.Id)" (Get-StatusColor "WARN")
                try {
                    $state.Process.Kill()
                }
                catch {
                    Write-TerminalLog "could not stop collector: $($_.Exception.Message)" (Get-StatusColor "WARN")
                }
            }
            return
        }

        $sender.Stop()
        $sender.Dispose()
        $script:ScanTimer = $null

        $state.Process.WaitForExit()
        $stdout = $state.StdOut.Result
        $stderr = $state.StdErr.Result
        $exitCode = $state.Process.ExitCode
        $state.Process.Dispose()

        $script:IsRunning = $false
        Set-ScanControlsEnabled $true

        Write-TerminalLog "command: $($state.CommandLine)" ([Drawing.Color]::FromArgb(112, 210, 160))
        if ($stdout.Trim()) {
            foreach ($line in ($stdout -split "`r?`n")) {
                if ($line.Trim()) { Write-TerminalLog $line ([Drawing.Color]::FromArgb(170, 244, 198)) }
            }
        }
        if ($stderr.Trim()) {
            foreach ($line in ($stderr -split "`r?`n")) {
                if ($line.Trim()) { Write-TerminalLog $line (Get-StatusColor "WARN") }
            }
        }

        if ($state.TimedOut) {
            $script:StatusLabel.Text = "SCAN TIMEOUT"
            $script:StatusLabel.ForeColor = Get-StatusColor "WARN"
        }
        elseif ($exitCode -ne 0) {
            $script:StatusLabel.Text = "SCAN EXIT $exitCode"
            $script:StatusLabel.ForeColor = Get-StatusColor "WARN"
        }
        else {
            $script:StatusLabel.Text = "VERIFYING REPORT"
            $script:StatusLabel.ForeColor = Get-StatusColor "INFO"
        }

        $jsonPath = Get-LatestReportJson
        $newReport = $false
        if ($jsonPath -and (Test-Path -LiteralPath $jsonPath)) {
            $file = Get-Item -LiteralPath $jsonPath
            $newReport = (-not $state.PreviousFiles.ContainsKey($jsonPath)) -or $file.LastWriteTimeUtc.Ticks -gt $state.PreviousFiles[$jsonPath]
        }
        if (-not $state.TimedOut -and $exitCode -eq 0 -and $newReport) {
            try {
                $report = Get-Content -Path $jsonPath -Raw | ConvertFrom-Json
                if ($report.Tool -ne 'GamingStatusBench' -or -not $report.Findings -or -not $report.Sections) { throw 'Report is incomplete or invalid.' }
                Update-ReportView $report
                $script:StatusLabel.Text = 'SCAN COMPLETE'
                $script:StatusLabel.ForeColor = Get-StatusColor 'OK'
                $script:ActionStatus.Text = 'Verified: new diagnostics report loaded. Game FPS/input latency was not measured.'
                $script:ActionStatus.ForeColor = Get-StatusColor 'OK'
                Write-TerminalLog "report loaded: $jsonPath" (Get-StatusColor "OK")
            }
            catch {
                Write-TerminalLog "could not load JSON report: $($_.Exception.Message)" (Get-StatusColor "WARN")
                $script:StatusLabel.Text = 'REPORT ERROR'
                $script:StatusLabel.ForeColor = Get-StatusColor 'FAIL'
                $script:ActionStatus.Text = "Failed: report validation. $($_.Exception.Message)"
                $script:ActionStatus.ForeColor = Get-StatusColor 'FAIL'
            }
        }
        else {
            $script:ActionStatus.Text = 'Failed: no verified new report. Previous measurements remain stale.'
            $script:ActionStatus.ForeColor = Get-StatusColor 'FAIL'
            if ($exitCode -eq 0 -and -not $state.TimedOut) { $script:StatusLabel.Text = 'REPORT MISSING'; $script:StatusLabel.ForeColor = Get-StatusColor 'FAIL' }
            Write-TerminalLog $script:ActionStatus.Text (Get-StatusColor "WARN")
        }
    })

    $script:ScanTimer.Start()
}

function Get-GuiRelaunchArguments {
    $directory = (Get-GsbTimerPaths $script:TimerStateDirectory).Root
    $arguments = @('-NoProfile','-ExecutionPolicy','Bypass','-File',(Quote-Arg $script:GuiScriptPath),
        '-OutputDir',(Quote-Arg $script:OutputDir),'-TimerStateDirectory',(Quote-Arg $directory),
        '-TimerTarget100ns',[string]$script:TimerTarget.Value,'-InitialSection',(Quote-Arg ([string]$script:Navigation.SelectedItem)))
    if ($script:UserStartupPathOverride) { $arguments += @('-StartupPath',(Quote-Arg $script:UserStartupPathOverride)) }
    $report = if ($script:LastJsonPath -and (Test-Path -LiteralPath $script:LastJsonPath -PathType Leaf)) { $script:LastJsonPath } else { $script:InitialSamplePath }
    if ($report) { $arguments += @('-SampleReportPath',(Quote-Arg ([IO.Path]::GetFullPath($report)))) }
    $arguments -join ' '
}

function Restart-AsAdmin {
    $adminArgs = Get-GuiRelaunchArguments
    try {
        Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') -ArgumentList $adminArgs -Verb RunAs -ErrorAction Stop
    }
    catch {
        if ($_.Exception -is [ComponentModel.Win32Exception] -and $_.Exception.NativeErrorCode -eq 1223) { return New-GuiResult 'Administrator restart cancelled. Current window remains open.' 'Cancelled' }
        throw
    }
    $script:AdminRelaunched = $true
    New-GuiResult 'Elevated window launch requested. Check the new window for its actual privilege state.' 'Review'
}

function Copy-Summary {
    $lines = @(
        "Gaming Status Bench",
        $script:MeasurementStatus.Text,
        $script:HostLabel.Text,
        $script:TimerLabel.Text,
        $script:DisplayLabel.Text,
        $script:NetworkLabel.Text,
        $script:OkLabel.Text,
        $script:WarnLabel.Text,
        $script:FailLabel.Text,
        $script:InfoLabel.Text,
        $script:UnknownLabel.Text,
        "JSON: $script:LastJsonPath",
        "HTML: $script:LastHtmlPath"
    )
    Set-VerifiedGuiClipboardText ($lines -join "`r`n")
    Write-TerminalLog "summary copied to clipboard"
}

function Get-CpuSolverValue {
    param(
        [object]$Report,
        [string]$Name
    )

    return Get-JsonValue $Report @("Sections", "CpuScheduler", $Name)
}

function Get-CpuSolverStateText {
    param([object]$Report)

    if ($null -eq $Report) {
        return "No report loaded. Run a scan first."
    }

    $cpuName = Get-CpuSolverValue $Report "CpuName"
    $cpuProfile = Get-CpuSolverValue $Report "CpuModelProfile"
    $visible = Get-CpuSolverValue $Report "VisibleLogicalProcessors"
    $expected = Get-CpuSolverValue $Report "ExpectedLogicalProcessors"
    $visibleThreadsPerCore = Get-CpuSolverValue $Report "VisibleThreadsPerCore"
    $expectedThreadsPerCore = Get-CpuSolverValue $Report "ExpectedThreadsPerCore"
    $smtState = Get-CpuSolverValue $Report "SmtState"
    $smtConfidence = Get-CpuSolverValue $Report "SmtConfidence"
    $smtRecommendation = Get-CpuSolverValue $Report "SmtRecommendation"
    $cores = Get-CpuSolverValue $Report "PhysicalCores"
    $expectedCores = Get-CpuSolverValue $Report "ExpectedPhysicalCores"
    $ccdCount = Get-CpuSolverValue $Report "CcdCount"
    $coresPerCcd = Get-CpuSolverValue $Report "CoresPerCcd"
    $bcdActive = Get-CpuSolverValue $Report "BcdNumProcActive"
    $bcdNumProc = Get-CpuSolverValue $Report "BcdNumProc"
    $setAllowed = Get-CpuSolverValue $Report "Set16Allowed"
    $blocked = Get-CpuSolverValue $Report "Set16BlockedReason"
    $restoreAllowed = Get-CpuSolverValue $Report "RestoreAllowed"
    $recommendation = Get-CpuSolverValue $Report "SolverRecommendation"

    return @(
        "CPU: $cpuName",
        "CPU profile: $cpuProfile",
        "Physical cores: $cores",
        "Expected physical cores: $expectedCores",
        "CCD layout: $ccdCount CCD(s), $coresPerCcd core(s) per CCD",
        "Visible logical processors: $visible",
        "Expected logical processors: $expected",
        "Visible threads/core: $visibleThreadsPerCore",
        "Expected threads/core: $expectedThreadsPerCore",
        "SMT/HT state: $smtState ($smtConfidence)",
        "SMT/HT recommendation: $smtRecommendation",
        "BCD numproc active: $bcdActive",
        "BCD numproc: $bcdNumProc",
        "CPU SET 16 allowed: $setAllowed",
        "Set block/allow reason: $blocked",
        "CPU RESTORE allowed: $restoreAllowed",
        "Recommendation: $recommendation"
    ) -join "`r`n"
}

function Get-PowerSettingRegistryRows {
    $base = "HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings"
    $rows = @()

    foreach ($subgroup in @(Get-ChildItem -Path $base -ErrorAction Stop)) {
        foreach ($setting in @(Get-ChildItem -Path $subgroup.PSPath -ErrorAction SilentlyContinue)) {
            $props = Get-ItemProperty -Path $setting.PSPath -ErrorAction SilentlyContinue
            if ($null -eq $props -or $null -eq $props.PSObject.Properties["Attributes"]) { continue }
            $attributes = [int]$props.PSObject.Properties["Attributes"].Value
            $friendlyProp = $props.PSObject.Properties["FriendlyName"]
            $rows += [pscustomobject]@{
                Path = $setting.PSPath
                SubgroupGuid = $subgroup.PSChildName
                SettingGuid = $setting.PSChildName
                FriendlyName = if ($friendlyProp) { [string]$friendlyProp.Value } else { "" }
                Attributes = $attributes
                Hidden = (($attributes -band 1) -ne 0)
            }
        }
    }

    return $rows
}

function Get-UsbDeviceIdentityRows {
    $rows = @()

    foreach ($className in @("Win32_USBController", "Win32_USBHub")) {
        try {
            foreach ($device in @(Get-CimInstance -ClassName $className -ErrorAction Stop)) {
                if (-not $device.PNPDeviceID) { continue }
                $rows += [pscustomobject]@{
                    PNPDeviceID = [string]$device.PNPDeviceID
                    Name = [string]$device.Name
                    SourceClass = $className
                }
            }
        }
        catch {
        }
    }

    try {
        foreach ($device in @(Get-CimInstance -ClassName Win32_PnPEntity -ErrorAction Stop | Where-Object { $_.PNPDeviceID -like "USB*" -or $_.PNPClass -eq "USB" })) {
            if (-not $device.PNPDeviceID) { continue }
            $rows += [pscustomobject]@{
                PNPDeviceID = [string]$device.PNPDeviceID
                Name = [string]$device.Name
                SourceClass = "Win32_PnPEntity"
            }
        }
    }
    catch {
    }

    $deduped = @{}
    foreach ($row in $rows) {
        if (-not $deduped.ContainsKey($row.PNPDeviceID)) {
            $deduped[$row.PNPDeviceID] = $row
        }
    }

    return @($deduped.Values | Sort-Object PNPDeviceID)
}

function Convert-UsbPowerRegistryValueToText {
    param([object]$Value)

    if ($null -eq $Value) { return "" }
    if ($Value -is [array]) { return (($Value | ForEach-Object { [string]$_ }) -join ",") }
    return [string]$Value
}

function Test-UsbPowerRegistryValueEnabled {
    param([object]$Value)

    if ($null -eq $Value) { return $false }
    if ($Value -is [array]) {
        foreach ($item in $Value) {
            if ([int]$item -ne 0) { return $true }
        }
        return $false
    }

    try { return ([int]$Value -ne 0) } catch { return $false }
}

function Get-UsbPowerRegistryRows {
    $roots = @(
        "HKLM:\SYSTEM\CurrentControlSet\Enum\USB",
        "HKLM:\SYSTEM\CurrentControlSet\Enum\USB4",
        "HKLM:\SYSTEM\CurrentControlSet\Enum\USBSTOR",
        "HKLM:\SYSTEM\CurrentControlSet\Enum\HID"
    )
    $valueNames = @(
        "EnhancedPowerManagementEnabled",
        "AllowIdleIrpInD3",
        "DeviceSelectiveSuspended",
        "SelectiveSuspendEnabled",
        "SelectiveSuspendOn",
        "EnableSelectiveSuspend"
    )
    $rows = @()

    foreach ($root in $roots) {
        if (-not (Test-Path -LiteralPath $root)) { continue }
        foreach ($key in @(Get-ChildItem -LiteralPath $root -Recurse -ErrorAction SilentlyContinue | Where-Object { $_.PSChildName -eq "Device Parameters" })) {
            $props = Get-ItemProperty -LiteralPath $key.PSPath -ErrorAction SilentlyContinue
            if ($null -eq $props) { continue }

            foreach ($name in $valueNames) {
                $prop = $props.PSObject.Properties[$name]
                if ($null -eq $prop) { continue }
                $value = $prop.Value
                $rows += [pscustomobject]@{
                    Backend = "Registry"
                    RegistryPath = $key.PSPath
                    DisplayPath = $key.Name
                    DeviceName = ($key.Name -replace "^HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Enum\\", "")
                    Name = $name
                    Value = Convert-UsbPowerRegistryValueToText -Value $value
                    Enable = (Test-UsbPowerRegistryValueEnabled -Value $value)
                    TargetValue = 0
                }
            }
        }
    }

    return @($rows | Sort-Object Enable, Name, DisplayPath)
}

function Get-UsbPowerSavingRows {
    $usbDevices = @(Get-UsbDeviceIdentityRows)
    $rows = @()

    try {
        $powerEntries = @(Get-WmiObject MSPower_DeviceEnable -Namespace root\wmi -ErrorAction Stop)
        foreach ($powerEntry in $powerEntries) {
            $instanceName = [string]$powerEntry.InstanceName
            if (-not $instanceName) { continue }
            $instanceUpper = $instanceName.ToUpperInvariant()
            $matchedDevice = $null

            foreach ($usbDevice in $usbDevices) {
                $pnp = [string]$usbDevice.PNPDeviceID
                if (-not $pnp) { continue }
                if ($instanceUpper.Contains($pnp.ToUpperInvariant())) {
                    $matchedDevice = $usbDevice
                    break
                }
            }

            if ($null -eq $matchedDevice) { continue }

            $rows += [pscustomobject]@{
                Backend = "WMI"
                PowerEntry = $powerEntry
                DeviceName = $matchedDevice.Name
                PNPDeviceID = $matchedDevice.PNPDeviceID
                SourceClass = $matchedDevice.SourceClass
                InstanceName = $instanceName
                Enable = [bool]$powerEntry.Enable
            }
        }
    }
    catch {
        Write-TerminalLog "USB MSPower_DeviceEnable read failed, using registry fallback: $($_.Exception.Message)" (Get-StatusColor "WARN")
    }

    try {
        $rows += @(Get-UsbPowerRegistryRows)
    }
    catch {
        Write-TerminalLog "USB registry power read failed: $($_.Exception.Message)" (Get-StatusColor "WARN")
    }

    return @($rows | Sort-Object Enable, DeviceName, InstanceName)
}

. (Join-Path $PSScriptRoot "TimerRuntime.ps1")
. (Join-Path $PSScriptRoot 'TimerStartupDiagnostics.ps1')
. (Join-Path $PSScriptRoot "GuiActions.ps1")
. (Join-Path $PSScriptRoot "GuiWorkspace.ps1")
