Set-StrictMode -Version 2.0

function Initialize-GsbTimerNative {
    if ('GsbTimerNative' -as [type]) { return }
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
[StructLayout(LayoutKind.Sequential)]
public struct GsbPowerPolicy { public uint Version, ControlMask, StateMask; }
[StructLayout(LayoutKind.Sequential)]
public struct GsbLuid { public uint LowPart; public int HighPart; }
[StructLayout(LayoutKind.Sequential)]
public struct GsbTokenStatistics {
    public GsbLuid TokenId, AuthenticationId;
    public long ExpirationTime;
    public int TokenType, ImpersonationLevel;
    public uint DynamicCharged, DynamicAvailable, GroupCount, PrivilegeCount;
    public GsbLuid ModifiedId;
}
public static class GsbTimerNative {
    [DllImport("ntdll.dll")] public static extern int NtQueryTimerResolution(out uint maximum, out uint minimum, out uint current);
    [DllImport("ntdll.dll")] public static extern int NtSetTimerResolution(uint desired, bool set, out uint current);
    [DllImport("kernel32.dll")] public static extern IntPtr GetCurrentProcess();
    [DllImport("kernel32.dll", SetLastError=true)] public static extern bool SetProcessInformation(IntPtr process, int kind, ref GsbPowerPolicy policy, int size);
    [DllImport("kernel32.dll", SetLastError=true)] public static extern bool GetProcessInformation(IntPtr process, int kind, ref GsbPowerPolicy policy, int size);
    [DllImport("advapi32.dll", SetLastError=true)] public static extern bool GetTokenInformation(IntPtr token, int kind, out GsbTokenStatistics statistics, uint size, out uint returnedSize);
}
'@ -ErrorAction Stop
}

function Get-GsbLogonIdentity {
    Initialize-GsbTimerNative
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    try {
        $statistics = New-Object GsbTokenStatistics
        [uint32]$returned = 0
        [uint32]$size = [Runtime.InteropServices.Marshal]::SizeOf([type][GsbTokenStatistics])
        if (-not [GsbTimerNative]::GetTokenInformation($identity.Token,10,[ref]$statistics,$size,[ref]$returned)) {
            throw "Token statistics query failed: Win32 $([Runtime.InteropServices.Marshal]::GetLastWin32Error())"
        }
        $id = ([uint64]([uint32]$statistics.AuthenticationId.HighPart) -shl 32) -bor [uint64]$statistics.AuthenticationId.LowPart
        [pscustomobject]@{ UserSid=$identity.User.Value; LogonId=$id.ToString(); SessionId=(Get-Process -Id $PID).SessionId }
    }
    finally { $identity.Dispose() }
}

function Get-GsbTimerResolution {
    Initialize-GsbTimerNative
    [uint32]$coarse = 0; [uint32]$fine = 0; [uint32]$current = 0
    $status = [GsbTimerNative]::NtQueryTimerResolution([ref]$coarse, [ref]$fine, [ref]$current)
    if ($status -ne 0) { throw "NtQueryTimerResolution failed: $status" }
    [pscustomobject]@{ Lowest100ns = $fine; Highest100ns = $coarse; Current100ns = $current; CurrentMs = $current / 10000.0 }
}

function Set-GsbProcessTimerPolicy {
    Initialize-GsbTimerNative
    $policy = New-Object GsbPowerPolicy
    $policy.Version = 1; $policy.ControlMask = 4; $policy.StateMask = 0
    $size = [Runtime.InteropServices.Marshal]::SizeOf([type][GsbPowerPolicy])
    $handle = [GsbTimerNative]::GetCurrentProcess()
    if (-not [GsbTimerNative]::SetProcessInformation($handle, 4, [ref]$policy, $size)) {
        throw "SetProcessInformation failed: Win32 $([Runtime.InteropServices.Marshal]::GetLastWin32Error())"
    }
    $verify = New-Object GsbPowerPolicy
    $verify.Version = 1
    if (-not [GsbTimerNative]::GetProcessInformation($handle, 4, [ref]$verify, $size)) {
        throw "GetProcessInformation failed: Win32 $([Runtime.InteropServices.Marshal]::GetLastWin32Error())"
    }
    if (($verify.ControlMask -band 4) -eq 0 -or ($verify.StateMask -band 4) -ne 0) {
        throw 'Process timer policy did not verify.'
    }
    return $true
}

function ConvertTo-GsbProcessArgument {
    param([string]$Value)
    # Windows argv parsing doubles quote-adjacent and trailing backslashes.
    $escaped = [regex]::Replace($Value, '(\\*)"', '$1$1\"')
    $escaped = [regex]::Replace($escaped, '(\\+)$', '$1$1')
    '"' + $escaped + '"'
}

function Get-GsbTimerPaths {
    param([string]$StateDirectory = '')
    $machineRoot = Join-Path $env:ProgramData 'GamingStatusBench\TimerMachine'
    if (-not $StateDirectory) {
        $StateDirectory = if (Test-Path -LiteralPath (Join-Path $machineRoot 'config.json')) { $machineRoot } else { Join-Path $env:LOCALAPPDATA 'GamingStatusBench\Timer' }
    }
    $root = [IO.Path]::GetFullPath($StateDirectory)
    # Directory aliases must share singleton and stop-event keys.
    if ($root -ne [IO.Path]::GetPathRoot($root)) { $root = $root.TrimEnd([char[]]@('\','/')) }
    $machine = $root.TrimEnd('\') -eq [IO.Path]::GetFullPath($machineRoot).TrimEnd('\')
    $hash = [Security.Cryptography.SHA256]::Create()
    try { $key = ([BitConverter]::ToString($hash.ComputeHash([Text.Encoding]::UTF8.GetBytes($root.ToLowerInvariant())))).Replace('-', '').Substring(0, 24) }
    finally { $hash.Dispose() }
    $sid = if ($machine) { 'Machine' } else { [Security.Principal.WindowsIdentity]::GetCurrent().User.Value }
    $space = if ($machine) { 'Global' } else { 'Local' }
    [pscustomobject]@{
        Root = $root
        Machine = $machine
        State = Join-Path $root $(if ($machine) { 'state\state.json' } else { 'state.json' })
        ErrorLog = Join-Path $root $(if ($machine) { 'state\startup-error.txt' } else { 'startup-error.txt' })
        Config = Join-Path $root 'config.json'
        Holder = Join-Path $root 'TimerHolder.ps1'
        Runtime = Join-Path $root 'TimerRuntime.ps1'
        Startup = $(if ($machine) { $null } else { Join-Path ([Environment]::GetFolderPath('Startup')) 'GamingStatusBench-Timer.bat' })
        Mutex = "$space\GSB.Timer.$sid.$key"
        StopEvent = "$space\GSB.Timer.Stop.$sid.$key"
    }
}

function Write-GsbTimerJson {
    param([string]$Path, [object]$Value)
    $temp = "$Path.$PID.tmp"
    try {
        [IO.File]::WriteAllText($temp, ($Value | ConvertTo-Json -Depth 8), (New-Object Text.UTF8Encoding($false)))
        if ([IO.File]::Exists($Path)) { [IO.File]::Replace($temp, $Path, "$Path.previous") }
        else { [IO.File]::Move($temp, $Path) }
    }
    finally {
        if ([IO.File]::Exists($temp)) { [IO.File]::Delete($temp) }
        if ([IO.File]::Exists("$Path.previous")) { [IO.File]::Delete("$Path.previous") }
    }
}

function Assert-GsbTimerTarget {
    param([uint32]$Target100ns)
    $limits = Get-GsbTimerResolution
    if ($Target100ns -lt $limits.Lowest100ns -or $Target100ns -gt $limits.Highest100ns) {
        throw "Target $Target100ns is outside the supported range $($limits.Lowest100ns)-$($limits.Highest100ns) (100 ns units)."
    }
}

function Get-GsbTimerHolderState {
    param([string]$StateDirectory = '')
    $paths = Get-GsbTimerPaths $StateDirectory
    if (-not (Test-Path -LiteralPath $paths.State)) {
        $errorText = if (Test-Path -LiteralPath $paths.ErrorLog) { [IO.File]::ReadAllText($paths.ErrorLog) } else { '' }
        return [pscustomobject]@{ Running = $false; State = $null; Error = $errorText; RetryAllowed = $true }
    }
    try {
        $state = Get-Content -LiteralPath $paths.State -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
        $process = Get-Process -Id $state.ProcessId -ErrorAction SilentlyContinue
        $alive = $false
        if ($null -ne $process) {
            try { $alive = $process.StartTime.ToUniversalTime().Ticks.ToString() -eq $state.ProcessStartTicks -and $process.SessionId -eq $state.SessionId }
            catch {
                if ($null -ne $state.PSObject.Properties['ProcessCreationUtc']) {
                    $cim = Get-CimInstance Win32_Process -Filter "ProcessId=$($state.ProcessId)" -ErrorAction Stop
                    $alive = $null -ne $cim -and $cim.CreationDate.ToUniversalTime().ToString('o') -eq $state.ProcessCreationUtc -and $cim.SessionId -eq $state.SessionId
                }
            }
        }
        $fresh = ([DateTime]::UtcNow - [DateTime]::Parse($state.HeartbeatUtc).ToUniversalTime()).TotalSeconds -lt 5
        $errorText = if ($alive -and -not $fresh) { 'Holder heartbeat is stale; state is unverified.' } elseif ($state.Status -eq 'Error') { $state.Error } elseif (-not $alive -and (Test-Path -LiteralPath $paths.ErrorLog)) { [IO.File]::ReadAllText($paths.ErrorLog) } else { '' }
        [pscustomobject]@{ Running = ($alive -and $fresh -and $state.Status -eq 'Running'); State = $state; Error = $errorText; RetryAllowed = (-not $alive -and [bool]$errorText) }
    }
    catch { [pscustomobject]@{ Running = $false; State = $null; Error = $_.Exception.Message; RetryAllowed = $false } }
}

function Start-GsbTimerHolder {
    param([uint32]$Target100ns = 5070, [string]$StateDirectory = '')
    Assert-GsbTimerTarget $Target100ns
    $paths = Get-GsbTimerPaths $StateDirectory
    if ($paths.Machine) { return Start-GsbMachineTimer $Target100ns }
    if ($paths.Root -eq (Join-Path $env:LOCALAPPDATA 'GamingStatusBench\Timer')) {
        $machine = Get-GsbMachineTimerPaths
        if ((Get-GsbMachineTimerAutostart).Status -eq 'Enabled' -or (Get-GsbTimerHolderState $machine.Root).Running) { throw 'Disable and stop the machine holder before starting a current-user holder.' }
    }
    $existing = Get-GsbTimerHolderState $StateDirectory
    if ($existing.Running) {
        if ($existing.State.Requested100ns -ne $Target100ns) { throw 'A different timer target is already running. Stop it before changing the target.' }
        return $existing
    }
    if ($existing.Error -and -not $existing.RetryAllowed) { throw $existing.Error }
    New-Item -ItemType Directory -Path $paths.Root -Force -ErrorAction Stop | Out-Null
    $psi = New-Object Diagnostics.ProcessStartInfo
    $psi.FileName = Join-Path $PSHOME 'powershell.exe'
    $psi.Arguments = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File {0} -Target100ns {1} -StateDirectory {2}' -f (ConvertTo-GsbProcessArgument (Join-Path $PSScriptRoot 'TimerHolder.ps1')), $Target100ns, (ConvertTo-GsbProcessArgument $paths.Root)
    $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
    $process = [Diagnostics.Process]::Start($psi)
    try {
        $deadline = [DateTime]::UtcNow.AddSeconds(15)
        do {
            Start-Sleep -Milliseconds 100
            $result = Get-GsbTimerHolderState $StateDirectory
            if ($result.Running -and $result.State.Requested100ns -eq $Target100ns) { return $result }
            if ($process.HasExited) { throw "Timer holder exited with code $($process.ExitCode). $($result.Error)" }
        } while ([DateTime]::UtcNow -lt $deadline)
        # A timed-out launch must not leave an unobserved timer request behind.
        $event = [Threading.EventWaitHandle]::OpenExisting($paths.StopEvent)
        try { [void]$event.Set() } finally { $event.Dispose() }
        throw 'Timer holder did not verify within 15 seconds; stop was requested.'
    }
    finally { $process.Dispose() }
}

function Stop-GsbTimerHolder {
    param([string]$StateDirectory = '')
    $paths = Get-GsbTimerPaths $StateDirectory
    if ($paths.Machine) { Assert-GsbTimerAdministrator }
    try {
        $event = [Threading.EventWaitHandle]::OpenExisting($paths.StopEvent)
        try { [void]$event.Set() } finally { $event.Dispose() }
    }
    catch [Threading.WaitHandleCannotBeOpenedException] {
        $state = Get-GsbTimerHolderState $StateDirectory
        if ($state.Running -or $state.Error) { throw 'Could not signal the timer holder; stop is unverified.' }
        return $true
    }
    $deadline = [DateTime]::UtcNow.AddSeconds(10)
    do {
        Start-Sleep -Milliseconds 100
        $state = Get-GsbTimerHolderState $StateDirectory
        if ($null -ne $state.State -and $state.State.Status -eq 'Stopped') {
            if ($state.State.ReleaseStatus -ne 0) { throw "Timer release failed: $($state.State.ReleaseStatus)" }
            return $true
        }
    } while ([DateTime]::UtcNow -lt $deadline)
    throw 'Timer release did not verify within 10 seconds.'
}

function Get-GsbTimerStartupContent {
    param([object]$Paths)
    $holder = $Paths.Holder.Replace('%', '%%')
    $config = $Paths.Config.Replace('%', '%%')
    "@echo off`r`nrem GamingStatusBench managed timer holder - current-user sign-in`r`nsetlocal DisableDelayedExpansion`r`nchcp 65001 >nul`r`nstart `"`" /b `"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe`" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$holder`" -ConfigPath `"$config`" -LaunchKind SignIn`r`n"
}

function Get-GsbTimerAutostart {
    param([string]$StateDirectory = '', [string]$StartupPath = '')
    $paths = Get-GsbTimerPaths $StateDirectory
    if ($paths.Machine -and -not $StartupPath) { return Get-GsbMachineTimerAutostart }
    if ($StartupPath) { $paths.Startup = $StartupPath }
    $result = [ordered]@{ Status = 'Disabled'; Target100ns = $null; Path = $paths.Startup; Error = '' }
    if (-not (Test-Path -LiteralPath $paths.Startup)) { return [pscustomobject]$result }
    try {
        if ([IO.File]::ReadAllText($paths.Startup) -ne (Get-GsbTimerStartupContent $paths)) { throw 'Startup BAT does not match this installation.' }
        $config = Get-Content -LiteralPath $paths.Config -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
        if ($config.StateDirectory -ne $paths.Root) { throw 'Startup configuration points to another directory.' }
        foreach ($name in @('TimerHolder.ps1', 'TimerRuntime.ps1', 'TimerMachine.ps1')) {
            $actual = (Get-FileHash -LiteralPath (Join-Path $paths.Root $name) -Algorithm SHA256 -ErrorAction Stop).Hash
            if ($actual -ne $config.Hashes.PSObject.Properties[$name].Value) { throw "Installed $name failed integrity verification." }
        }
        Assert-GsbTimerTarget ([uint32]$config.Target100ns)
        $result.Status = 'Enabled'; $result.Target100ns = $config.Target100ns
    }
    catch { $result.Status = 'Invalid'; $result.Error = $_.Exception.Message }
    [pscustomobject]$result
}

function Enable-GsbTimerAutostart {
    param([uint32]$Target100ns = 5070, [string]$StateDirectory = '', [string]$StartupPath = '')
    Assert-GsbTimerTarget $Target100ns
    $paths = Get-GsbTimerPaths $StateDirectory
    if ($paths.Machine -and -not $StartupPath) { return Enable-GsbMachineTimerAutostart $Target100ns }
    if ($paths.Root -eq (Join-Path $env:LOCALAPPDATA 'GamingStatusBench\Timer') -and ((Get-GsbMachineTimerAutostart).Status -eq 'Enabled' -or (Get-GsbTimerHolderState (Get-GsbMachineTimerPaths).Root).Running)) { throw 'Disable and stop machine mode before enabling user startup.' }
    if (-not $StateDirectory -and (Get-GsbMachineTimerAutostart).Status -eq 'Enabled') { throw 'Disable machine startup before enabling a user Startup BAT.' }
    if ($StartupPath) { $paths.Startup = $StartupPath }
    if ((Test-Path -LiteralPath $paths.Startup) -and -not ([IO.File]::ReadAllText($paths.Startup).Contains('rem GamingStatusBench managed timer holder - current-user sign-in'))) {
        throw 'An unmanaged Startup BAT already exists at this path. It will not be overwritten.'
    }
    New-Item -ItemType Directory -Path $paths.Root -Force -ErrorAction Stop | Out-Null
    $hashes = [ordered]@{}
    foreach ($name in @('TimerHolder.ps1', 'TimerRuntime.ps1', 'TimerMachine.ps1')) {
        $source = Join-Path $PSScriptRoot $name
        $destination = Join-Path $paths.Root $name
        if ([IO.Path]::GetFullPath($source) -ne [IO.Path]::GetFullPath($destination)) { Copy-Item -LiteralPath $source -Destination $destination -Force -ErrorAction Stop }
        $hashes[$name] = (Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash
    }
    Write-GsbTimerJson $paths.Config ([ordered]@{ Target100ns = $Target100ns; StateDirectory = $paths.Root; Hashes = $hashes })
    [IO.File]::WriteAllText($paths.Startup, (Get-GsbTimerStartupContent $paths), (New-Object Text.UTF8Encoding($false)))
    $verified = Get-GsbTimerAutostart $StateDirectory $paths.Startup
    if ($verified.Status -ne 'Enabled') { throw "Autostart failed verification: $($verified.Error)" }
    return $verified
}

function Disable-GsbTimerAutostart {
    param([string]$StateDirectory = '', [string]$StartupPath = '')
    $paths = Get-GsbTimerPaths $StateDirectory
    if ($paths.Machine -and -not $StartupPath) { return Disable-GsbMachineTimerAutostart }
    if ($StartupPath) { $paths.Startup = $StartupPath }
    if (Test-Path -LiteralPath $paths.Startup) {
        if (-not ([IO.File]::ReadAllText($paths.Startup).Contains('rem GamingStatusBench managed timer holder - current-user sign-in'))) { throw 'Refusing to remove an unmanaged Startup BAT.' }
        Remove-Item -LiteralPath $paths.Startup -ErrorAction Stop
    }
    if (Test-Path -LiteralPath $paths.Startup) { throw 'Startup BAT removal did not verify.' }
    return $true
}

. (Join-Path $PSScriptRoot 'TimerMachine.ps1')
