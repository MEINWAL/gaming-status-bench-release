function Get-GsbDiagnosticProperty {
    param([object]$Value,[string]$Name,[object]$Default=$null)
    if ($null -ne $Value -and $null -ne $Value.PSObject.Properties[$Name]) { return $Value.PSObject.Properties[$Name].Value }
    return $Default
}

function Get-GsbTimerCommandInfo {
    param([string]$Command,[string]$Name='')
    $known = $Command -match '(?i)(?:^|[\\/"\s])(?:SetTimerResolution\.exe|TimerResolution\.exe|Set-TimerResolution\.ps1|TimerHolder\.ps1)(?=["\s]|$)'
    $suspected = -not $known -and ($Name -match '(?i)timer[-_ ]?resolution|GamingStatusBench-Timer' -or $Command -match '(?i)\bNtSetTimerResolution\b')
    if (-not $known -and -not $suspected) { return $null }
    $target = $null
    if ($Command -match '(?i)(?:--resolution(?:=|\s+)|-Desired100ns\s+|-Target100ns\s+)"?(\d+)"?(?=\s|$)') {
        [uint32]$parsed = 0
        if ([uint32]::TryParse($matches[1],[ref]$parsed)) { $target = $parsed }
    }
    $managed = if ($Command -match '(?i)GamingStatusBench\\TimerMachine\\TimerHolder\.ps1') { 'Machine' } elseif ($Command -match '(?i)GamingStatusBench\\Timer\\TimerHolder\.ps1') { 'User' } else { '' }
    [pscustomobject]@{Target100ns=$target;ManagedScope=$managed;Recognition=$(if($known){'Known launcher'}else{'Suspected timer entry'})}
}

function New-GsbTimerStartupEntry {
    param([string]$Source,[string]$Identity,[string]$Scope,[object]$Enabled,[string]$State,[string]$Command,[string]$ExecutionIdentity='',[string]$RunLevel='')
    $info = Get-GsbTimerCommandInfo $Command $Identity
    if ($null -eq $info) { return }
    [pscustomobject]@{Source=$Source;Identity=$Identity;Scope=$Scope;Enabled=$Enabled;State=$State;Command=$Command;Target100ns=$info.Target100ns;ManagedScope=$info.ManagedScope;Recognition=$info.Recognition;ExecutionIdentity=$ExecutionIdentity;RunLevel=$RunLevel}
}

function Get-GsbTimerTaskInventory {
    foreach ($task in Get-ScheduledTask -ErrorAction Stop) {
        $commands = @($task.Actions | ForEach-Object {
            $execute = [string](Get-GsbDiagnosticProperty $_ 'Execute' '')
            $arguments = [string](Get-GsbDiagnosticProperty $_ 'Arguments' '')
            if ($execute -or $arguments) { "$execute $arguments" }
        })
        $settings = Get-GsbDiagnosticProperty $task 'Settings'
        $principal = Get-GsbDiagnosticProperty $task 'Principal'
        New-GsbTimerStartupEntry 'Scheduled task' ($task.TaskPath+$task.TaskName) 'Machine/current user' (Get-GsbDiagnosticProperty $settings 'Enabled') ([string]$task.State) ($commands -join ' | ') ([string](Get-GsbDiagnosticProperty $principal 'UserId' '')) ([string](Get-GsbDiagnosticProperty $principal 'RunLevel' ''))
    }
}

function Get-GsbTimerRunInventory {
    foreach ($hive in @('HKLM:\Software','HKLM:\Software\WOW6432Node','HKCU:\Software')) {
        foreach ($kind in @('Run','RunOnce')) {
            $path = "$hive\Microsoft\Windows\CurrentVersion\$kind"
            if (-not (Test-Path -LiteralPath $path -ErrorAction Stop)) { continue }
            $key = Get-Item -LiteralPath $path -ErrorAction Stop
            foreach ($name in $key.GetValueNames()) {
                $command = [string]$key.GetValue($name,$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
                New-GsbTimerStartupEntry $kind "$path :: $name" $(if($hive -like 'HKLM*'){'Machine'}else{'Current user'}) $null 'Configured; execution approval unverified' $command
            }
        }
    }
}

function Get-GsbTimerFolderInventory {
    foreach ($kind in @('Startup','CommonStartup')) {
        $folder = [Environment]::GetFolderPath($kind)
        if (-not $folder -or -not (Test-Path -LiteralPath $folder -ErrorAction Stop)) { continue }
        foreach ($file in Get-ChildItem -LiteralPath $folder -File -ErrorAction Stop) {
            $command = $file.FullName
            if ($file.Extension -in @('.bat','.cmd','.ps1')) {
                if ($file.Length -gt 65536) { throw "Startup script exceeds the 64 KB inspection limit: $($file.FullName)" }
                $command = [IO.File]::ReadAllText($file.FullName)
            }
            elseif ($file.Extension -eq '.lnk') {
                $shell = New-Object -ComObject WScript.Shell -ErrorAction Stop
                $shortcut=$null
                try { $shortcut=$shell.CreateShortcut($file.FullName); $command=$shortcut.TargetPath+' '+$shortcut.Arguments }
                finally { if($null -ne $shortcut){[void][Runtime.InteropServices.Marshal]::ReleaseComObject($shortcut)}; [void][Runtime.InteropServices.Marshal]::ReleaseComObject($shell) }
            }
            New-GsbTimerStartupEntry 'Startup folder' $file.FullName $(if($kind -eq 'CommonStartup'){'Machine'}else{'Current user'}) $null 'Configured; execution approval unverified' $command
        }
    }
}

function Get-GsbTimerServiceInventory {
    foreach ($service in Get-CimInstance Win32_Service -ErrorAction Stop) {
        New-GsbTimerStartupEntry 'Service' $service.Name 'Machine' ($service.StartMode -eq 'Auto') $service.State ([string]$service.PathName) ([string]$service.StartName)
    }
}

function Get-GsbTimerProcessInventory {
    foreach ($process in Get-CimInstance Win32_Process -ErrorAction Stop) {
        $command = [string]$process.CommandLine
        $info = Get-GsbTimerCommandInfo $command $process.Name
        if ($process.Name -in @('SetTimerResolution.exe','TimerResolution.exe') -and ($null -eq $info -or $info.Recognition -ne 'Known launcher')) { $info=Get-GsbTimerCommandInfo $process.Name $process.Name }
        if (-not $command -and ($null -ne $info -or $process.Name -in @('powershell.exe','pwsh.exe'))) {
            if($null -eq $info){$info=[pscustomobject]@{Target100ns=$null;ManagedScope='';Recognition='Uninspectable PowerShell process'}}
        }
        if ($null -eq $info) { continue }
        [pscustomobject]@{Name=$process.Name;ProcessId=$process.ProcessId;SessionId=$process.SessionId;Command=$command;CommandLineVisible=[bool]$command;ExecutablePath=$process.ExecutablePath;Target100ns=$info.Target100ns;ManagedScope=$info.ManagedScope;Recognition=$info.Recognition}
    }
}

function Get-GsbManagedTimerDiagnosticState {
    param([string]$StateDirectory='',[string]$StartupPath='')
    $machine = Get-GsbMachineTimerPaths
    $user = Get-GsbTimerPaths (Join-Path $env:LOCALAPPDATA 'GamingStatusBench\Timer')
    if ($StateDirectory -and -not (Get-GsbTimerPaths $StateDirectory).Machine) { $user=Get-GsbTimerPaths $StateDirectory }
    foreach ($entry in @(@('Machine',$machine),@('User',$user))) {
        $paths=$entry[1]
        $auto = if($entry[0] -eq 'Machine'){Get-GsbMachineTimerAutostart}else{Get-GsbTimerAutostart $paths.Root $StartupPath}
        $written = if(Test-Path -LiteralPath $paths.Config -ErrorAction Stop){(Get-Item -LiteralPath $paths.Config -ErrorAction Stop).LastWriteTimeUtc.ToString('o')}else{$null}
        [pscustomobject]@{Scope=$entry[0];Autostart=$auto;Holder=(Get-GsbTimerHolderState $paths.Root);ConfigWrittenUtc=$written}
    }
}

function Get-GsbTimerStartupInventory {
    param([string]$StateDirectory='',[string]$StartupPath='')
    $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
    try {$admin=(New-Object Security.Principal.WindowsPrincipal($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)}
    finally {$identity.Dispose()}
    $inventory=[ordered]@{CheckedUtc=[DateTime]::UtcNow.ToString('o');IsAdmin=$admin;StartupEntries=@();Processes=@();Managed=@();Resolution=$null;BootUtc=$null;Sources=@()}
    foreach ($spec in @(
        @('Scheduled tasks','StartupEntries',{Get-GsbTimerTaskInventory},$true),
        @('Run/RunOnce','StartupEntries',{Get-GsbTimerRunInventory},$false),
        @('Startup folders','StartupEntries',{Get-GsbTimerFolderInventory},$false),
        @('Services','StartupEntries',{Get-GsbTimerServiceInventory},$true),
        @('Processes','Processes',{Get-GsbTimerProcessInventory},$true),
        @('Managed GSB state','Managed',{Get-GsbManagedTimerDiagnosticState $StateDirectory $StartupPath},$false),
        @('Live resolution','Resolution',{Get-GsbTimerResolution},$false),
        @('Boot timestamp','BootUtc',{(Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).LastBootUpTime.ToUniversalTime().ToString('o')},$false)
    )) {
        $rows=New-Object 'System.Collections.Generic.List[object]'
        $status='Complete'; $errorText=''
        try { & $spec[2] | ForEach-Object {$rows.Add($_)} }
        catch {$status='Failed';$errorText=$_.Exception.Message}
        if($status -eq 'Complete' -and $spec[3] -and -not $admin){$status='Partial';$errorText='Protected machine entries or process command lines may be hidden without elevation.'}
        if($status -eq 'Complete' -and $spec[0] -eq 'Processes' -and @($rows | Where-Object {-not $_.CommandLineVisible}).Count){$status='Partial';$errorText='Some matching or PowerShell process command lines were unreadable; their timer role/target is unverified.'}
        if($spec[1] -in @('StartupEntries','Processes','Managed')){$inventory[$spec[1]]+=@($rows.ToArray())}
        elseif($rows.Count){$inventory[$spec[1]]=$rows[0]}
        $inventory.Sources+= [pscustomobject]@{Name=$spec[0];Status=$status;MatchedRows=$rows.Count;Error=$errorText}
    }
    [pscustomobject]$inventory
}

function New-GsbTimerStartupAssessment {
    param([Parameter(Mandatory=$true)][object]$Inventory)
    $issues=New-Object 'System.Collections.Generic.List[object]'
    function Add-StartupIssue {
        param([string]$Code,[string]$Status,[string]$Value,[string]$Note,[string]$Action)
        $issues.Add([pscustomobject]@{Code=$Code;Status=$Status;Value=$Value;Note=$Note;Action=$Action;Decision=$(if($Status -eq 'UNKNOWN'){'CHECK'}else{'REVIEW'})})
    }
    $incomplete=@($Inventory.Sources | Where-Object {$_.Status -ne 'Complete'})
    if($incomplete.Count -or -not $Inventory.IsAdmin){Add-StartupIssue 'InventoryIncomplete' 'UNKNOWN' 'Coverage incomplete' 'Protected tasks, unreadable sources or process arguments prevent an all-clear.' 'Run this check as administrator and review source errors. Missing rows do not prove absence.'}
    $active=@($Inventory.StartupEntries | Where-Object {$_.Enabled -ne $false -or $_.State -eq 'Running'})
    $unverifiedEntries=@($active | Where-Object {$null -eq $_.Enabled})
    if($unverifiedEntries.Count){Add-StartupIssue 'StartupExecutionUnverified' 'UNKNOWN' "$($unverifiedEntries.Count) configured entries with unverified execution approval" 'Run values or Startup files were read, but Windows startup approval/policy and actual launch were not verified.' 'Review Windows startup approval and actual launch evidence. A file or registry value existing is not proof that it runs.'}
    if($active.Count -gt 1){Add-StartupIssue 'MultipleStartupEntries' 'WARN' "$($active.Count) configured/running timer startup candidates" (($active | ForEach-Object {$_.Identity}) -join '; ') 'Choose one intentional holder. Verify which candidates execute, then back up and explicitly disable unwanted entries before retesting.'}
    foreach($row in $Inventory.StartupEntries){
        if($row.ManagedScope){
            $managed=@($Inventory.Managed | Where-Object {$_.Scope -eq $row.ManagedScope} | Select-Object -First 1)
            if($managed.Count -and $managed[0].Autostart.Status -eq 'Enabled'){$row.Target100ns=$managed[0].Autostart.Target100ns}
        }
    }
    foreach($managed in $Inventory.Managed){
        if(-not $managed.Holder.Running -or $null -eq $managed.Holder.State){continue}
        $state=$managed.Holder.State
        $managedPid=Get-GsbDiagnosticProperty $state 'ProcessId' -1
        foreach($row in $Inventory.Processes){
            # GSB can verify its own PID identity even when its command line is hidden.
            if($row.ProcessId -eq $managedPid -and $row.SessionId -eq $state.SessionId){
                if($row.Recognition -eq 'Uninspectable PowerShell process'){$row.Recognition='Verified GSB holder'}
                $row.ManagedScope=$managed.Scope
                if($null -eq $row.Target100ns){$row.Target100ns=$state.Requested100ns}
            }
        }
    }
    $processes=@($Inventory.Processes | Where-Object {$_.Recognition -in @('Known launcher','Verified GSB holder')})
    if($processes.Count -gt 1){Add-StartupIssue 'MultipleTimerProcesses' 'WARN' "$($processes.Count) timer launcher processes" (($processes | ForEach-Object {"$($_.Name) PID $($_.ProcessId) / session $($_.SessionId)"}) -join '; ') 'Review each matching process and its startup source. This count alone does not prove the cause of Sleep jitter.'}
    $targets=@(@($active | ForEach-Object {$_.Target100ns})+@($Inventory.Processes | ForEach-Object {$_.Target100ns}) | Where-Object {$null -ne $_} | Sort-Object -Unique)
    if($targets.Count -gt 1){Add-StartupIssue 'DifferentTimerTargets' 'WARN' ($targets -join ' / ') 'Different targets were read from active startup commands, managed configuration or running process arguments (100 ns units).' 'Review the configured targets and keep only the intentional startup. The live interval alone cannot identify every request owner.'}
    if(@($active | Where-Object {$_.Recognition -ne 'Known launcher'}).Count){Add-StartupIssue 'UnrecognizedTimerStartup' 'WARN' 'Suspected timer startup needs review' 'A timer-named entry or timer-API script does not match a known launcher signature.' 'Inspect its command/script manually. It will not be automatically replaced.'}
    foreach($managed in $Inventory.Managed){
        $auto=$managed.Autostart; $holder=$managed.Holder
        if($auto.Status -eq 'Invalid'){Add-StartupIssue 'ManagedStartupInvalid' 'WARN' "$($managed.Scope) startup invalid" $auto.Error 'Review startup configuration, task identity and installed-file integrity before reinstalling.'}
        if($holder.Error){Add-StartupIssue 'ManagedHolderUnverified' 'UNKNOWN' "$($managed.Scope) holder unverified" $holder.Error 'Inspect the retained startup error/heartbeat. A stale state file is not a running-holder confirmation.'}
        if($holder.Running -and $null -ne $holder.State){
            $state=$holder.State
            if($auto.Status -eq 'Enabled' -and $auto.Target100ns -ne $state.Requested100ns){Add-StartupIssue 'StartupRuntimeTargetMismatch' 'WARN' "$($managed.Scope): startup $($auto.Target100ns), running $($state.Requested100ns)" 'The next-startup target differs from the verified running holder target.' 'Restart the managed holder explicitly after updating its target, then check again.'}
            if($null -ne $Inventory.Resolution -and ($Inventory.Resolution.Current100ns -ne $state.Requested100ns -or $state.Returned100ns -ne $state.Requested100ns)){Add-StartupIssue 'RequestedMeasuredMismatch' 'WARN' "$($managed.Scope): requested $($state.Requested100ns), API $($state.Returned100ns), live $($Inventory.Resolution.Current100ns)" 'Requested, returned and currently measured timer intervals do not all match. Another request or OS rounding can affect the live value.' 'Review other launchers and retest. Do not claim the requested value was measured when it was not.'}
            if($managed.Scope -eq 'Machine' -and ($state.SessionId -ne 0 -or $state.LogonIdentity.UserSid -ne 'S-1-5-18')){Add-StartupIssue 'MachineHolderWrongIdentity' 'WARN' 'Machine holder is not SYSTEM/session 0' 'The observed holder identity does not match machine-startup requirements.' 'Review the protected machine task; do not rely on a user Startup BAT for pre-sign-in machine startup.'}
        }
        elseif($managed.Scope -eq 'Machine' -and $auto.Status -eq 'Enabled' -and $managed.ConfigWrittenUtc -and $Inventory.BootUtc){
            $boot=[DateTime]::Parse($Inventory.BootUtc).ToUniversalTime()
            $stoppedThisBoot=(Get-GsbDiagnosticProperty $holder.State 'Status' '') -eq 'Stopped' -and (Get-GsbDiagnosticProperty $holder.State 'BootUtc' '') -eq $Inventory.BootUtc
            if(-not $stoppedThisBoot -and [DateTime]::Parse($managed.ConfigWrittenUtc).ToUniversalTime() -lt $boot -and ([DateTime]::UtcNow-$boot).TotalSeconds -gt 120){Add-StartupIssue 'MachineStartupNotRunning' 'WARN' 'Enabled before this boot, but no verified holder' 'The machine startup was configured before boot and the startup grace period has elapsed. It may have failed to launch or been stopped later.' 'Inspect task history and the retained startup error. Do not report task registration as successful boot execution.'}
        }
    }
    $status=if(@($issues | Where-Object {$_.Status -eq 'WARN'}).Count){'WARN'}elseif($issues.Count){'UNKNOWN'}else{'OK'}
    [pscustomobject]@{
        Status=$status;CheckedUtc=$Inventory.CheckedUtc;ReadOnly=$true;IsAdmin=$Inventory.IsAdmin
        Coverage=[pscustomobject]@{Status=$(if($incomplete.Count -or -not $Inventory.IsAdmin){'Partial'}else{'Complete'});Scope='Known timer launch signatures; machine and current user';Sources=@($Inventory.Sources)}
        Summary=$(if($status -eq 'OK'){'No conflict detected within the inspected scope.'}elseif($status -eq 'WARN'){'Review detected timer startup/runtime problems.'}else{'Unverified: startup execution, inventory coverage or holder state needs checking.'})
        ActiveStartupCount=$active.Count;KnownTimerProcessCount=$processes.Count
        UnverifiedStartupCount=$unverifiedEntries.Count
        Issues=@($issues.ToArray());StartupEntries=@($Inventory.StartupEntries);Processes=@($Inventory.Processes);Managed=@($Inventory.Managed);Resolution=$Inventory.Resolution;BootUtc=$Inventory.BootUtc
        Limitations=@('Not a list of every kernel timer-resolution request owner.','Other users, arbitrary/encoded launcher scripts and unrecognized applications may not be detected.','Startup candidate counts include configured entries whose execution approval is unverified.','Multiple requests or varying Sleep times do not by themselves establish a jitter cause.','Configured startup and a running holder do not prove the next reboot will succeed.')
    }
}

function Get-GsbTimerStartupDiagnostics {
    param([string]$StateDirectory='',[string]$StartupPath='')
    New-GsbTimerStartupAssessment (Get-GsbTimerStartupInventory $StateDirectory $StartupPath)
}
