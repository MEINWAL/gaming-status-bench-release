[CmdletBinding()]
param(
    [string]$OutputDir = ""
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = "Continue"

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$script:CollectorPath = Join-Path $PSScriptRoot "GamingStatus.ps1"
if (-not $OutputDir) {
    $OutputDir = Join-Path $PSScriptRoot "..\..\reports"
}
$script:OutputDir = [System.IO.Path]::GetFullPath($OutputDir)
$script:LastJsonPath = $null
$script:LastHtmlPath = $null
$script:LastReport = $null
$script:IsRunning = $false
$script:ScanTimer = $null
$script:TimerHoldActive = $false
$script:TimerHoldCurrentMs = $null
$script:ProcessTimerPolicyApplied = $false
$script:ProcessTimerPolicyError = $null

if (-not (Test-Path $script:OutputDir)) {
    New-Item -ItemType Directory -Path $script:OutputDir -Force | Out-Null
}

function Test-IsAdmin {
    try {
        $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object Security.Principal.WindowsPrincipal($identity)
        return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    }
    catch {
        return $false
    }
}

function Quote-Arg {
    param([string]$Value)
    if ($null -eq $Value) { return '""' }
    $escaped = $Value -replace '"', '\"'
    return '"' + $escaped + '"'
}

function Get-StatusColor {
    param([string]$Status)
    switch ($Status) {
        "OK" { return [Drawing.Color]::FromArgb(64, 224, 126) }
        "WARN" { return [Drawing.Color]::FromArgb(247, 199, 91) }
        "FAIL" { return [Drawing.Color]::FromArgb(255, 94, 94) }
        "INFO" { return [Drawing.Color]::FromArgb(99, 208, 255) }
        default { return [Drawing.Color]::FromArgb(190, 176, 255) }
    }
}

function Set-FlatButtonStyle {
    param(
        [System.Windows.Forms.Button]$Button,
        [Drawing.Color]$Accent
    )
    $Button.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $Button.FlatAppearance.BorderColor = $Accent
    $Button.FlatAppearance.MouseOverBackColor = [Drawing.Color]::FromArgb(28, 44, 38)
    $Button.FlatAppearance.MouseDownBackColor = [Drawing.Color]::FromArgb(42, 68, 55)
    $Button.BackColor = [Drawing.Color]::FromArgb(10, 14, 13)
    $Button.ForeColor = $Accent
    $Button.Font = New-Object Drawing.Font("Consolas", 9.5, [Drawing.FontStyle]::Bold)
    $Button.Height = 34
}

function Write-TerminalLog {
    param(
        [string]$Text,
        [Drawing.Color]$Color = [Drawing.Color]::FromArgb(170, 244, 198)
    )

    if ($null -eq $script:LogBox) { return }
    $script:LogBox.SelectionStart = $script:LogBox.TextLength
    $script:LogBox.SelectionLength = 0
    $script:LogBox.SelectionColor = $Color
    $script:LogBox.AppendText("[$((Get-Date).ToString('HH:mm:ss'))] $Text`r`n")
    $script:LogBox.SelectionColor = $script:LogBox.ForeColor
    $script:LogBox.ScrollToCaret()
}

function Get-GameExePathsFromText {
    param([string]$Text)

    $items = @()
    foreach ($part in ($Text -split "[`r`n;]+")) {
        $trimmed = $part.Trim()
        if ($trimmed) {
            $items += $trimmed
        }
    }
    return $items
}

function Get-PingTargetsFromText {
    param([string]$Text)

    $items = @()
    foreach ($part in ($Text -split "[,;`r`n ]+")) {
        $trimmed = $part.Trim()
        if ($trimmed) {
            $items += $trimmed
        }
    }
    return $items
}

function Get-LatestReportJson {
    $latest = Get-ChildItem -Path $script:OutputDir -Filter "gaming-status-*.json" -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime |
        Select-Object -Last 1
    if ($latest) { return $latest.FullName }
    return $null
}

function Open-Path {
    param([string]$Path)
    if ($Path -and (Test-Path $Path)) {
        Start-Process $Path
    }
}

function Get-JsonValue {
    param(
        [object]$Object,
        [string[]]$Path
    )

    $current = $Object
    foreach ($part in $Path) {
        if ($null -eq $current) { return $null }
        $prop = $current.PSObject.Properties[$part]
        if ($null -eq $prop) { return $null }
        $current = $prop.Value
    }
    return $current
}

function Get-ObjectsWithProperty {
    param(
        [object]$Value,
        [string]$PropertyName
    )

    return @($Value | Where-Object {
        $null -ne $_ -and $null -ne $_.PSObject.Properties[$PropertyName]
    })
}

function Set-ScanControlsEnabled {
    param([bool]$Enabled)
    $script:RunButton.Enabled = $Enabled
    $script:AdminButton.Enabled = $Enabled
    $script:GameExeBox.Enabled = $Enabled
    $script:PingTargetBox.Enabled = $Enabled
    $script:PingCountBox.Enabled = $Enabled
    $script:TimerSamplesBox.Enabled = $Enabled
    $script:NetworkBox.Enabled = $Enabled
}

function Set-SummaryLabel {
    param(
        [System.Windows.Forms.Label]$Label,
        [string]$Text,
        [string]$Status
    )
    $Label.Text = $Text
    $Label.ForeColor = Get-StatusColor $Status
}

function Update-ReportView {
    param([object]$Report)

    $script:LastReport = $Report
    $findings = @($Report.Findings)
    $ok = @($findings | Where-Object { $_.Status -eq "OK" }).Count
    $warn = @($findings | Where-Object { $_.Status -eq "WARN" }).Count
    $fail = @($findings | Where-Object { $_.Status -eq "FAIL" }).Count
    $info = @($findings | Where-Object { $_.Status -eq "INFO" }).Count
    $unknown = @($findings | Where-Object { $_.Status -eq "UNKNOWN" }).Count

    Set-SummaryLabel $script:OkLabel "OK $ok" "OK"
    Set-SummaryLabel $script:WarnLabel "WARN $warn" "WARN"
    Set-SummaryLabel $script:FailLabel "FAIL $fail" "FAIL"
    Set-SummaryLabel $script:InfoLabel "INFO $info" "INFO"
    Set-SummaryLabel $script:UnknownLabel "UNKNOWN $unknown" "UNKNOWN"

    $timer = Get-JsonValue $Report @("Sections", "Timer", "NtQueryTimerResolution", "CurrentMs")
    $sleepWake = Get-JsonValue $Report @("Sections", "Timer", "SleepJitter", "P95Ms")
    $waitable = Get-JsonValue $Report @("Sections", "Timer", "HighResolutionWaitableTimer", "P95Ms")
    $hostText = "$($Report.Host.ComputerName) | Admin=$($Report.Host.IsAdmin) | $($Report.Host.OS)"
    $script:HostLabel.Text = $hostText
    $script:TimerLabel.Text = "timer $timer ms | Sleep(1) p95 $sleepWake ms | waitable p95 $waitable ms"

    $gpu = @(Get-ObjectsWithProperty -Value (Get-JsonValue $Report @("Sections", "DisplayGpu", "VideoControllers")) -PropertyName "Name" | Select-Object -First 1)
    if ($gpu.Count -gt 0) {
        $script:DisplayLabel.Text = "$($gpu[0].Name) | $($gpu[0].CurrentHorizontalResolution)x$($gpu[0].CurrentVerticalResolution)@$($gpu[0].CurrentRefreshRate)Hz"
    }
    else {
        $script:DisplayLabel.Text = "display/gpu unknown"
    }

    $pings = @(Get-ObjectsWithProperty -Value (Get-JsonValue $Report @("Sections", "Network", "Ping")) -PropertyName "Target")
    if ($pings.Count -gt 0) {
        $bestPing = $pings | Sort-Object AvgMs | Select-Object -First 1
        $script:NetworkLabel.Text = "best ping $($bestPing.Target): $($bestPing.AvgMs) ms / loss $($bestPing.LossPct)%"
    }
    else {
        $script:NetworkLabel.Text = "network benchmark skipped"
    }

    $script:FindingsList.BeginUpdate()
    $script:FindingsList.Items.Clear()
    foreach ($finding in ($findings | Sort-Object Priority, Status, Area, Name)) {
        $item = New-Object System.Windows.Forms.ListViewItem([string]$finding.Status)
        $item.SubItems.Add([string]$finding.Decision) | Out-Null
        $item.SubItems.Add([string]$finding.Area) | Out-Null
        $item.SubItems.Add([string]$finding.Name) | Out-Null
        $item.SubItems.Add([string]$finding.Value) | Out-Null
        $item.SubItems.Add([string]$finding.Action) | Out-Null
        $item.SubItems.Add([string]$finding.Note) | Out-Null
        $item.ForeColor = Get-StatusColor $finding.Status
        $item.BackColor = [Drawing.Color]::FromArgb(7, 10, 10)
        $script:FindingsList.Items.Add($item) | Out-Null
    }
    $script:FindingsList.EndUpdate()

    $script:DetailsBox.Clear()
    $script:DetailsBox.AppendText(($Report | ConvertTo-Json -Depth 7))

    $script:LastJsonPath = $Report.Paths.Json
    $script:LastHtmlPath = $Report.Paths.Html
    $script:OpenJsonButton.Enabled = [bool]($script:LastJsonPath -and (Test-Path $script:LastJsonPath))
    $script:OpenHtmlButton.Enabled = [bool]($script:LastHtmlPath -and (Test-Path $script:LastHtmlPath))
    $script:CopySummaryButton.Enabled = $true
    Update-SolverView -Report $Report
}

function Start-GuiScan {
    if ($script:IsRunning) { return }
    if (-not (Test-Path $script:CollectorPath)) {
        [System.Windows.Forms.MessageBox]::Show("Collector not found:`n$script:CollectorPath", "Gaming Status Bench", "OK", "Error") | Out-Null
        return
    }

    $script:IsRunning = $true
    Set-ScanControlsEnabled $false
    $script:StatusLabel.Text = "SCAN RUNNING"
    $script:StatusLabel.ForeColor = [Drawing.Color]::FromArgb(247, 199, 91)
    Write-TerminalLog "scan started"

    $gamePaths = @(Get-GameExePathsFromText $script:GameExeBox.Text)
    $pingTargets = @(Get-PingTargetsFromText $script:PingTargetBox.Text)
    $pingCount = [int]$script:PingCountBox.Value
    $timerSamples = [int]$script:TimerSamplesBox.Value
    $networkEnabled = $script:NetworkBox.Checked

    $procArgs = @(
        "-NoProfile",
        "-ExecutionPolicy", "Bypass",
        "-File", (Quote-Arg $script:CollectorPath),
        "-OutputDir", (Quote-Arg $script:OutputDir),
        "-PingCount", $pingCount,
        "-TimerSampleCount", $timerSamples,
        "-Quiet"
    )

    if (-not $networkEnabled) {
        $procArgs += "-NoNetworkBenchmark"
    }

    if ($pingTargets.Count -gt 0) {
        $procArgs += "-PingTarget"
        $procArgs += (Quote-Arg ($pingTargets -join ","))
    }

    if ($gamePaths.Count -gt 0) {
        $procArgs += "-GameExePath"
        $procArgs += (Quote-Arg ($gamePaths -join ";"))
    }

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = "powershell.exe"
    $psi.Arguments = ($procArgs -join " ")
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true

    try {
        $process = [Diagnostics.Process]::Start($psi)
    }
    catch {
        $script:IsRunning = $false
        Set-ScanControlsEnabled $true
        $script:StatusLabel.Text = "SCAN ERROR"
        $script:StatusLabel.ForeColor = Get-StatusColor "FAIL"
        Write-TerminalLog "failed to start scan: $($_.Exception.Message)" (Get-StatusColor "FAIL")
        return
    }

    Write-TerminalLog "process started pid=$($process.Id)"

    $script:ScanTimer = New-Object System.Windows.Forms.Timer
    $script:ScanTimer.Interval = 350
    $script:ScanTimer.Tag = [pscustomobject]@{
        Process = $process
        CommandLine = "powershell.exe $($psi.Arguments)"
        Tick = 0
        Started = Get-Date
        TimedOut = $false
        TimeoutSeconds = 120
    }
    $script:ScanTimer.Add_Tick({
        param($sender, $eventArgs)

        $state = $sender.Tag
        $state.Tick = [int]$state.Tick + 1
        if (($state.Tick % 6) -eq 0) {
            $script:StatusLabel.Text = "SCAN RUNNING" + ("." * (($state.Tick / 6) % 4))
        }

        if (-not $state.Process.HasExited) {
            $elapsed = ((Get-Date) - $state.Started).TotalSeconds
            if ($elapsed -gt $state.TimeoutSeconds -and -not $state.TimedOut) {
                $state.TimedOut = $true
                Write-TerminalLog "scan timeout after $([int]$elapsed)s; stopping collector pid=$($state.Process.Id)" (Get-StatusColor "WARN")
                try {
                    $state.Process.Kill()
                }
                catch {
                    Write-TerminalLog "could not stop collector: $($_.Exception.Message)" (Get-StatusColor "WARN")
                }
            }
            return
        }

        $sender.Stop()
        $sender.Dispose()
        $script:ScanTimer = $null

        $stdout = $state.Process.StandardOutput.ReadToEnd()
        $stderr = $state.Process.StandardError.ReadToEnd()
        $state.Process.WaitForExit()
        $exitCode = $state.Process.ExitCode
        $state.Process.Dispose()

        $script:IsRunning = $false
        Set-ScanControlsEnabled $true

        Write-TerminalLog "command: $($state.CommandLine)" ([Drawing.Color]::FromArgb(112, 210, 160))
        if ($stdout.Trim()) {
            foreach ($line in ($stdout -split "`r?`n")) {
                if ($line.Trim()) { Write-TerminalLog $line ([Drawing.Color]::FromArgb(170, 244, 198)) }
            }
        }
        if ($stderr.Trim()) {
            foreach ($line in ($stderr -split "`r?`n")) {
                if ($line.Trim()) { Write-TerminalLog $line (Get-StatusColor "WARN") }
            }
        }

        if ($state.TimedOut) {
            $script:StatusLabel.Text = "SCAN TIMEOUT"
            $script:StatusLabel.ForeColor = Get-StatusColor "WARN"
        }
        elseif ($exitCode -ne 0) {
            $script:StatusLabel.Text = "SCAN EXIT $exitCode"
            $script:StatusLabel.ForeColor = Get-StatusColor "WARN"
        }
        else {
            $script:StatusLabel.Text = "SCAN COMPLETE"
            $script:StatusLabel.ForeColor = Get-StatusColor "OK"
        }

        $jsonPath = Get-LatestReportJson
        if ($jsonPath -and (Test-Path $jsonPath)) {
            try {
                $report = Get-Content -Path $jsonPath -Raw | ConvertFrom-Json
                Update-ReportView $report
                Write-TerminalLog "report loaded: $jsonPath" (Get-StatusColor "OK")
            }
            catch {
                Write-TerminalLog "could not load JSON report: $($_.Exception.Message)" (Get-StatusColor "WARN")
            }
        }
        else {
            Write-TerminalLog "no JSON report found in $script:OutputDir" (Get-StatusColor "WARN")
        }
    })

    $script:ScanTimer.Start()
}

function Restart-AsAdmin {
    $adminArgs = "-NoProfile -ExecutionPolicy Bypass -File $(Quote-Arg $PSCommandPath) -OutputDir $(Quote-Arg $script:OutputDir)"
    try {
        Start-Process -FilePath "powershell.exe" -ArgumentList $adminArgs -Verb RunAs
        $script:Form.Close()
    }
    catch {
        Write-TerminalLog "admin relaunch cancelled or failed: $($_.Exception.Message)" (Get-StatusColor "WARN")
    }
}

function Copy-Summary {
    $lines = @(
        "Gaming Status Bench",
        $script:HostLabel.Text,
        $script:TimerLabel.Text,
        $script:DisplayLabel.Text,
        $script:NetworkLabel.Text,
        $script:OkLabel.Text,
        $script:WarnLabel.Text,
        $script:FailLabel.Text,
        $script:InfoLabel.Text,
        $script:UnknownLabel.Text,
        "JSON: $script:LastJsonPath",
        "HTML: $script:LastHtmlPath"
    )
    [System.Windows.Forms.Clipboard]::SetText(($lines -join "`r`n"))
    Write-TerminalLog "summary copied to clipboard"
}

function Ensure-GuiNativeTimer {
    try {
        if (-not ("GamingStatusGuiNativeTimer" -as [type])) {
            Add-Type -TypeDefinition @"
	using System;
	using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Sequential)]
public struct GamingStatusGuiProcessPowerThrottlingState
{
    public uint Version;
    public uint ControlMask;
    public uint StateMask;
}

public static class GamingStatusGuiNativeTimer
{
    [DllImport("ntdll.dll")]
    public static extern int NtSetTimerResolution(uint DesiredResolution, bool SetResolution, out uint CurrentResolution);

    [DllImport("kernel32.dll")]
    public static extern IntPtr GetCurrentProcess();

    [DllImport("kernel32.dll", SetLastError=true)]
    public static extern bool SetProcessInformation(IntPtr hProcess, int ProcessInformationClass, ref GamingStatusGuiProcessPowerThrottlingState ProcessInformation, int ProcessInformationSize);

    public const int ProcessPowerThrottling = 4;
    public const uint PROCESS_POWER_THROTTLING_CURRENT_VERSION = 1;
    public const uint PROCESS_POWER_THROTTLING_IGNORE_TIMER_RESOLUTION = 0x00000004;
}
"@ -ErrorAction Stop
        }
        return $true
    }
    catch {
        Write-TerminalLog "timer native load failed: $($_.Exception.Message)" (Get-StatusColor "WARN")
        return $false
    }
}

function Apply-ProcessTimerPolicy {
    if (-not (Ensure-GuiNativeTimer)) { return $false }

    try {
        $state = New-Object GamingStatusGuiProcessPowerThrottlingState
        $state.Version = [GamingStatusGuiNativeTimer]::PROCESS_POWER_THROTTLING_CURRENT_VERSION
        $state.ControlMask = [GamingStatusGuiNativeTimer]::PROCESS_POWER_THROTTLING_IGNORE_TIMER_RESOLUTION
        $state.StateMask = 0

        $size = [Runtime.InteropServices.Marshal]::SizeOf([type][GamingStatusGuiProcessPowerThrottlingState])
        $ok = [GamingStatusGuiNativeTimer]::SetProcessInformation(
            [GamingStatusGuiNativeTimer]::GetCurrentProcess(),
            [GamingStatusGuiNativeTimer]::ProcessPowerThrottling,
            [ref]$state,
            $size
        )

        $script:ProcessTimerPolicyApplied = [bool]$ok
        if ($ok) {
            $script:ProcessTimerPolicyError = $null
            Write-TerminalLog "process timer policy fixed: IGNORE_TIMER_RESOLUTION disabled" (Get-StatusColor "OK")
        }
        else {
            $script:ProcessTimerPolicyError = [Runtime.InteropServices.Marshal]::GetLastWin32Error()
            Write-TerminalLog "process timer policy failed: Win32 $script:ProcessTimerPolicyError" (Get-StatusColor "WARN")
        }

        Update-SolverView -Report $script:LastReport
        return [bool]$ok
    }
    catch {
        $script:ProcessTimerPolicyApplied = $false
        $script:ProcessTimerPolicyError = $_.Exception.Message
        Write-TerminalLog "process timer policy failed: $script:ProcessTimerPolicyError" (Get-StatusColor "WARN")
        Update-SolverView -Report $script:LastReport
        return $false
    }
}

function Set-TimerHold {
    param([bool]$Enabled)

    if (-not (Ensure-GuiNativeTimer)) { return }

    try {
        if ($Enabled) {
            Apply-ProcessTimerPolicy | Out-Null
        }

        [uint32]$current = 0
        $status = [GamingStatusGuiNativeTimer]::NtSetTimerResolution(5000, $Enabled, [ref]$current)
        if ($status -eq 0) {
            $script:TimerHoldActive = $Enabled
            $script:TimerHoldCurrentMs = [Math]::Round($current / 10000.0, 4)
            if ($Enabled) {
                Write-TerminalLog "timer hold active at $script:TimerHoldCurrentMs ms" (Get-StatusColor "OK")
            }
            else {
                Write-TerminalLog "timer hold released; current reported $script:TimerHoldCurrentMs ms" (Get-StatusColor "INFO")
            }
            Update-SolverView -Report $script:LastReport
        }
        else {
            Write-TerminalLog "NtSetTimerResolution failed with status $status" (Get-StatusColor "WARN")
        }
    }
    catch {
        Write-TerminalLog "timer hold failed: $($_.Exception.Message)" (Get-StatusColor "WARN")
    }
}

function Invoke-SolverProcess {
    param(
        [string]$FilePath,
        [string[]]$Arguments
    )

    try {
        $psi = New-Object Diagnostics.ProcessStartInfo
        $psi.FileName = $FilePath
        $psi.Arguments = (($Arguments | ForEach-Object { Quote-Arg ([string]$_) }) -join " ")
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError = $true
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow = $true
        $process = [Diagnostics.Process]::Start($psi)
        $stdout = $process.StandardOutput.ReadToEnd()
        $stderr = $process.StandardError.ReadToEnd()
        $process.WaitForExit()
        Write-TerminalLog "$FilePath $($psi.Arguments) -> exit $($process.ExitCode)" ([Drawing.Color]::FromArgb(112, 210, 160))
        foreach ($line in (($stdout + "`n" + $stderr) -split "`r?`n")) {
            if ($line.Trim()) { Write-TerminalLog $line ([Drawing.Color]::FromArgb(170, 244, 198)) }
        }
        return $process.ExitCode
    }
    catch {
        Write-TerminalLog "solver command failed: $($_.Exception.Message)" (Get-StatusColor "WARN")
        return 1
    }
}

function Copy-TimerSolverCommands {
    $text = @(
        "REM GamingStatusBench timer baseline commands",
        "REM Run as Administrator. Reboot after BCDEdit changes.",
        "REM Optional Windows 11 legacy global timer mode for old apps/tests:",
        "reg add `"HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel`" /v GlobalTimerResolutionRequests /t REG_DWORD /d 1 /f",
        "REM Revert optional global mode:",
        "reg delete `"HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel`" /v GlobalTimerResolutionRequests /f",
        "bcdedit /set disabledynamictick yes",
        "bcdedit /deletevalue useplatformclock",
        "bcdedit /deletevalue useplatformtick",
        "powercfg /GETACTIVESCHEME",
        "powercfg /query SCHEME_CURRENT SUB_PROCESSOR PROCTHROTTLEMIN",
        "powercfg /query SCHEME_CURRENT SUB_PROCESSOR PROCTHROTTLEMAX"
    ) -join "`r`n"
    [System.Windows.Forms.Clipboard]::SetText($text)
    Write-TerminalLog "timer solver commands copied"
}

function Apply-GlobalTimerResolutionRequests {
    if (-not (Test-IsAdmin)) {
        [System.Windows.Forms.MessageBox]::Show("Admin rights are required. Use the ADMIN button first.", "Solver", "OK", "Warning") | Out-Null
        return
    }

    $message = "Enable Windows 11 legacy global timer mode?`r`n`r`nThis writes:`r`nHKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel`r`nGlobalTimerResolutionRequests = 1`r`n`r`nUse this when external tools or older games still show Sleep(1) around 15.6 ms while timer resolution reports 0.5 ms.`r`n`r`nReboot is required. This can increase power use while a high timer request is active."
    $answer = [System.Windows.Forms.MessageBox]::Show($message, "Confirm global timer mode", "YesNo", "Warning")
    if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) {
        Write-TerminalLog "global timer mode cancelled" (Get-StatusColor "INFO")
        return
    }

    Invoke-SolverProcess "reg.exe" @(
        "add",
        "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel",
        "/v", "GlobalTimerResolutionRequests",
        "/t", "REG_DWORD",
        "/d", "1",
        "/f"
    ) | Out-Null

    [System.Windows.Forms.MessageBox]::Show("Global timer mode was written. Reboot before retesting the external Sleep(1) tool.", "Solver", "OK", "Information") | Out-Null
}

function Apply-BcdeditBaseline {
    if (-not (Test-IsAdmin)) {
        [System.Windows.Forms.MessageBox]::Show("Admin rights are required. Use the ADMIN button first.", "Solver", "OK", "Warning") | Out-Null
        return
    }

    $message = "Apply timer boot baseline?`r`n`r`nThis runs:`r`nbcdedit /set disabledynamictick yes`r`nbcdedit /deletevalue useplatformclock`r`nbcdedit /deletevalue useplatformtick`r`n`r`nA reboot is required. Existing missing values may print harmless errors."
    $answer = [System.Windows.Forms.MessageBox]::Show($message, "Confirm BCDEdit baseline", "YesNo", "Warning")
    if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) {
        Write-TerminalLog "BCDEdit baseline cancelled" (Get-StatusColor "INFO")
        return
    }

    Invoke-SolverProcess "bcdedit.exe" @("/set", "disabledynamictick", "yes") | Out-Null
    Invoke-SolverProcess "bcdedit.exe" @("/deletevalue", "useplatformclock") | Out-Null
    Invoke-SolverProcess "bcdedit.exe" @("/deletevalue", "useplatformtick") | Out-Null
    [System.Windows.Forms.MessageBox]::Show("BCDEdit baseline attempted. Reboot before trusting timer results.", "Solver", "OK", "Information") | Out-Null
}

function Update-SolverView {
    param([object]$Report)

    if ($null -eq $script:SolverBox) { return }

    $timer = Get-JsonValue $Report @("Sections", "Timer", "NtQueryTimerResolution", "CurrentMs")
    $sleep = Get-JsonValue $Report @("Sections", "Timer", "SleepJitter", "P95Ms")
    $wait = Get-JsonValue $Report @("Sections", "Timer", "HighResolutionWaitableTimer", "P95Ms")
    $waitMethod = Get-JsonValue $Report @("Sections", "Timer", "HighResolutionWaitableTimer", "Method")
    $waitError = Get-JsonValue $Report @("Sections", "Timer", "HighResolutionWaitableTimer", "ErrorCode")
    $waitFallback = Get-JsonValue $Report @("Sections", "Timer", "HighResolutionWaitableTimer", "FallbackUsed")
    $waitTimerRequest = Get-JsonValue $Report @("Sections", "Timer", "HighResolutionWaitableTimer", "TimerRequestActive")
    $waitTimerRequestMs = Get-JsonValue $Report @("Sections", "Timer", "HighResolutionWaitableTimer", "TimerRequestCurrentMs")
    $reportPolicyApplied = Get-JsonValue $Report @("Sections", "Timer", "ProcessTimerPolicy", "Applied")
    $reportPolicyError = Get-JsonValue $Report @("Sections", "Timer", "ProcessTimerPolicy", "ErrorCode")
    $reportPolicyNote = Get-JsonValue $Report @("Sections", "Timer", "ProcessTimerPolicy", "Note")
    $globalTimerValue = Get-JsonValue $Report @("Sections", "Timer", "GlobalTimerResolutionRequests", "Value")
    $globalTimerEnabled = Get-JsonValue $Report @("Sections", "Timer", "GlobalTimerResolutionRequests", "Enabled")
    $analysisOverall = Get-JsonValue $Report @("Analysis", "Timer", "Summary", "Overall")
    $analysisGlobalMode = Get-JsonValue $Report @("Analysis", "Timer", "Summary", "GlobalTimerMode")
    $analysisExternalSleep = Get-JsonValue $Report @("Analysis", "Timer", "Summary", "ExternalSleepTester")
    $analysisRemainingJitter = Get-JsonValue $Report @("Analysis", "Timer", "Summary", "RemainingJitter")
    $actionVerdict = Get-JsonValue $Report @("Analysis", "ActionGuide", "Summary", "Verdict")
    $mustFix = Get-JsonValue $Report @("Analysis", "ActionGuide", "Summary", "MustFix")
    $shouldFix = Get-JsonValue $Report @("Analysis", "ActionGuide", "Summary", "ShouldFix")
    $reviewCount = Get-JsonValue $Report @("Analysis", "ActionGuide", "Summary", "Review")
    $optionalCount = Get-JsonValue $Report @("Analysis", "ActionGuide", "Summary", "Optional")
    $dynamicTick = Get-JsonValue $Report @("Sections", "Kernel", "Parsed", "disabledynamictick")
    $platformClock = Get-JsonValue $Report @("Sections", "Kernel", "Parsed", "useplatformclock")
    $platformTick = Get-JsonValue $Report @("Sections", "Kernel", "Parsed", "useplatformtick")
    $vbs = Get-JsonValue $Report @("Sections", "Security", "DeviceGuard", "VirtualizationBasedSecurityStatus")

    $state = "NO REPORT"
    $stateColor = "INFO"
    if ($null -ne $timer -and $timer -le 1.0 -and $null -ne $wait -and $wait -ge 10.0) {
        $state = "MIXED TIMER STATE"
        $stateColor = "WARN"
    }
    elseif ($null -ne $timer -and $timer -le 1.0 -and $null -ne $sleep -and $sleep -le 2.5 -and $null -ne $wait -and $wait -le 2.5) {
        $state = "CLEAN HIGH-RES TIMER"
        $stateColor = "OK"
    }
    elseif ($null -ne $timer) {
        $state = "CHECK TIMER WAKE PATHS"
        $stateColor = "WARN"
    }

    $bootBaselineOk = (
        [string]$dynamicTick -match "Yes|Ja|true|1" -and
        -not $platformClock -and
        -not $platformTick
    )
    $apiRejected = ($waitFallback -eq $true -and [int]$waitError -eq 87)

    $script:SolverStatusLabel.Text = "solver: $state"
    $script:SolverStatusLabel.ForeColor = Get-StatusColor $stateColor

    $timerHold = if ($script:TimerHoldActive) { "active at $script:TimerHoldCurrentMs ms" } else { "off" }
    $guiPolicyLine = if ($script:ProcessTimerPolicyApplied) {
        "OK - GUI process has IGNORE_TIMER_RESOLUTION disabled"
    }
    elseif ($script:ProcessTimerPolicyError) {
        "CHECK - GUI apply failed: $script:ProcessTimerPolicyError"
    }
    else {
        "not applied in GUI yet"
    }
    $reportPolicyLine = if ($reportPolicyApplied -eq $true) {
        "OK - scan process disabled IGNORE_TIMER_RESOLUTION"
    }
    elseif ($null -ne $reportPolicyApplied) {
        "CHECK - scan process could not apply policy ($reportPolicyError)"
    }
    else {
        "not present in latest report"
    }
    $globalTimerLine = if ($globalTimerEnabled -eq $true) {
        "OK - GlobalTimerResolutionRequests=1, reboot must have happened after set"
    }
    elseif ($null -ne $globalTimerValue) {
        "CHECK - value is $globalTimerValue, expected 1 for legacy global mode"
    }
    else {
        "OFF - external old apps/tests may still Sleep(1) at ~15.6 ms"
    }
    $bootLine = if ($bootBaselineOk) {
        "OK - disabledynamictick is set and platform clock/tick are not forced"
    }
    else {
        "CHECK - use COPY CMDS or APPLY BCDEDIT only if you want the baseline"
    }
    $apiLine = if ($apiRejected) {
        if ($null -ne $wait -and $wait -le 2.5) {
            "REJECTED - high-res flag returns Win32 87, but fallback now wakes fast"
        }
        else {
            "REJECTED - high-res flag returns Win32 87; fix process timer policy and retest"
        }
    }
    else {
        "not rejected in latest report"
    }
    $actionLine = if ($globalTimerEnabled -ne $true -and $null -ne $timer -and $timer -le 1.0 -and $null -ne $sleep -and $sleep -le 2.5 -and $null -ne $wait -and $wait -le 2.5) {
        "For external testers still showing 15.6 ms, apply GLOBAL MODE, reboot, then retest that external tool."
    }
    elseif ($apiRejected -and $bootBaselineOk -and $null -ne $wait -and $wait -ge 10.0) {
        "Use FIX PROC POLICY first. This is a per-process Windows 11 timer behavior, not a BCDEdit-first problem."
    }
    elseif ($null -ne $wait -and $wait -le 2.5) {
        "No BCDEdit fix is recommended from this report. The scan process wake path is clean."
    }
    else {
        "Apply only one change at a time, reboot after BCDEdit, then retest."
    }

    $lines = @(
        "Timer solver",
        "============",
        "Action guide: $actionVerdict",
        "Actions: MUST $mustFix | SHOULD $shouldFix | REVIEW $reviewCount | OPTIONAL $optionalCount",
        "Legend: MUST FIX=change now | SHOULD FIX=fix before trusting | REVIEW=retest/check | OPTIONAL=A/B only | KEEP=leave",
        "",
        "State: $state",
        "Analysis: $analysisOverall",
        "Global timer mode: $analysisGlobalMode",
        "External Sleep tester: $analysisExternalSleep",
        "Remaining jitter: $analysisRemainingJitter",
        "",
        "Timer hold: $timerHold",
        "GUI process policy: $guiPolicyLine",
        "Scan process policy: $reportPolicyLine",
        "Global timer mode: $globalTimerLine",
        "Boot baseline: $bootLine",
        "High-res waitable API: $apiLine",
        "",
        "Last report:",
        "  NtQueryTimerResolution: $timer ms",
        "  Thread.Sleep(1) p95:    $sleep ms",
        "  Waitable timer p95:     $wait ms",
        "  Waitable method:        $waitMethod",
        "  Waitable error:         $waitError",
        "  Waitable timer request: $waitTimerRequest at $waitTimerRequestMs ms",
        "  Policy note:            $reportPolicyNote",
        "",
        "Boot/kernel:",
        "  disabledynamictick:     $dynamicTick",
        "  useplatformclock:       $platformClock",
        "  useplatformtick:        $platformTick",
        "  VBS status:             $vbs",
        "",
        "Recommended order:",
        "  0. $actionLine",
        "  1. Use FIX PROC POLICY for this GUI/process, then RUN RETEST.",
        "  2. Use HOLD 0.5MS during tests if the current process needs a timer request.",
        "  3. If another timer tester still shows 15.6 ms, use APPLY GLOBAL MODE and reboot.",
        "  4. Keep disabledynamictick=yes for repeatable benchmark profiles.",
        "  5. Keep useplatformclock/useplatformtick deleted unless you measured a win.",
        "  6. Reboot after registry/BCDEdit changes, then run a timer-only retest.",
        "  7. For final game proof, compare CapFrameX/PresentMon/LDAT style evidence.",
        "",
        "Important:",
        "  Windows can report 0.5 ms globally while a specific process still wakes coarse.",
        "  GLOBAL MODE is for legacy apps/tests that do not make their own timer request."
    )

    $script:SolverBox.Text = ($lines -join "`r`n")
}

$bg = [Drawing.Color]::FromArgb(4, 7, 7)
$panel = [Drawing.Color]::FromArgb(8, 13, 12)
$panel2 = [Drawing.Color]::FromArgb(13, 21, 19)
$line = [Drawing.Color]::FromArgb(35, 75, 58)
$green = [Drawing.Color]::FromArgb(98, 255, 153)
$muted = [Drawing.Color]::FromArgb(118, 172, 142)
$cyan = [Drawing.Color]::FromArgb(99, 208, 255)
$amber = [Drawing.Color]::FromArgb(247, 199, 91)
$red = [Drawing.Color]::FromArgb(255, 94, 94)

$script:Form = New-Object System.Windows.Forms.Form
$script:Form.Text = "Gaming Status Bench // terminal GUI"
$script:Form.StartPosition = "CenterScreen"
$script:Form.MinimumSize = New-Object Drawing.Size(1080, 720)
$script:Form.Size = New-Object Drawing.Size(1240, 820)
$script:Form.BackColor = $bg
$script:Form.ForeColor = $green
$script:Form.Font = New-Object Drawing.Font("Consolas", 9)
$script:Form.Add_FormClosing({
    if ($script:TimerHoldActive) {
        Set-TimerHold $false
    }
})

$top = New-Object System.Windows.Forms.Panel
$top.Dock = "Top"
$top.Height = 86
$top.BackColor = $panel
$top.Padding = New-Object System.Windows.Forms.Padding(14, 10, 14, 10)
$script:Form.Controls.Add($top)

$title = New-Object System.Windows.Forms.Label
$title.Text = "GAMING STATUS BENCH"
$title.Font = New-Object Drawing.Font("Consolas", 20, [Drawing.FontStyle]::Bold)
$title.ForeColor = $green
$title.Location = New-Object Drawing.Point(16, 10)
$title.Size = New-Object Drawing.Size(420, 32)
$top.Controls.Add($title)

$script:StatusLabel = New-Object System.Windows.Forms.Label
$script:StatusLabel.Text = "READY"
$script:StatusLabel.Font = New-Object Drawing.Font("Consolas", 16, [Drawing.FontStyle]::Bold)
$script:StatusLabel.ForeColor = $cyan
$script:StatusLabel.TextAlign = "MiddleRight"
$script:StatusLabel.Anchor = "Top,Right"
$script:StatusLabel.Location = New-Object Drawing.Point(934, 13)
$script:StatusLabel.Size = New-Object Drawing.Size(270, 28)
$top.Controls.Add($script:StatusLabel)

$script:HostLabel = New-Object System.Windows.Forms.Label
$script:HostLabel.Text = "host pending | admin=$(Test-IsAdmin) | reports: $script:OutputDir"
$script:HostLabel.ForeColor = $muted
$script:HostLabel.Location = New-Object Drawing.Point(18, 50)
$script:HostLabel.Size = New-Object Drawing.Size(960, 22)
$top.Controls.Add($script:HostLabel)

$body = New-Object System.Windows.Forms.TableLayoutPanel
$body.Dock = "Fill"
$body.ColumnCount = 2
$body.RowCount = 1
$body.BackColor = $bg
$body.Margin = New-Object System.Windows.Forms.Padding(0)
$body.Padding = New-Object System.Windows.Forms.Padding(0)
$body.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 330))) | Out-Null
$body.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$body.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$script:Form.Controls.Add($body)

$left = New-Object System.Windows.Forms.Panel
$left.Dock = "Fill"
$left.BackColor = $panel
$left.Padding = New-Object System.Windows.Forms.Padding(12)
$body.Controls.Add($left, 0, 0)

$configLabel = New-Object System.Windows.Forms.Label
$configLabel.Text = "SCAN CONFIG"
$configLabel.ForeColor = $cyan
$configLabel.Font = New-Object Drawing.Font("Consolas", 11, [Drawing.FontStyle]::Bold)
$configLabel.Location = New-Object Drawing.Point(12, 12)
$configLabel.Size = New-Object Drawing.Size(280, 24)
$left.Controls.Add($configLabel)

$gameLabel = New-Object System.Windows.Forms.Label
$gameLabel.Text = "game exe paths (optional; newline/semicolon)"
$gameLabel.ForeColor = $muted
$gameLabel.Location = New-Object Drawing.Point(12, 46)
$gameLabel.Size = New-Object Drawing.Size(290, 18)
$left.Controls.Add($gameLabel)

$script:GameExeBox = New-Object System.Windows.Forms.TextBox
$script:GameExeBox.Multiline = $true
$script:GameExeBox.ScrollBars = "Vertical"
$script:GameExeBox.BackColor = [Drawing.Color]::Black
$script:GameExeBox.ForeColor = $green
$script:GameExeBox.BorderStyle = "FixedSingle"
$script:GameExeBox.Font = New-Object Drawing.Font("Consolas", 9)
$script:GameExeBox.Location = New-Object Drawing.Point(12, 68)
$script:GameExeBox.Size = New-Object Drawing.Size(295, 88)
$script:GameExeBox.Anchor = "Top,Left,Right"
$left.Controls.Add($script:GameExeBox)

$pingLabel = New-Object System.Windows.Forms.Label
$pingLabel.Text = "ping targets"
$pingLabel.ForeColor = $muted
$pingLabel.Location = New-Object Drawing.Point(12, 170)
$pingLabel.Size = New-Object Drawing.Size(110, 18)
$left.Controls.Add($pingLabel)

$script:PingTargetBox = New-Object System.Windows.Forms.TextBox
$script:PingTargetBox.Text = "1.1.1.1, 8.8.8.8"
$script:PingTargetBox.BackColor = [Drawing.Color]::Black
$script:PingTargetBox.ForeColor = $green
$script:PingTargetBox.BorderStyle = "FixedSingle"
$script:PingTargetBox.Font = New-Object Drawing.Font("Consolas", 9)
$script:PingTargetBox.Location = New-Object Drawing.Point(12, 192)
$script:PingTargetBox.Size = New-Object Drawing.Size(295, 22)
$script:PingTargetBox.Anchor = "Top,Left,Right"
$left.Controls.Add($script:PingTargetBox)

$script:NetworkBox = New-Object System.Windows.Forms.CheckBox
$script:NetworkBox.Text = "network benchmark"
$script:NetworkBox.Checked = $true
$script:NetworkBox.ForeColor = $green
$script:NetworkBox.Location = New-Object Drawing.Point(12, 226)
$script:NetworkBox.Size = New-Object Drawing.Size(190, 22)
$left.Controls.Add($script:NetworkBox)

$pingCountLabel = New-Object System.Windows.Forms.Label
$pingCountLabel.Text = "ping count"
$pingCountLabel.ForeColor = $muted
$pingCountLabel.Location = New-Object Drawing.Point(12, 262)
$pingCountLabel.Size = New-Object Drawing.Size(110, 18)
$left.Controls.Add($pingCountLabel)

$script:PingCountBox = New-Object System.Windows.Forms.NumericUpDown
$script:PingCountBox.Minimum = 1
$script:PingCountBox.Maximum = 30
$script:PingCountBox.Value = 8
$script:PingCountBox.BackColor = [Drawing.Color]::Black
$script:PingCountBox.ForeColor = $green
$script:PingCountBox.BorderStyle = "FixedSingle"
$script:PingCountBox.Location = New-Object Drawing.Point(150, 258)
$script:PingCountBox.Size = New-Object Drawing.Size(78, 22)
$left.Controls.Add($script:PingCountBox)

$timerLabel = New-Object System.Windows.Forms.Label
$timerLabel.Text = "timer samples"
$timerLabel.ForeColor = $muted
$timerLabel.Location = New-Object Drawing.Point(12, 292)
$timerLabel.Size = New-Object Drawing.Size(130, 18)
$left.Controls.Add($timerLabel)

$script:TimerSamplesBox = New-Object System.Windows.Forms.NumericUpDown
$script:TimerSamplesBox.Minimum = 10
$script:TimerSamplesBox.Maximum = 2000
$script:TimerSamplesBox.Increment = 10
$script:TimerSamplesBox.Value = 300
$script:TimerSamplesBox.BackColor = [Drawing.Color]::Black
$script:TimerSamplesBox.ForeColor = $green
$script:TimerSamplesBox.BorderStyle = "FixedSingle"
$script:TimerSamplesBox.Location = New-Object Drawing.Point(150, 288)
$script:TimerSamplesBox.Size = New-Object Drawing.Size(78, 22)
$left.Controls.Add($script:TimerSamplesBox)

$script:RunButton = New-Object System.Windows.Forms.Button
$script:RunButton.Text = "RUN SCAN"
$script:RunButton.Location = New-Object Drawing.Point(12, 334)
$script:RunButton.Size = New-Object Drawing.Size(140, 34)
Set-FlatButtonStyle $script:RunButton $green
$script:RunButton.Add_Click({ Start-GuiScan })
$left.Controls.Add($script:RunButton)

$script:AdminButton = New-Object System.Windows.Forms.Button
$script:AdminButton.Text = "ADMIN"
$script:AdminButton.Location = New-Object Drawing.Point(166, 334)
$script:AdminButton.Size = New-Object Drawing.Size(95, 34)
Set-FlatButtonStyle $script:AdminButton $amber
$script:AdminButton.Add_Click({ Restart-AsAdmin })
$left.Controls.Add($script:AdminButton)

$script:OpenHtmlButton = New-Object System.Windows.Forms.Button
$script:OpenHtmlButton.Text = "OPEN HTML"
$script:OpenHtmlButton.Location = New-Object Drawing.Point(12, 382)
$script:OpenHtmlButton.Size = New-Object Drawing.Size(140, 34)
$script:OpenHtmlButton.Enabled = $false
Set-FlatButtonStyle $script:OpenHtmlButton $cyan
$script:OpenHtmlButton.Add_Click({ Open-Path $script:LastHtmlPath })
$left.Controls.Add($script:OpenHtmlButton)

$script:OpenJsonButton = New-Object System.Windows.Forms.Button
$script:OpenJsonButton.Text = "OPEN JSON"
$script:OpenJsonButton.Location = New-Object Drawing.Point(166, 382)
$script:OpenJsonButton.Size = New-Object Drawing.Size(140, 34)
$script:OpenJsonButton.Enabled = $false
Set-FlatButtonStyle $script:OpenJsonButton $cyan
$script:OpenJsonButton.Add_Click({ Open-Path $script:LastJsonPath })
$left.Controls.Add($script:OpenJsonButton)

$reportsButton = New-Object System.Windows.Forms.Button
$reportsButton.Text = "REPORTS"
$reportsButton.Location = New-Object Drawing.Point(12, 430)
$reportsButton.Size = New-Object Drawing.Size(140, 34)
Set-FlatButtonStyle $reportsButton $muted
$reportsButton.Add_Click({ Open-Path $script:OutputDir })
$left.Controls.Add($reportsButton)

$script:CopySummaryButton = New-Object System.Windows.Forms.Button
$script:CopySummaryButton.Text = "COPY SUM"
$script:CopySummaryButton.Location = New-Object Drawing.Point(166, 430)
$script:CopySummaryButton.Size = New-Object Drawing.Size(140, 34)
$script:CopySummaryButton.Enabled = $false
Set-FlatButtonStyle $script:CopySummaryButton $muted
$script:CopySummaryButton.Add_Click({ Copy-Summary })
$left.Controls.Add($script:CopySummaryButton)

$hint = New-Object System.Windows.Forms.Label
$hint.Text = "Quick answer: scan is read-only. It finds common Windows gaming/latency setup problems and tells you what to keep, review, or fix."
$hint.ForeColor = $muted
$hint.Location = New-Object Drawing.Point(12, 484)
$hint.Size = New-Object Drawing.Size(295, 80)
$hint.Anchor = "Top,Left,Right"
$left.Controls.Add($hint)

$right = New-Object System.Windows.Forms.Panel
$right.Dock = "Fill"
$right.BackColor = $bg
$right.Padding = New-Object System.Windows.Forms.Padding(12, 12, 14, 12)
$body.Controls.Add($right, 1, 0)

$rightLayout = New-Object System.Windows.Forms.TableLayoutPanel
$rightLayout.Dock = "Fill"
$rightLayout.ColumnCount = 1
$rightLayout.RowCount = 2
$rightLayout.BackColor = $bg
$rightLayout.Margin = New-Object System.Windows.Forms.Padding(0)
$rightLayout.Padding = New-Object System.Windows.Forms.Padding(0)
$rightLayout.ColumnStyles.Clear()
$rightLayout.RowStyles.Clear()
$rightLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$rightLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 112))) | Out-Null
$rightLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$right.Controls.Add($rightLayout)

$summary = New-Object System.Windows.Forms.Panel
$summary.Dock = "Fill"
$summary.Height = 112
$summary.BackColor = $bg
$rightLayout.Controls.Add($summary, 0, 0)

$script:OkLabel = New-Object System.Windows.Forms.Label
$script:OkLabel.Text = "OK 0"
$script:OkLabel.Font = New-Object Drawing.Font("Consolas", 18, [Drawing.FontStyle]::Bold)
$script:OkLabel.Location = New-Object Drawing.Point(10, 8)
$script:OkLabel.Size = New-Object Drawing.Size(130, 32)
$summary.Controls.Add($script:OkLabel)

$script:WarnLabel = New-Object System.Windows.Forms.Label
$script:WarnLabel.Text = "WARN 0"
$script:WarnLabel.Font = New-Object Drawing.Font("Consolas", 18, [Drawing.FontStyle]::Bold)
$script:WarnLabel.Location = New-Object Drawing.Point(150, 8)
$script:WarnLabel.Size = New-Object Drawing.Size(150, 32)
$summary.Controls.Add($script:WarnLabel)

$script:FailLabel = New-Object System.Windows.Forms.Label
$script:FailLabel.Text = "FAIL 0"
$script:FailLabel.Font = New-Object Drawing.Font("Consolas", 18, [Drawing.FontStyle]::Bold)
$script:FailLabel.Location = New-Object Drawing.Point(315, 8)
$script:FailLabel.Size = New-Object Drawing.Size(140, 32)
$summary.Controls.Add($script:FailLabel)

$script:InfoLabel = New-Object System.Windows.Forms.Label
$script:InfoLabel.Text = "INFO 0"
$script:InfoLabel.Font = New-Object Drawing.Font("Consolas", 18, [Drawing.FontStyle]::Bold)
$script:InfoLabel.Location = New-Object Drawing.Point(470, 8)
$script:InfoLabel.Size = New-Object Drawing.Size(140, 32)
$summary.Controls.Add($script:InfoLabel)

$script:UnknownLabel = New-Object System.Windows.Forms.Label
$script:UnknownLabel.Text = "UNKNOWN 0"
$script:UnknownLabel.Font = New-Object Drawing.Font("Consolas", 18, [Drawing.FontStyle]::Bold)
$script:UnknownLabel.Location = New-Object Drawing.Point(625, 8)
$script:UnknownLabel.Size = New-Object Drawing.Size(180, 32)
$summary.Controls.Add($script:UnknownLabel)

$script:TimerLabel = New-Object System.Windows.Forms.Label
$script:TimerLabel.Text = "timer pending"
$script:TimerLabel.ForeColor = $green
$script:TimerLabel.Location = New-Object Drawing.Point(12, 52)
$script:TimerLabel.Size = New-Object Drawing.Size(620, 20)
$summary.Controls.Add($script:TimerLabel)

$script:DisplayLabel = New-Object System.Windows.Forms.Label
$script:DisplayLabel.Text = "display pending"
$script:DisplayLabel.ForeColor = $muted
$script:DisplayLabel.Location = New-Object Drawing.Point(390, 52)
$script:DisplayLabel.Size = New-Object Drawing.Size(480, 20)
$summary.Controls.Add($script:DisplayLabel)

$script:NetworkLabel = New-Object System.Windows.Forms.Label
$script:NetworkLabel.Text = "network pending"
$script:NetworkLabel.ForeColor = $muted
$script:NetworkLabel.Location = New-Object Drawing.Point(12, 78)
$script:NetworkLabel.Size = New-Object Drawing.Size(720, 20)
$summary.Controls.Add($script:NetworkLabel)

$tabs = New-Object System.Windows.Forms.TabControl
$tabs.Dock = "Fill"
$tabs.Appearance = "Normal"
$tabs.BackColor = $bg
$tabs.ForeColor = $green
$tabs.Margin = New-Object System.Windows.Forms.Padding(0, 8, 0, 0)
$rightLayout.Controls.Add($tabs, 0, 1)

$findingsTab = New-Object System.Windows.Forms.TabPage
$findingsTab.Text = "findings"
$findingsTab.BackColor = $bg
$findingsTab.Padding = New-Object System.Windows.Forms.Padding(6, 8, 6, 6)
$tabs.TabPages.Add($findingsTab) | Out-Null

$script:FindingsList = New-Object System.Windows.Forms.ListView
$script:FindingsList.Dock = "Fill"
$script:FindingsList.View = "Details"
$script:FindingsList.FullRowSelect = $true
$script:FindingsList.GridLines = $true
$script:FindingsList.BackColor = [Drawing.Color]::Black
$script:FindingsList.ForeColor = $green
$script:FindingsList.Font = New-Object Drawing.Font("Consolas", 9)
$script:FindingsList.Columns.Add("status", 72) | Out-Null
$script:FindingsList.Columns.Add("decision", 112) | Out-Null
$script:FindingsList.Columns.Add("area", 130) | Out-Null
$script:FindingsList.Columns.Add("name", 260) | Out-Null
$script:FindingsList.Columns.Add("value", 170) | Out-Null
$script:FindingsList.Columns.Add("action", 420) | Out-Null
$script:FindingsList.Columns.Add("note", 420) | Out-Null
$findingsTab.Controls.Add($script:FindingsList)

$solverTab = New-Object System.Windows.Forms.TabPage
$solverTab.Text = "solver"
$solverTab.BackColor = $bg
$solverTab.Padding = New-Object System.Windows.Forms.Padding(8)
$tabs.TabPages.Add($solverTab) | Out-Null

$solverLayout = New-Object System.Windows.Forms.TableLayoutPanel
$solverLayout.Dock = "Fill"
$solverLayout.ColumnCount = 1
$solverLayout.RowCount = 3
$solverLayout.BackColor = $bg
$solverLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$solverLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 38))) | Out-Null
$solverLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$solverLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 92))) | Out-Null
$solverTab.Controls.Add($solverLayout)

$script:SolverStatusLabel = New-Object System.Windows.Forms.Label
$script:SolverStatusLabel.Text = "solver: no report"
$script:SolverStatusLabel.Dock = "Fill"
$script:SolverStatusLabel.ForeColor = $cyan
$script:SolverStatusLabel.Font = New-Object Drawing.Font("Consolas", 13, [Drawing.FontStyle]::Bold)
$solverLayout.Controls.Add($script:SolverStatusLabel, 0, 0)

$script:SolverBox = New-Object System.Windows.Forms.RichTextBox
$script:SolverBox.Dock = "Fill"
$script:SolverBox.ReadOnly = $true
$script:SolverBox.BackColor = [Drawing.Color]::Black
$script:SolverBox.ForeColor = $green
$script:SolverBox.BorderStyle = "FixedSingle"
$script:SolverBox.Font = New-Object Drawing.Font("Consolas", 9)
$script:SolverBox.Text = "Run a scan, then open this tab for timer/network/display solver actions."
$solverLayout.Controls.Add($script:SolverBox, 0, 1)

$solverButtons = New-Object System.Windows.Forms.FlowLayoutPanel
$solverButtons.Dock = "Fill"
$solverButtons.BackColor = $bg
$solverButtons.FlowDirection = "LeftToRight"
$solverButtons.WrapContents = $true
$solverButtons.Padding = New-Object System.Windows.Forms.Padding(0, 10, 0, 0)
$solverLayout.Controls.Add($solverButtons, 0, 2)

$processPolicyButton = New-Object System.Windows.Forms.Button
$processPolicyButton.Text = "FIX PROC POLICY"
$processPolicyButton.Size = New-Object Drawing.Size(155, 34)
Set-FlatButtonStyle $processPolicyButton $cyan
$processPolicyButton.Add_Click({ Apply-ProcessTimerPolicy | Out-Null })
$solverButtons.Controls.Add($processPolicyButton)

$timerHoldButton = New-Object System.Windows.Forms.Button
$timerHoldButton.Text = "HOLD 0.5MS"
$timerHoldButton.Size = New-Object Drawing.Size(130, 34)
Set-FlatButtonStyle $timerHoldButton $green
$timerHoldButton.Add_Click({ Set-TimerHold $true })
$solverButtons.Controls.Add($timerHoldButton)

$timerReleaseButton = New-Object System.Windows.Forms.Button
$timerReleaseButton.Text = "RELEASE"
$timerReleaseButton.Size = New-Object Drawing.Size(110, 34)
Set-FlatButtonStyle $timerReleaseButton $amber
$timerReleaseButton.Add_Click({ Set-TimerHold $false })
$solverButtons.Controls.Add($timerReleaseButton)

$timerRetestButton = New-Object System.Windows.Forms.Button
$timerRetestButton.Text = "RUN RETEST"
$timerRetestButton.Size = New-Object Drawing.Size(125, 34)
Set-FlatButtonStyle $timerRetestButton $cyan
$timerRetestButton.Add_Click({
    $script:NetworkBox.Checked = $false
    $script:TimerSamplesBox.Value = 120
    Start-GuiScan
})
$solverButtons.Controls.Add($timerRetestButton)

$copySolverButton = New-Object System.Windows.Forms.Button
$copySolverButton.Text = "COPY CMDS"
$copySolverButton.Size = New-Object Drawing.Size(120, 34)
Set-FlatButtonStyle $copySolverButton $muted
$copySolverButton.Add_Click({ Copy-TimerSolverCommands })
$solverButtons.Controls.Add($copySolverButton)

$applyGlobalTimerButton = New-Object System.Windows.Forms.Button
$applyGlobalTimerButton.Text = "APPLY GLOBAL MODE"
$applyGlobalTimerButton.Size = New-Object Drawing.Size(170, 34)
Set-FlatButtonStyle $applyGlobalTimerButton $red
$applyGlobalTimerButton.Add_Click({ Apply-GlobalTimerResolutionRequests })
$solverButtons.Controls.Add($applyGlobalTimerButton)

$applyBcdeditButton = New-Object System.Windows.Forms.Button
$applyBcdeditButton.Text = "APPLY BCDEDIT"
$applyBcdeditButton.Size = New-Object Drawing.Size(145, 34)
Set-FlatButtonStyle $applyBcdeditButton $red
$applyBcdeditButton.Add_Click({ Apply-BcdeditBaseline })
$solverButtons.Controls.Add($applyBcdeditButton)

$logTab = New-Object System.Windows.Forms.TabPage
$logTab.Text = "terminal"
$logTab.BackColor = $bg
$tabs.TabPages.Add($logTab) | Out-Null

$script:LogBox = New-Object System.Windows.Forms.RichTextBox
$script:LogBox.Dock = "Fill"
$script:LogBox.ReadOnly = $true
$script:LogBox.BackColor = [Drawing.Color]::Black
$script:LogBox.ForeColor = $green
$script:LogBox.BorderStyle = "FixedSingle"
$script:LogBox.Font = New-Object Drawing.Font("Consolas", 9)
$logTab.Controls.Add($script:LogBox)

$detailsTab = New-Object System.Windows.Forms.TabPage
$detailsTab.Text = "json"
$detailsTab.BackColor = $bg
$tabs.TabPages.Add($detailsTab) | Out-Null

$script:DetailsBox = New-Object System.Windows.Forms.TextBox
$script:DetailsBox.Dock = "Fill"
$script:DetailsBox.Multiline = $true
$script:DetailsBox.ScrollBars = "Both"
$script:DetailsBox.ReadOnly = $true
$script:DetailsBox.WordWrap = $false
$script:DetailsBox.BackColor = [Drawing.Color]::Black
$script:DetailsBox.ForeColor = $green
$script:DetailsBox.BorderStyle = "FixedSingle"
$script:DetailsBox.Font = New-Object Drawing.Font("Consolas", 8.5)
$detailsTab.Controls.Add($script:DetailsBox)

Set-SummaryLabel $script:OkLabel "OK 0" "OK"
Set-SummaryLabel $script:WarnLabel "WARN 0" "WARN"
Set-SummaryLabel $script:FailLabel "FAIL 0" "FAIL"
Set-SummaryLabel $script:InfoLabel "INFO 0" "INFO"
Set-SummaryLabel $script:UnknownLabel "UNKNOWN 0" "UNKNOWN"

Write-TerminalLog "ready"
Write-TerminalLog "collector: $script:CollectorPath"
Write-TerminalLog "reports: $script:OutputDir"
if (-not (Test-IsAdmin)) {
    Write-TerminalLog "not elevated; use ADMIN button for full adapter/BCDEdit visibility" $amber
}

[void]$script:Form.ShowDialog()
