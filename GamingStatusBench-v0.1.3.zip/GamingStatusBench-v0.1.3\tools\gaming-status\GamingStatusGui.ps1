[CmdletBinding()]
param(
    [string]$OutputDir = ""
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = "Continue"

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$script:CollectorPath = Join-Path $PSScriptRoot "GamingStatus.ps1"
if (-not $OutputDir) {
    $OutputDir = Join-Path $PSScriptRoot "..\..\reports"
}
$script:OutputDir = [System.IO.Path]::GetFullPath($OutputDir)
$script:LastJsonPath = $null
$script:LastHtmlPath = $null
$script:LastReport = $null
$script:IsRunning = $false
$script:ScanTimer = $null
$script:TimerHoldActive = $false
$script:TimerHoldCurrentMs = $null
$script:ProcessTimerPolicyApplied = $false
$script:ProcessTimerPolicyError = $null
$script:CpuSet16Button = $null
$script:CpuRestoreButton = $null
$script:CopyCpuFixButton = $null

if (-not (Test-Path $script:OutputDir)) {
    New-Item -ItemType Directory -Path $script:OutputDir -Force | Out-Null
}

function Test-IsAdmin {
    try {
        $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object Security.Principal.WindowsPrincipal($identity)
        return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    }
    catch {
        return $false
    }
}

function Quote-Arg {
    param([string]$Value)
    if ($null -eq $Value) { return '""' }
    $escaped = $Value -replace '"', '\"'
    return '"' + $escaped + '"'
}

function Get-StatusColor {
    param([string]$Status)
    switch ($Status) {
        "OK" { return [Drawing.Color]::FromArgb(64, 224, 126) }
        "WARN" { return [Drawing.Color]::FromArgb(247, 199, 91) }
        "FAIL" { return [Drawing.Color]::FromArgb(255, 94, 94) }
        "INFO" { return [Drawing.Color]::FromArgb(99, 208, 255) }
        default { return [Drawing.Color]::FromArgb(190, 176, 255) }
    }
}

function Set-FlatButtonStyle {
    param(
        [System.Windows.Forms.Button]$Button,
        [Drawing.Color]$Accent
    )
    $Button.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $Button.FlatAppearance.BorderColor = $Accent
    $Button.FlatAppearance.MouseOverBackColor = [Drawing.Color]::FromArgb(28, 44, 38)
    $Button.FlatAppearance.MouseDownBackColor = [Drawing.Color]::FromArgb(42, 68, 55)
    $Button.BackColor = [Drawing.Color]::FromArgb(10, 14, 13)
    $Button.ForeColor = $Accent
    $Button.Font = New-Object Drawing.Font("Consolas", 9.5, [Drawing.FontStyle]::Bold)
    $Button.Height = 34
}

function Write-TerminalLog {
    param(
        [string]$Text,
        [Drawing.Color]$Color = [Drawing.Color]::FromArgb(170, 244, 198)
    )

    if ($null -eq $script:LogBox) { return }
    $script:LogBox.SelectionStart = $script:LogBox.TextLength
    $script:LogBox.SelectionLength = 0
    $script:LogBox.SelectionColor = $Color
    $script:LogBox.AppendText("[$((Get-Date).ToString('HH:mm:ss'))] $Text`r`n")
    $script:LogBox.SelectionColor = $script:LogBox.ForeColor
    $script:LogBox.ScrollToCaret()
}

function Get-GameExePathsFromText {
    param([string]$Text)

    $items = @()
    foreach ($part in ($Text -split "[`r`n;]+")) {
        $trimmed = $part.Trim()
        if ($trimmed) {
            $items += $trimmed
        }
    }
    return $items
}

function Get-PingTargetsFromText {
    param([string]$Text)

    $items = @()
    foreach ($part in ($Text -split "[,;`r`n ]+")) {
        $trimmed = $part.Trim()
        if ($trimmed) {
            $items += $trimmed
        }
    }
    return $items
}

function Get-GamePingProfileFromText {
    param([string]$Text)

    $trimmed = ([string]$Text).Trim()
    if (-not $trimmed -or $trimmed -eq "none") {
        return @()
    }
    return @($trimmed -split "[,;`r`n]+" | ForEach-Object { $_.Trim() } | Where-Object { $_ })
}

function Get-LatestReportJson {
    $latest = Get-ChildItem -Path $script:OutputDir -Filter "gaming-status-*.json" -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime |
        Select-Object -Last 1
    if ($latest) { return $latest.FullName }
    return $null
}

function Open-Path {
    param([string]$Path)
    if ($Path -and (Test-Path $Path)) {
        Start-Process $Path
    }
}

function Get-JsonValue {
    param(
        [object]$Object,
        [string[]]$Path
    )

    $current = $Object
    foreach ($part in $Path) {
        if ($null -eq $current) { return $null }
        $prop = $current.PSObject.Properties[$part]
        if ($null -eq $prop) { return $null }
        $current = $prop.Value
    }
    return $current
}

function Get-ObjectsWithProperty {
    param(
        [object]$Value,
        [string]$PropertyName
    )

    return @($Value | Where-Object {
        $null -ne $_ -and $null -ne $_.PSObject.Properties[$PropertyName]
    })
}

function Update-CpuSolverButtons {
    param([object]$Report)

    if ($null -eq $script:CpuSet16Button -or $null -eq $script:CpuRestoreButton) { return }

    $admin = Test-IsAdmin
    $set16Allowed = (Get-JsonValue $Report @("Sections", "CpuScheduler", "Set16Allowed")) -eq $true
    $restoreAllowed = (Get-JsonValue $Report @("Sections", "CpuScheduler", "RestoreAllowed")) -eq $true

    $script:CpuSet16Button.Enabled = ($admin -and -not $script:IsRunning -and $set16Allowed)
    $script:CpuRestoreButton.Enabled = ($admin -and -not $script:IsRunning -and $restoreAllowed)
    if ($script:CopyCpuFixButton) {
        $script:CopyCpuFixButton.Enabled = (-not $script:IsRunning)
    }
}

function Set-ScanControlsEnabled {
    param([bool]$Enabled)
    $script:RunButton.Enabled = $Enabled
    $script:AdminButton.Enabled = $Enabled
    $script:GameExeBox.Enabled = $Enabled
    $script:PingTargetBox.Enabled = $Enabled
    $script:GamePingProfileBox.Enabled = $Enabled
    $script:PingCountBox.Enabled = $Enabled
    $script:TimerSamplesBox.Enabled = $Enabled
    $script:NetworkBox.Enabled = $Enabled
    Update-CpuSolverButtons -Report $script:LastReport
}

function Set-SummaryLabel {
    param(
        [System.Windows.Forms.Label]$Label,
        [string]$Text,
        [string]$Status
    )
    $Label.Text = $Text
    $Label.ForeColor = Get-StatusColor $Status
}

function Update-ReportView {
    param([object]$Report)

    $script:LastReport = $Report
    $findings = @($Report.Findings)
    $ok = @($findings | Where-Object { $_.Status -eq "OK" }).Count
    $warn = @($findings | Where-Object { $_.Status -eq "WARN" }).Count
    $fail = @($findings | Where-Object { $_.Status -eq "FAIL" }).Count
    $info = @($findings | Where-Object { $_.Status -eq "INFO" }).Count
    $unknown = @($findings | Where-Object { $_.Status -eq "UNKNOWN" }).Count

    Set-SummaryLabel $script:OkLabel "OK $ok" "OK"
    Set-SummaryLabel $script:WarnLabel "WARN $warn" "WARN"
    Set-SummaryLabel $script:FailLabel "FAIL $fail" "FAIL"
    Set-SummaryLabel $script:InfoLabel "INFO $info" "INFO"
    Set-SummaryLabel $script:UnknownLabel "UNKNOWN $unknown" "UNKNOWN"

    $timer = Get-JsonValue $Report @("Sections", "Timer", "NtQueryTimerResolution", "CurrentMs")
    $sleepWake = Get-JsonValue $Report @("Sections", "Timer", "SleepJitter", "P95Ms")
    $waitable = Get-JsonValue $Report @("Sections", "Timer", "HighResolutionWaitableTimer", "P95Ms")
    $hostText = "$($Report.Host.ComputerName) | Admin=$($Report.Host.IsAdmin) | $($Report.Host.OS)"
    $script:HostLabel.Text = $hostText
    $script:TimerLabel.Text = "timer $timer ms | Sleep(1) p95 $sleepWake ms | waitable p95 $waitable ms"

    $gpu = @(Get-ObjectsWithProperty -Value (Get-JsonValue $Report @("Sections", "DisplayGpu", "VideoControllers")) -PropertyName "Name" | Select-Object -First 1)
    if ($gpu.Count -gt 0) {
        $script:DisplayLabel.Text = "$($gpu[0].Name) | $($gpu[0].CurrentHorizontalResolution)x$($gpu[0].CurrentVerticalResolution)@$($gpu[0].CurrentRefreshRate)Hz"
    }
    else {
        $script:DisplayLabel.Text = "display/gpu unknown"
    }

    $pings = @(Get-ObjectsWithProperty -Value (Get-JsonValue $Report @("Sections", "Network", "Ping")) -PropertyName "Target")
    if ($pings.Count -gt 0) {
        $bestPing = $pings | Sort-Object AvgMs | Select-Object -First 1
        $script:NetworkLabel.Text = "best ping $($bestPing.Target): $($bestPing.AvgMs) ms / loss $($bestPing.LossPct)%"
    }
    else {
        $script:NetworkLabel.Text = "network benchmark skipped"
    }

    $script:FindingsList.BeginUpdate()
    $script:FindingsList.Items.Clear()
    foreach ($finding in ($findings | Sort-Object Priority, Status, Area, Name)) {
        $item = New-Object System.Windows.Forms.ListViewItem([string]$finding.Status)
        $item.SubItems.Add([string]$finding.Decision) | Out-Null
        $item.SubItems.Add([string]$finding.Area) | Out-Null
        $item.SubItems.Add([string]$finding.Name) | Out-Null
        $item.SubItems.Add([string]$finding.Value) | Out-Null
        $item.SubItems.Add([string]$finding.Action) | Out-Null
        $item.SubItems.Add([string]$finding.Note) | Out-Null
        $item.ForeColor = Get-StatusColor $finding.Status
        $item.BackColor = [Drawing.Color]::FromArgb(7, 10, 10)
        $script:FindingsList.Items.Add($item) | Out-Null
    }
    $script:FindingsList.EndUpdate()

    $script:DetailsBox.Clear()
    $script:DetailsBox.AppendText(($Report | ConvertTo-Json -Depth 7))

    $script:LastJsonPath = $Report.Paths.Json
    $script:LastHtmlPath = $Report.Paths.Html
    $script:OpenJsonButton.Enabled = [bool]($script:LastJsonPath -and (Test-Path $script:LastJsonPath))
    $script:OpenHtmlButton.Enabled = [bool]($script:LastHtmlPath -and (Test-Path $script:LastHtmlPath))
    $script:CopySummaryButton.Enabled = $true
    Update-SolverView -Report $Report
    Update-FixesView -Report $Report
}

function Start-GuiScan {
    if ($script:IsRunning) { return }
    if (-not (Test-Path $script:CollectorPath)) {
        [System.Windows.Forms.MessageBox]::Show("Collector not found:`n$script:CollectorPath", "Gaming Status Bench", "OK", "Error") | Out-Null
        return
    }

    $script:IsRunning = $true
    Set-ScanControlsEnabled $false
    $script:StatusLabel.Text = "SCAN RUNNING"
    $script:StatusLabel.ForeColor = [Drawing.Color]::FromArgb(247, 199, 91)
    Write-TerminalLog "scan started"

    $gamePaths = @(Get-GameExePathsFromText $script:GameExeBox.Text)
    $pingTargets = @(Get-PingTargetsFromText $script:PingTargetBox.Text)
    $gamePingProfiles = @(Get-GamePingProfileFromText $script:GamePingProfileBox.Text)
    $pingCount = [int]$script:PingCountBox.Value
    $timerSamples = [int]$script:TimerSamplesBox.Value
    $networkEnabled = $script:NetworkBox.Checked

    $procArgs = @(
        "-NoProfile",
        "-ExecutionPolicy", "Bypass",
        "-File", (Quote-Arg $script:CollectorPath),
        "-OutputDir", (Quote-Arg $script:OutputDir),
        "-PingCount", $pingCount,
        "-TimerSampleCount", $timerSamples,
        "-Quiet"
    )

    if (-not $networkEnabled) {
        $procArgs += "-NoNetworkBenchmark"
    }

    if ($pingTargets.Count -gt 0) {
        $procArgs += "-PingTarget"
        $procArgs += (Quote-Arg ($pingTargets -join ","))
    }

    if ($gamePingProfiles.Count -gt 0) {
        $procArgs += "-GamePingProfile"
        $procArgs += (Quote-Arg ($gamePingProfiles -join ","))
    }

    if ($gamePaths.Count -gt 0) {
        $procArgs += "-GameExePath"
        $procArgs += (Quote-Arg ($gamePaths -join ";"))
    }

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = "powershell.exe"
    $psi.Arguments = ($procArgs -join " ")
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true

    try {
        $process = [Diagnostics.Process]::Start($psi)
    }
    catch {
        $script:IsRunning = $false
        Set-ScanControlsEnabled $true
        $script:StatusLabel.Text = "SCAN ERROR"
        $script:StatusLabel.ForeColor = Get-StatusColor "FAIL"
        Write-TerminalLog "failed to start scan: $($_.Exception.Message)" (Get-StatusColor "FAIL")
        return
    }

    Write-TerminalLog "process started pid=$($process.Id)"

    $script:ScanTimer = New-Object System.Windows.Forms.Timer
    $script:ScanTimer.Interval = 350
    $script:ScanTimer.Tag = [pscustomobject]@{
        Process = $process
        CommandLine = "powershell.exe $($psi.Arguments)"
        Tick = 0
        Started = Get-Date
        TimedOut = $false
        TimeoutSeconds = 120
    }
    $script:ScanTimer.Add_Tick({
        param($sender, $eventArgs)

        $state = $sender.Tag
        $state.Tick = [int]$state.Tick + 1
        if (($state.Tick % 6) -eq 0) {
            $script:StatusLabel.Text = "SCAN RUNNING" + ("." * (($state.Tick / 6) % 4))
        }

        if (-not $state.Process.HasExited) {
            $elapsed = ((Get-Date) - $state.Started).TotalSeconds
            if ($elapsed -gt $state.TimeoutSeconds -and -not $state.TimedOut) {
                $state.TimedOut = $true
                Write-TerminalLog "scan timeout after $([int]$elapsed)s; stopping collector pid=$($state.Process.Id)" (Get-StatusColor "WARN")
                try {
                    $state.Process.Kill()
                }
                catch {
                    Write-TerminalLog "could not stop collector: $($_.Exception.Message)" (Get-StatusColor "WARN")
                }
            }
            return
        }

        $sender.Stop()
        $sender.Dispose()
        $script:ScanTimer = $null

        $stdout = $state.Process.StandardOutput.ReadToEnd()
        $stderr = $state.Process.StandardError.ReadToEnd()
        $state.Process.WaitForExit()
        $exitCode = $state.Process.ExitCode
        $state.Process.Dispose()

        $script:IsRunning = $false
        Set-ScanControlsEnabled $true

        Write-TerminalLog "command: $($state.CommandLine)" ([Drawing.Color]::FromArgb(112, 210, 160))
        if ($stdout.Trim()) {
            foreach ($line in ($stdout -split "`r?`n")) {
                if ($line.Trim()) { Write-TerminalLog $line ([Drawing.Color]::FromArgb(170, 244, 198)) }
            }
        }
        if ($stderr.Trim()) {
            foreach ($line in ($stderr -split "`r?`n")) {
                if ($line.Trim()) { Write-TerminalLog $line (Get-StatusColor "WARN") }
            }
        }

        if ($state.TimedOut) {
            $script:StatusLabel.Text = "SCAN TIMEOUT"
            $script:StatusLabel.ForeColor = Get-StatusColor "WARN"
        }
        elseif ($exitCode -ne 0) {
            $script:StatusLabel.Text = "SCAN EXIT $exitCode"
            $script:StatusLabel.ForeColor = Get-StatusColor "WARN"
        }
        else {
            $script:StatusLabel.Text = "SCAN COMPLETE"
            $script:StatusLabel.ForeColor = Get-StatusColor "OK"
        }

        $jsonPath = Get-LatestReportJson
        if ($jsonPath -and (Test-Path $jsonPath)) {
            try {
                $report = Get-Content -Path $jsonPath -Raw | ConvertFrom-Json
                Update-ReportView $report
                Write-TerminalLog "report loaded: $jsonPath" (Get-StatusColor "OK")
            }
            catch {
                Write-TerminalLog "could not load JSON report: $($_.Exception.Message)" (Get-StatusColor "WARN")
            }
        }
        else {
            Write-TerminalLog "no JSON report found in $script:OutputDir" (Get-StatusColor "WARN")
        }
    })

    $script:ScanTimer.Start()
}

function Restart-AsAdmin {
    $adminArgs = "-NoProfile -ExecutionPolicy Bypass -File $(Quote-Arg $PSCommandPath) -OutputDir $(Quote-Arg $script:OutputDir)"
    try {
        Start-Process -FilePath "powershell.exe" -ArgumentList $adminArgs -Verb RunAs
        $script:Form.Close()
    }
    catch {
        Write-TerminalLog "admin relaunch cancelled or failed: $($_.Exception.Message)" (Get-StatusColor "WARN")
    }
}

function Copy-Summary {
    $lines = @(
        "Gaming Status Bench",
        $script:HostLabel.Text,
        $script:TimerLabel.Text,
        $script:DisplayLabel.Text,
        $script:NetworkLabel.Text,
        $script:OkLabel.Text,
        $script:WarnLabel.Text,
        $script:FailLabel.Text,
        $script:InfoLabel.Text,
        $script:UnknownLabel.Text,
        "JSON: $script:LastJsonPath",
        "HTML: $script:LastHtmlPath"
    )
    [System.Windows.Forms.Clipboard]::SetText(($lines -join "`r`n"))
    Write-TerminalLog "summary copied to clipboard"
}

function Ensure-GuiNativeTimer {
    try {
        if (-not ("GamingStatusGuiNativeTimer" -as [type])) {
            Add-Type -TypeDefinition @"
	using System;
	using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Sequential)]
public struct GamingStatusGuiProcessPowerThrottlingState
{
    public uint Version;
    public uint ControlMask;
    public uint StateMask;
}

public static class GamingStatusGuiNativeTimer
{
    [DllImport("ntdll.dll")]
    public static extern int NtSetTimerResolution(uint DesiredResolution, bool SetResolution, out uint CurrentResolution);

    [DllImport("kernel32.dll")]
    public static extern IntPtr GetCurrentProcess();

    [DllImport("kernel32.dll", SetLastError=true)]
    public static extern bool SetProcessInformation(IntPtr hProcess, int ProcessInformationClass, ref GamingStatusGuiProcessPowerThrottlingState ProcessInformation, int ProcessInformationSize);

    public const int ProcessPowerThrottling = 4;
    public const uint PROCESS_POWER_THROTTLING_CURRENT_VERSION = 1;
    public const uint PROCESS_POWER_THROTTLING_IGNORE_TIMER_RESOLUTION = 0x00000004;
}
"@ -ErrorAction Stop
        }
        return $true
    }
    catch {
        Write-TerminalLog "timer native load failed: $($_.Exception.Message)" (Get-StatusColor "WARN")
        return $false
    }
}

function Apply-ProcessTimerPolicy {
    if (-not (Ensure-GuiNativeTimer)) { return $false }

    try {
        $state = New-Object GamingStatusGuiProcessPowerThrottlingState
        $state.Version = [GamingStatusGuiNativeTimer]::PROCESS_POWER_THROTTLING_CURRENT_VERSION
        $state.ControlMask = [GamingStatusGuiNativeTimer]::PROCESS_POWER_THROTTLING_IGNORE_TIMER_RESOLUTION
        $state.StateMask = 0

        $size = [Runtime.InteropServices.Marshal]::SizeOf([type][GamingStatusGuiProcessPowerThrottlingState])
        $ok = [GamingStatusGuiNativeTimer]::SetProcessInformation(
            [GamingStatusGuiNativeTimer]::GetCurrentProcess(),
            [GamingStatusGuiNativeTimer]::ProcessPowerThrottling,
            [ref]$state,
            $size
        )

        $script:ProcessTimerPolicyApplied = [bool]$ok
        if ($ok) {
            $script:ProcessTimerPolicyError = $null
            Write-TerminalLog "process timer policy fixed: IGNORE_TIMER_RESOLUTION disabled" (Get-StatusColor "OK")
        }
        else {
            $script:ProcessTimerPolicyError = [Runtime.InteropServices.Marshal]::GetLastWin32Error()
            Write-TerminalLog "process timer policy failed: Win32 $script:ProcessTimerPolicyError" (Get-StatusColor "WARN")
        }

        Update-SolverView -Report $script:LastReport
        return [bool]$ok
    }
    catch {
        $script:ProcessTimerPolicyApplied = $false
        $script:ProcessTimerPolicyError = $_.Exception.Message
        Write-TerminalLog "process timer policy failed: $script:ProcessTimerPolicyError" (Get-StatusColor "WARN")
        Update-SolverView -Report $script:LastReport
        return $false
    }
}

function Set-TimerHold {
    param([bool]$Enabled)

    if (-not (Ensure-GuiNativeTimer)) { return }

    try {
        if ($Enabled) {
            Apply-ProcessTimerPolicy | Out-Null
        }

        [uint32]$current = 0
        $status = [GamingStatusGuiNativeTimer]::NtSetTimerResolution(5000, $Enabled, [ref]$current)
        if ($status -eq 0) {
            $script:TimerHoldActive = $Enabled
            $script:TimerHoldCurrentMs = [Math]::Round($current / 10000.0, 4)
            if ($Enabled) {
                Write-TerminalLog "timer hold active at $script:TimerHoldCurrentMs ms" (Get-StatusColor "OK")
            }
            else {
                Write-TerminalLog "timer hold released; current reported $script:TimerHoldCurrentMs ms" (Get-StatusColor "INFO")
            }
            Update-SolverView -Report $script:LastReport
        }
        else {
            Write-TerminalLog "NtSetTimerResolution failed with status $status" (Get-StatusColor "WARN")
        }
    }
    catch {
        Write-TerminalLog "timer hold failed: $($_.Exception.Message)" (Get-StatusColor "WARN")
    }
}

function Invoke-SolverProcess {
    param(
        [string]$FilePath,
        [string[]]$Arguments
    )

    try {
        $psi = New-Object Diagnostics.ProcessStartInfo
        $psi.FileName = $FilePath
        $psi.Arguments = (($Arguments | ForEach-Object { Quote-Arg ([string]$_) }) -join " ")
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError = $true
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow = $true
        $process = [Diagnostics.Process]::Start($psi)
        $stdout = $process.StandardOutput.ReadToEnd()
        $stderr = $process.StandardError.ReadToEnd()
        $process.WaitForExit()
        Write-TerminalLog "$FilePath $($psi.Arguments) -> exit $($process.ExitCode)" ([Drawing.Color]::FromArgb(112, 210, 160))
        foreach ($line in (($stdout + "`n" + $stderr) -split "`r?`n")) {
            if ($line.Trim()) { Write-TerminalLog $line ([Drawing.Color]::FromArgb(170, 244, 198)) }
        }
        return $process.ExitCode
    }
    catch {
        Write-TerminalLog "solver command failed: $($_.Exception.Message)" (Get-StatusColor "WARN")
        return 1
    }
}

function Copy-TimerSolverCommands {
    $text = @(
        "REM GamingStatusBench timer baseline commands",
        "REM Run as Administrator. Reboot after BCDEdit changes.",
        "REM Optional Windows 11 legacy global timer mode for old apps/tests:",
        "reg add `"HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel`" /v GlobalTimerResolutionRequests /t REG_DWORD /d 1 /f",
        "REM Revert optional global mode:",
        "reg delete `"HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel`" /v GlobalTimerResolutionRequests /f",
        "bcdedit /set disabledynamictick yes",
        "bcdedit /deletevalue useplatformclock",
        "bcdedit /deletevalue useplatformtick",
        "REM Power plan unlocker / show all:",
        "powercfg /qh SCHEME_CURRENT",
        "REM Unhide all discovered Advanced Power Settings UI entries. Does not change active values:",
        "powershell -NoProfile -ExecutionPolicy Bypass -Command `"Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings' -Recurse | Where-Object { `$_.PSChildName -match '^[0-9a-fA-F-]{36}$' -and `$_.PSParentPath -match 'PowerSettings\\[0-9a-fA-F-]{36}$' } | ForEach-Object { New-ItemProperty -Path `$_.PSPath -Name Attributes -Value 2 -PropertyType DWord -Force | Out-Null }`"",
        "powercfg /GETACTIVESCHEME",
        "powercfg /query SCHEME_CURRENT SUB_PROCESSOR PROCTHROTTLEMIN",
        "powercfg /query SCHEME_CURRENT SUB_PROCESSOR PROCTHROTTLEMAX"
    ) -join "`r`n"
    [System.Windows.Forms.Clipboard]::SetText($text)
    Write-TerminalLog "timer solver commands copied"
}

function Apply-GlobalTimerResolutionRequests {
    if (-not (Test-IsAdmin)) {
        [System.Windows.Forms.MessageBox]::Show("Admin rights are required. Use the ADMIN button first.", "Solver", "OK", "Warning") | Out-Null
        return
    }

    $message = "Enable Windows 11 legacy global timer mode?`r`n`r`nThis writes:`r`nHKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel`r`nGlobalTimerResolutionRequests = 1`r`n`r`nUse this when external tools or older games still show Sleep(1) around 15.6 ms while timer resolution reports 0.5 ms.`r`n`r`nReboot is required. This can increase power use while a high timer request is active."
    $answer = [System.Windows.Forms.MessageBox]::Show($message, "Confirm global timer mode", "YesNo", "Warning")
    if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) {
        Write-TerminalLog "global timer mode cancelled" (Get-StatusColor "INFO")
        return
    }

    Invoke-SolverProcess "reg.exe" @(
        "add",
        "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel",
        "/v", "GlobalTimerResolutionRequests",
        "/t", "REG_DWORD",
        "/d", "1",
        "/f"
    ) | Out-Null

    [System.Windows.Forms.MessageBox]::Show("Global timer mode was written. Reboot before retesting the external Sleep(1) tool.", "Solver", "OK", "Information") | Out-Null
}

function Apply-BcdeditBaseline {
    if (-not (Test-IsAdmin)) {
        [System.Windows.Forms.MessageBox]::Show("Admin rights are required. Use the ADMIN button first.", "Solver", "OK", "Warning") | Out-Null
        return
    }

    $message = "Apply timer boot baseline?`r`n`r`nThis runs:`r`nbcdedit /set disabledynamictick yes`r`nbcdedit /deletevalue useplatformclock`r`nbcdedit /deletevalue useplatformtick`r`n`r`nA reboot is required. Existing missing values may print harmless errors."
    $answer = [System.Windows.Forms.MessageBox]::Show($message, "Confirm BCDEdit baseline", "YesNo", "Warning")
    if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) {
        Write-TerminalLog "BCDEdit baseline cancelled" (Get-StatusColor "INFO")
        return
    }

    Invoke-SolverProcess "bcdedit.exe" @("/set", "disabledynamictick", "yes") | Out-Null
    Invoke-SolverProcess "bcdedit.exe" @("/deletevalue", "useplatformclock") | Out-Null
    Invoke-SolverProcess "bcdedit.exe" @("/deletevalue", "useplatformtick") | Out-Null
    [System.Windows.Forms.MessageBox]::Show("BCDEdit baseline attempted. Reboot before trusting timer results.", "Solver", "OK", "Information") | Out-Null
}

function Get-CpuSolverValue {
    param(
        [object]$Report,
        [string]$Name
    )

    return Get-JsonValue $Report @("Sections", "CpuScheduler", $Name)
}

function Get-CpuSolverStateText {
    param([object]$Report)

    if ($null -eq $Report) {
        return "No report loaded. Run a scan first."
    }

    $cpuName = Get-CpuSolverValue $Report "CpuName"
    $cpuProfile = Get-CpuSolverValue $Report "CpuModelProfile"
    $visible = Get-CpuSolverValue $Report "VisibleLogicalProcessors"
    $expected = Get-CpuSolverValue $Report "ExpectedLogicalProcessors"
    $visibleThreadsPerCore = Get-CpuSolverValue $Report "VisibleThreadsPerCore"
    $expectedThreadsPerCore = Get-CpuSolverValue $Report "ExpectedThreadsPerCore"
    $smtState = Get-CpuSolverValue $Report "SmtState"
    $smtConfidence = Get-CpuSolverValue $Report "SmtConfidence"
    $smtRecommendation = Get-CpuSolverValue $Report "SmtRecommendation"
    $cores = Get-CpuSolverValue $Report "PhysicalCores"
    $expectedCores = Get-CpuSolverValue $Report "ExpectedPhysicalCores"
    $ccdCount = Get-CpuSolverValue $Report "CcdCount"
    $coresPerCcd = Get-CpuSolverValue $Report "CoresPerCcd"
    $bcdActive = Get-CpuSolverValue $Report "BcdNumProcActive"
    $bcdNumProc = Get-CpuSolverValue $Report "BcdNumProc"
    $setAllowed = Get-CpuSolverValue $Report "Set16Allowed"
    $blocked = Get-CpuSolverValue $Report "Set16BlockedReason"
    $restoreAllowed = Get-CpuSolverValue $Report "RestoreAllowed"
    $recommendation = Get-CpuSolverValue $Report "SolverRecommendation"

    return @(
        "CPU: $cpuName",
        "CPU profile: $cpuProfile",
        "Physical cores: $cores",
        "Expected physical cores: $expectedCores",
        "CCD layout: $ccdCount CCD(s), $coresPerCcd core(s) per CCD",
        "Visible logical processors: $visible",
        "Expected logical processors: $expected",
        "Visible threads/core: $visibleThreadsPerCore",
        "Expected threads/core: $expectedThreadsPerCore",
        "SMT/HT state: $smtState ($smtConfidence)",
        "SMT/HT recommendation: $smtRecommendation",
        "BCD numproc active: $bcdActive",
        "BCD numproc: $bcdNumProc",
        "CPU SET 16 allowed: $setAllowed",
        "Set block/allow reason: $blocked",
        "CPU RESTORE allowed: $restoreAllowed",
        "Recommendation: $recommendation"
    ) -join "`r`n"
}

function Copy-CpuFixCommands {
    if ($null -eq $script:LastReport) {
        [System.Windows.Forms.Clipboard]::SetText("REM GamingStatusBench CPU fix: run a scan first.")
        Write-TerminalLog "CPU fix copy skipped: no report loaded" (Get-StatusColor "WARN")
        return
    }

    $setAllowed = (Get-CpuSolverValue $script:LastReport "Set16Allowed") -eq $true
    $restoreAllowed = (Get-CpuSolverValue $script:LastReport "RestoreAllowed") -eq $true
    $blocked = Get-CpuSolverValue $script:LastReport "Set16BlockedReason"

    $lines = @(
        "REM GamingStatusBench CPU Scheduler / Logical Processor Fix",
        "REM Run as Administrator. Reboot after SET or RESTORE.",
        "REM Apply only when the latest report says the action is allowed.",
        "REM CPU SET 16 cannot enable SMT/Hyper-Threading. BIOS/UEFI controls SMT.",
        "",
        "REM Current report state:",
        (Get-CpuSolverStateText $script:LastReport),
        "",
        "REM Check commands:",
        "Get-CimInstance Win32_ComputerSystem | Select-Object NumberOfProcessors,NumberOfLogicalProcessors",
        "Get-CimInstance Win32_Processor | Select-Object Name,NumberOfCores,NumberOfLogicalProcessors",
        "bcdedit /enum {current}",
        ""
    )

    if ($setAllowed) {
        $lines += "REM CPU SET 16 is allowed by latest report:"
        $lines += "bcdedit /set {current} numproc 16"
    }
    else {
        $lines += "REM CPU SET 16 blocked by latest report: $blocked"
        $lines += "REM bcdedit /set {current} numproc 16"
    }

    $lines += ""
    if ($restoreAllowed) {
        $lines += "REM CPU RESTORE is allowed by latest report:"
        $lines += "bcdedit /deletevalue {current} numproc"
    }
    else {
        $lines += "REM CPU RESTORE not needed: no active numproc override in latest report."
        $lines += "REM bcdedit /deletevalue {current} numproc"
    }

    [System.Windows.Forms.Clipboard]::SetText(($lines -join "`r`n"))
    Write-TerminalLog "CPU fix commands copied"
}

function Apply-CpuSet16 {
    if ($script:IsRunning) {
        [System.Windows.Forms.MessageBox]::Show("Wait for the current scan to finish first.", "CPU Scheduler", "OK", "Warning") | Out-Null
        return
    }
    if (-not (Test-IsAdmin)) {
        [System.Windows.Forms.MessageBox]::Show("Admin rights are required. Use the ADMIN button first.", "CPU Scheduler", "OK", "Warning") | Out-Null
        return
    }
    if ($null -eq $script:LastReport) {
        [System.Windows.Forms.MessageBox]::Show("Run a scan first. CPU SET 16 only works from a confirmed latest report.", "CPU Scheduler", "OK", "Warning") | Out-Null
        return
    }

    $setAllowed = (Get-CpuSolverValue $script:LastReport "Set16Allowed") -eq $true
    if (-not $setAllowed) {
        $blocked = Get-CpuSolverValue $script:LastReport "Set16BlockedReason"
        [System.Windows.Forms.MessageBox]::Show("CPU SET 16 is blocked by the latest report.`r`n`r`n$blocked", "CPU Scheduler", "OK", "Warning") | Out-Null
        Write-TerminalLog "CPU SET 16 blocked: $blocked" (Get-StatusColor "WARN")
        return
    }

    $message = "Apply CPU SET 16?`r`n`r`nThis runs:`r`nbcdedit /set {current} numproc 16`r`n`r`nLatest report:`r`n$(Get-CpuSolverStateText $script:LastReport)`r`n`r`nThis is a boot configuration change. Reboot is required. Use only for the confirmed 8C/16T case shown above."
    $answer = [System.Windows.Forms.MessageBox]::Show($message, "Confirm CPU SET 16", "YesNo", "Warning")
    if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) {
        Write-TerminalLog "CPU SET 16 cancelled" (Get-StatusColor "INFO")
        return
    }

    Invoke-SolverProcess "bcdedit.exe" @("/set", "{current}", "numproc", "16") | Out-Null
    [System.Windows.Forms.MessageBox]::Show("CPU SET 16 was attempted. Reboot, then run a new scan to verify logical processors.", "CPU Scheduler", "OK", "Information") | Out-Null
}

function Apply-CpuRestore {
    if ($script:IsRunning) {
        [System.Windows.Forms.MessageBox]::Show("Wait for the current scan to finish first.", "CPU Scheduler", "OK", "Warning") | Out-Null
        return
    }
    if (-not (Test-IsAdmin)) {
        [System.Windows.Forms.MessageBox]::Show("Admin rights are required. Use the ADMIN button first.", "CPU Scheduler", "OK", "Warning") | Out-Null
        return
    }
    if ($null -eq $script:LastReport) {
        [System.Windows.Forms.MessageBox]::Show("Run a scan first. CPU RESTORE only works from the latest report state.", "CPU Scheduler", "OK", "Warning") | Out-Null
        return
    }

    $restoreAllowed = (Get-CpuSolverValue $script:LastReport "RestoreAllowed") -eq $true
    if (-not $restoreAllowed) {
        [System.Windows.Forms.MessageBox]::Show("CPU RESTORE is blocked because the latest report does not show an active numproc override.", "CPU Scheduler", "OK", "Information") | Out-Null
        Write-TerminalLog "CPU RESTORE blocked: no active numproc override" (Get-StatusColor "INFO")
        return
    }

    $message = "Apply CPU RESTORE?`r`n`r`nThis runs:`r`nbcdedit /deletevalue {current} numproc`r`n`r`nLatest report:`r`n$(Get-CpuSolverStateText $script:LastReport)`r`n`r`nThis removes the boot processor-count override. Reboot is required."
    $answer = [System.Windows.Forms.MessageBox]::Show($message, "Confirm CPU RESTORE", "YesNo", "Warning")
    if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) {
        Write-TerminalLog "CPU RESTORE cancelled" (Get-StatusColor "INFO")
        return
    }

    Invoke-SolverProcess "bcdedit.exe" @("/deletevalue", "{current}", "numproc") | Out-Null
    [System.Windows.Forms.MessageBox]::Show("CPU RESTORE was attempted. Reboot, then run a new scan to verify logical processors.", "CPU Scheduler", "OK", "Information") | Out-Null
}

function Apply-GameDvrBenchmarkOff {
    $message = "Disable Windows capture/replay buffer for benchmark runs?`r`n`r`nThis writes HKCU values only:`r`nGameDVR_Enabled = 0`r`nAppCaptureEnabled = 0`r`nHistoricalCaptureEnabled = 0`r`n`r`nRestart the game before retesting."
    $answer = [System.Windows.Forms.MessageBox]::Show($message, "Confirm GameDVR off", "YesNo", "Warning")
    if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) {
        Write-TerminalLog "GameDVR fix cancelled" (Get-StatusColor "INFO")
        return
    }

    Invoke-SolverProcess "reg.exe" @("add", "HKCU\System\GameConfigStore", "/v", "GameDVR_Enabled", "/t", "REG_DWORD", "/d", "0", "/f") | Out-Null
    Invoke-SolverProcess "reg.exe" @("add", "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR", "/v", "AppCaptureEnabled", "/t", "REG_DWORD", "/d", "0", "/f") | Out-Null
    Invoke-SolverProcess "reg.exe" @("add", "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR", "/v", "HistoricalCaptureEnabled", "/t", "REG_DWORD", "/d", "0", "/f") | Out-Null
    [System.Windows.Forms.MessageBox]::Show("GameDVR capture/background recording values were written. Restart the game, then rescan.", "Solver", "OK", "Information") | Out-Null
}

function Apply-GameModeOn {
    $message = "Enable Windows Game Mode?`r`n`r`nThis writes HKCU GameBar values:`r`nAutoGameModeEnabled = 1`r`nAllowAutoGameMode = 1`r`n`r`nRestart the game before retesting."
    $answer = [System.Windows.Forms.MessageBox]::Show($message, "Confirm Game Mode", "YesNo", "Question")
    if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) {
        Write-TerminalLog "Game Mode change cancelled" (Get-StatusColor "INFO")
        return
    }

    Invoke-SolverProcess "reg.exe" @("add", "HKCU\Software\Microsoft\GameBar", "/v", "AutoGameModeEnabled", "/t", "REG_DWORD", "/d", "1", "/f") | Out-Null
    Invoke-SolverProcess "reg.exe" @("add", "HKCU\Software\Microsoft\GameBar", "/v", "AllowAutoGameMode", "/t", "REG_DWORD", "/d", "1", "/f") | Out-Null
    [System.Windows.Forms.MessageBox]::Show("Game Mode values were written. Restart the game, then rescan.", "Solver", "OK", "Information") | Out-Null
}

function Get-PowerSettingRegistryRows {
    $base = "HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings"
    $rows = @()

    foreach ($subgroup in @(Get-ChildItem -Path $base -ErrorAction Stop)) {
        foreach ($setting in @(Get-ChildItem -Path $subgroup.PSPath -ErrorAction SilentlyContinue)) {
            $props = Get-ItemProperty -Path $setting.PSPath -ErrorAction SilentlyContinue
            if ($null -eq $props -or $null -eq $props.PSObject.Properties["Attributes"]) { continue }
            $attributes = [int]$props.PSObject.Properties["Attributes"].Value
            $friendlyProp = $props.PSObject.Properties["FriendlyName"]
            $rows += [pscustomobject]@{
                Path = $setting.PSPath
                SubgroupGuid = $subgroup.PSChildName
                SettingGuid = $setting.PSChildName
                FriendlyName = if ($friendlyProp) { [string]$friendlyProp.Value } else { "" }
                Attributes = $attributes
                Hidden = (($attributes -band 1) -ne 0)
            }
        }
    }

    return $rows
}

function Get-UsbDeviceIdentityRows {
    $rows = @()

    foreach ($className in @("Win32_USBController", "Win32_USBHub")) {
        try {
            foreach ($device in @(Get-CimInstance -ClassName $className -ErrorAction Stop)) {
                if (-not $device.PNPDeviceID) { continue }
                $rows += [pscustomobject]@{
                    PNPDeviceID = [string]$device.PNPDeviceID
                    Name = [string]$device.Name
                    SourceClass = $className
                }
            }
        }
        catch {
        }
    }

    try {
        foreach ($device in @(Get-CimInstance -ClassName Win32_PnPEntity -ErrorAction Stop | Where-Object { $_.PNPDeviceID -like "USB*" -or $_.PNPClass -eq "USB" })) {
            if (-not $device.PNPDeviceID) { continue }
            $rows += [pscustomobject]@{
                PNPDeviceID = [string]$device.PNPDeviceID
                Name = [string]$device.Name
                SourceClass = "Win32_PnPEntity"
            }
        }
    }
    catch {
    }

    $deduped = @{}
    foreach ($row in $rows) {
        if (-not $deduped.ContainsKey($row.PNPDeviceID)) {
            $deduped[$row.PNPDeviceID] = $row
        }
    }

    return @($deduped.Values | Sort-Object PNPDeviceID)
}

function Convert-UsbPowerRegistryValueToText {
    param([object]$Value)

    if ($null -eq $Value) { return "" }
    if ($Value -is [array]) { return (($Value | ForEach-Object { [string]$_ }) -join ",") }
    return [string]$Value
}

function Test-UsbPowerRegistryValueEnabled {
    param([object]$Value)

    if ($null -eq $Value) { return $false }
    if ($Value -is [array]) {
        foreach ($item in $Value) {
            if ([int]$item -ne 0) { return $true }
        }
        return $false
    }

    try { return ([int]$Value -ne 0) } catch { return $false }
}

function Get-UsbPowerRegistryRows {
    $roots = @(
        "HKLM:\SYSTEM\CurrentControlSet\Enum\USB",
        "HKLM:\SYSTEM\CurrentControlSet\Enum\USB4",
        "HKLM:\SYSTEM\CurrentControlSet\Enum\USBSTOR",
        "HKLM:\SYSTEM\CurrentControlSet\Enum\HID"
    )
    $valueNames = @(
        "EnhancedPowerManagementEnabled",
        "AllowIdleIrpInD3",
        "DeviceSelectiveSuspended",
        "SelectiveSuspendEnabled",
        "SelectiveSuspendOn",
        "EnableSelectiveSuspend"
    )
    $rows = @()

    foreach ($root in $roots) {
        if (-not (Test-Path -LiteralPath $root)) { continue }
        foreach ($key in @(Get-ChildItem -LiteralPath $root -Recurse -ErrorAction SilentlyContinue | Where-Object { $_.PSChildName -eq "Device Parameters" })) {
            $props = Get-ItemProperty -LiteralPath $key.PSPath -ErrorAction SilentlyContinue
            if ($null -eq $props) { continue }

            foreach ($name in $valueNames) {
                $prop = $props.PSObject.Properties[$name]
                if ($null -eq $prop) { continue }
                $value = $prop.Value
                $rows += [pscustomobject]@{
                    Backend = "Registry"
                    RegistryPath = $key.PSPath
                    DisplayPath = $key.Name
                    DeviceName = ($key.Name -replace "^HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Enum\\", "")
                    Name = $name
                    Value = Convert-UsbPowerRegistryValueToText -Value $value
                    Enable = (Test-UsbPowerRegistryValueEnabled -Value $value)
                    TargetValue = 0
                }
            }
        }
    }

    return @($rows | Sort-Object Enable, Name, DisplayPath)
}

function Get-UsbPowerSavingRows {
    $usbDevices = @(Get-UsbDeviceIdentityRows)
    $rows = @()

    try {
        $powerEntries = @(Get-WmiObject MSPower_DeviceEnable -Namespace root\wmi -ErrorAction Stop)
        foreach ($powerEntry in $powerEntries) {
            $instanceName = [string]$powerEntry.InstanceName
            if (-not $instanceName) { continue }
            $instanceUpper = $instanceName.ToUpperInvariant()
            $matchedDevice = $null

            foreach ($usbDevice in $usbDevices) {
                $pnp = [string]$usbDevice.PNPDeviceID
                if (-not $pnp) { continue }
                if ($instanceUpper.Contains($pnp.ToUpperInvariant())) {
                    $matchedDevice = $usbDevice
                    break
                }
            }

            if ($null -eq $matchedDevice) { continue }

            $rows += [pscustomobject]@{
                Backend = "WMI"
                PowerEntry = $powerEntry
                DeviceName = $matchedDevice.Name
                PNPDeviceID = $matchedDevice.PNPDeviceID
                SourceClass = $matchedDevice.SourceClass
                InstanceName = $instanceName
                Enable = [bool]$powerEntry.Enable
            }
        }
    }
    catch {
        Write-TerminalLog "USB MSPower_DeviceEnable read failed, using registry fallback: $($_.Exception.Message)" (Get-StatusColor "WARN")
    }

    try {
        $rows += @(Get-UsbPowerRegistryRows)
    }
    catch {
        Write-TerminalLog "USB registry power read failed: $($_.Exception.Message)" (Get-StatusColor "WARN")
    }

    return @($rows | Sort-Object Enable, DeviceName, InstanceName)
}

function Copy-PowerShowAll {
    try {
        $psi = New-Object Diagnostics.ProcessStartInfo
        $psi.FileName = "powercfg.exe"
        $psi.Arguments = "/qh SCHEME_CURRENT"
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError = $true
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow = $true
        $process = [Diagnostics.Process]::Start($psi)
        $stdout = $process.StandardOutput.ReadToEnd()
        $stderr = $process.StandardError.ReadToEnd()
        $process.WaitForExit()
        $text = ($stdout + "`r`n" + $stderr).Trim()
        if (-not $text) { $text = "powercfg /qh SCHEME_CURRENT returned no output." }
        [System.Windows.Forms.Clipboard]::SetText($text)
        Write-TerminalLog "powercfg /qh SCHEME_CURRENT copied to clipboard ($($text.Length) chars)"
        [System.Windows.Forms.MessageBox]::Show("Full current power plan output was copied to clipboard.", "Power unlocker", "OK", "Information") | Out-Null
    }
    catch {
        Write-TerminalLog "power show all failed: $($_.Exception.Message)" (Get-StatusColor "WARN")
    }
}

function Apply-PowerUnhideAll {
    if (-not (Test-IsAdmin)) {
        [System.Windows.Forms.MessageBox]::Show("Admin rights are required. Use the ADMIN button first.", "Power unlocker", "OK", "Warning") | Out-Null
        return
    }

    $rows = @()
    try {
        $rows = @(Get-PowerSettingRegistryRows)
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Could not read PowerSettings registry:`r`n$($_.Exception.Message)", "Power unlocker", "OK", "Error") | Out-Null
        return
    }

    $hiddenCount = @($rows | Where-Object { $_.Hidden }).Count
    $message = "Unhide all discovered Windows Advanced Power Settings?`r`n`r`nThis sets Attributes=2 under:`r`nHKLM\SYSTEM\CurrentControlSet\Control\Power\PowerSettings`r`n`r`nDiscovered settings: $($rows.Count)`r`nCurrently hidden: $hiddenCount`r`n`r`nThis unlocks UI visibility only. It does not change active AC/DC power values. Export/document your plan before changing actual values."
    $answer = [System.Windows.Forms.MessageBox]::Show($message, "Confirm power unlocker", "YesNo", "Warning")
    if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) {
        Write-TerminalLog "power unhide all cancelled" (Get-StatusColor "INFO")
        return
    }

    $changed = 0
    $failed = 0
    foreach ($row in $rows) {
        try {
            New-ItemProperty -Path $row.Path -Name "Attributes" -Value 2 -PropertyType DWord -Force | Out-Null
            $changed++
        }
        catch {
            $failed++
            Write-TerminalLog "power setting unlock failed: $($row.SettingGuid) $($_.Exception.Message)" (Get-StatusColor "WARN")
        }
    }

    Write-TerminalLog "power unhide all complete: changed=$changed failed=$failed hidden_before=$hiddenCount"
    [System.Windows.Forms.MessageBox]::Show("Power settings unlock finished.`r`nChanged: $changed`r`nFailed: $failed`r`n`r`nRun a new scan or open Advanced Power Settings to verify.", "Power unlocker", "OK", "Information") | Out-Null
}

function Apply-UsbPowerSavingOff {
    if (-not (Test-IsAdmin)) {
        [System.Windows.Forms.MessageBox]::Show("Admin rights are required. Use the ADMIN button first.", "USB power saving", "OK", "Warning") | Out-Null
        return
    }

    $rows = @()
    try {
        $rows = @(Get-UsbPowerSavingRows)
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Could not read USB power policy entries:`r`n$($_.Exception.Message)", "USB power saving", "OK", "Error") | Out-Null
        return
    }

    if ($rows.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show("No USB power-saving entries were found via WMI or registry fallback.", "USB power saving", "OK", "Information") | Out-Null
        Write-TerminalLog "USB power saving: no WMI/registry entries" (Get-StatusColor "INFO")
        return
    }

    $enabledRows = @($rows | Where-Object { $_.Enable })
    if ($enabledRows.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show("USB power saving is already disabled for all matched entries.`r`nMatched entries: $($rows.Count)", "USB power saving", "OK", "Information") | Out-Null
        Write-TerminalLog "USB power saving already disabled for matched entries"
        return
    }

    $wmiCount = @($rows | Where-Object { $_.Backend -eq "WMI" }).Count
    $registryCount = @($rows | Where-Object { $_.Backend -eq "Registry" }).Count
    $preview = (($enabledRows | Select-Object -First 10 | ForEach-Object {
        if ($_.Backend -eq "Registry") { "- Registry: $($_.Name) = $($_.Value) :: $($_.DeviceName)" }
        else { "- WMI: $($_.DeviceName)" }
    }) -join "`r`n")
    $message = "Disable USB power saving for matched USB entries?`r`n`r`nThis uses WMI when available and registry fallback under:`r`nHKLM\SYSTEM\CurrentControlSet\Enum\USB/USB4/USBSTOR/HID\...\Device Parameters`r`n`r`nMatched checks: $($rows.Count)  (WMI: $wmiCount / Registry: $registryCount)`r`nCurrently enabled: $($enabledRows.Count)`r`n`r`n$preview`r`n`r`nUse this for a strict input-latency benchmark profile. It can increase idle power. Reconnect affected USB devices or reboot if a device does not refresh."
    $answer = [System.Windows.Forms.MessageBox]::Show($message, "Confirm USB power saving off", "YesNo", "Warning")
    if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) {
        Write-TerminalLog "USB power saving change cancelled" (Get-StatusColor "INFO")
        return
    }

    $changed = 0
    $failed = 0
    foreach ($row in $enabledRows) {
        try {
            if ($row.Backend -eq "Registry") {
                Set-ItemProperty -LiteralPath $row.RegistryPath -Name $row.Name -Value $row.TargetValue -ErrorAction Stop
            }
            else {
                $row.PowerEntry.Enable = $false
                $row.PowerEntry.psbase.Put() | Out-Null
            }
            $changed++
        }
        catch {
            $failed++
            $label = if ($row.Backend -eq "Registry") { "$($row.Name) at $($row.DisplayPath)" } else { $row.DeviceName }
            Write-TerminalLog "USB power saving write failed: $label $($_.Exception.Message)" (Get-StatusColor "WARN")
        }
    }

    Write-TerminalLog "USB power saving off complete: changed=$changed failed=$failed enabled_before=$($enabledRows.Count)"
    [System.Windows.Forms.MessageBox]::Show("USB power saving update finished.`r`nChanged: $changed`r`nFailed: $failed`r`n`r`nRun a new scan to verify. Reconnect affected USB devices or reboot if needed.", "USB power saving", "OK", "Information") | Out-Null
}

function Open-CapturesSettings {
    try {
        Start-Process "ms-settings:gaming-gamedvr"
        Write-TerminalLog "opened Windows Captures settings"
    }
    catch {
        Write-TerminalLog "could not open captures settings: $($_.Exception.Message)" (Get-StatusColor "WARN")
    }
}

function Copy-FixGuideCommands {
    if ($null -eq $script:LastReport) {
        Write-TerminalLog "no report loaded for fix commands" (Get-StatusColor "WARN")
        return
    }

    $rows = @(Get-ObjectsWithProperty -Value (Get-JsonValue $script:LastReport @("Analysis", "FixGuide", "Matrix")) -PropertyName "Commands" | Where-Object { [string]$_.Commands })
    if ($rows.Count -eq 0) {
        [System.Windows.Forms.Clipboard]::SetText("REM GamingStatusBench: no command-backed fixes in latest report.")
        Write-TerminalLog "no command-backed fixes in latest report"
        return
    }

    $lines = @(
        "REM GamingStatusBench fix commands from latest report",
        "REM Apply one fix at a time. Reboot when the report marks RequiresReboot=True.",
        "REM Review every command before running it."
    )
    foreach ($row in $rows) {
        $lines += ""
        $lines += "REM $($row.Decision) | $($row.Area) | $($row.Check)"
        $lines += "REM $($row.FixSummary)"
        foreach ($command in ([string]$row.Commands -split "\s+\|\s+")) {
            if ($command.Trim()) {
                $lines += $command.Trim()
            }
        }
    }

    [System.Windows.Forms.Clipboard]::SetText(($lines -join "`r`n"))
    Write-TerminalLog "fix guide commands copied"
}

function Update-FixesView {
    param([object]$Report)

    if ($null -eq $script:FixesBox) { return }

    $summary = Get-JsonValue $Report @("Analysis", "FixGuide", "Summary")
    $topFixes = @(Get-ObjectsWithProperty -Value (Get-JsonValue $Report @("Analysis", "FixGuide", "TopFixes")) -PropertyName "Check")
    $matrix = @(Get-ObjectsWithProperty -Value (Get-JsonValue $Report @("Analysis", "FixGuide", "Matrix")) -PropertyName "Check")

    if ($null -eq $summary) {
        $script:FixesBox.Text = "No fix guide found in this report. Run a new scan with the current collector."
        return
    }

    $lines = @(
        "Fix guide",
        "=========",
        "Required fixes: $($summary.RequiredFixes) | MUST $($summary.MustFix) | SHOULD $($summary.ShouldFix) | REVIEW/CHECK $($summary.ReviewOrCheck) | OPTIONAL $($summary.Optional)",
        "Command-backed fixes: $($summary.CommandBackedFixes)",
        "Rule: $($summary.Rule)",
        "",
        "Recommended fixes / review items",
        "--------------------------------"
    )

    foreach ($row in $topFixes) {
        $lines += "$($row.Decision) | $($row.Area) | $($row.Check)"
        $lines += "  value:  $($row.Value)"
        $lines += "  fix:    $($row.FixSummary)"
        if ($row.SolverAction) { $lines += "  solver: $($row.SolverAction)" }
        $lines += "  admin:  $($row.RequiresAdmin) | reboot: $($row.RequiresReboot) | risk: $($row.Risk)"
        if ($row.Steps) { $lines += "  steps:  $($row.Steps)" }
        if ($row.Commands) { $lines += "  cmds:   $($row.Commands)" }
        $lines += ""
    }

    $lines += "All solution notes"
    $lines += "------------------"
    foreach ($row in $matrix) {
        $lines += "$($row.Decision) | $($row.Area) | $($row.Check) -> $($row.FixSummary)"
        if ($row.SolverAction) { $lines += "  solver: $($row.SolverAction)" }
        if ($row.Commands) { $lines += "  cmds:   $($row.Commands)" }
        $lines += "  admin: $($row.RequiresAdmin) | reboot: $($row.RequiresReboot) | risk: $($row.Risk)"
        $lines += ""
    }

    $script:FixesBox.Text = ($lines -join "`r`n")
}

function Update-SolverView {
    param([object]$Report)

    if ($null -eq $script:SolverBox) { return }

    $timer = Get-JsonValue $Report @("Sections", "Timer", "NtQueryTimerResolution", "CurrentMs")
    $sleep = Get-JsonValue $Report @("Sections", "Timer", "SleepJitter", "P95Ms")
    $wait = Get-JsonValue $Report @("Sections", "Timer", "HighResolutionWaitableTimer", "P95Ms")
    $waitMethod = Get-JsonValue $Report @("Sections", "Timer", "HighResolutionWaitableTimer", "Method")
    $waitError = Get-JsonValue $Report @("Sections", "Timer", "HighResolutionWaitableTimer", "ErrorCode")
    $waitFallback = Get-JsonValue $Report @("Sections", "Timer", "HighResolutionWaitableTimer", "FallbackUsed")
    $waitTimerRequest = Get-JsonValue $Report @("Sections", "Timer", "HighResolutionWaitableTimer", "TimerRequestActive")
    $waitTimerRequestMs = Get-JsonValue $Report @("Sections", "Timer", "HighResolutionWaitableTimer", "TimerRequestCurrentMs")
    $reportPolicyApplied = Get-JsonValue $Report @("Sections", "Timer", "ProcessTimerPolicy", "Applied")
    $reportPolicyError = Get-JsonValue $Report @("Sections", "Timer", "ProcessTimerPolicy", "ErrorCode")
    $reportPolicyNote = Get-JsonValue $Report @("Sections", "Timer", "ProcessTimerPolicy", "Note")
    $globalTimerValue = Get-JsonValue $Report @("Sections", "Timer", "GlobalTimerResolutionRequests", "Value")
    $globalTimerEnabled = Get-JsonValue $Report @("Sections", "Timer", "GlobalTimerResolutionRequests", "Enabled")
    $analysisOverall = Get-JsonValue $Report @("Analysis", "Timer", "Summary", "Overall")
    $analysisCompetitiveTarget = Get-JsonValue $Report @("Analysis", "Timer", "Summary", "CompetitiveTimerTarget")
    $analysisCompetitiveSteps = Get-JsonValue $Report @("Analysis", "Timer", "Summary", "CompetitiveTimerSteps")
    $lowestSupportedResolution = Get-JsonValue $Report @("Analysis", "Timer", "Summary", "LowestSupportedResolutionMs")
    $currentResolution = Get-JsonValue $Report @("Analysis", "Timer", "Summary", "CurrentResolutionMs")
    $analysisGlobalMode = Get-JsonValue $Report @("Analysis", "Timer", "Summary", "GlobalTimerMode")
    $analysisExternalSleep = Get-JsonValue $Report @("Analysis", "Timer", "Summary", "ExternalSleepTester")
    $analysisRemainingJitter = Get-JsonValue $Report @("Analysis", "Timer", "Summary", "RemainingJitter")
    $actionVerdict = Get-JsonValue $Report @("Analysis", "ActionGuide", "Summary", "Verdict")
    $mustFix = Get-JsonValue $Report @("Analysis", "ActionGuide", "Summary", "MustFix")
    $shouldFix = Get-JsonValue $Report @("Analysis", "ActionGuide", "Summary", "ShouldFix")
    $reviewCount = Get-JsonValue $Report @("Analysis", "ActionGuide", "Summary", "Review")
    $optionalCount = Get-JsonValue $Report @("Analysis", "ActionGuide", "Summary", "Optional")
    $powerHidden = Get-JsonValue $Report @("Sections", "Power", "HiddenSettings", "HiddenCount")
    $powerTotal = Get-JsonValue $Report @("Sections", "Power", "HiddenSettings", "TotalCount")
    $usbPowerEnabled = Get-JsonValue $Report @("Sections", "Power", "UsbPowerSaving", "EnabledCount")
    $usbPowerMatched = Get-JsonValue $Report @("Sections", "Power", "UsbPowerSaving", "MatchedCount")
    $dynamicTick = Get-JsonValue $Report @("Sections", "Kernel", "Parsed", "disabledynamictick")
    $platformClock = Get-JsonValue $Report @("Sections", "Kernel", "Parsed", "useplatformclock")
    $platformTick = Get-JsonValue $Report @("Sections", "Kernel", "Parsed", "useplatformtick")
    $vbs = Get-JsonValue $Report @("Sections", "Security", "DeviceGuard", "VirtualizationBasedSecurityStatus")
    $cpuName = Get-JsonValue $Report @("Sections", "CpuScheduler", "CpuName")
    $cpuProfile = Get-JsonValue $Report @("Sections", "CpuScheduler", "CpuModelProfile")
    $cpuCores = Get-JsonValue $Report @("Sections", "CpuScheduler", "PhysicalCores")
    $cpuExpectedCores = Get-JsonValue $Report @("Sections", "CpuScheduler", "ExpectedPhysicalCores")
    $cpuCcdCount = Get-JsonValue $Report @("Sections", "CpuScheduler", "CcdCount")
    $cpuCoresPerCcd = Get-JsonValue $Report @("Sections", "CpuScheduler", "CoresPerCcd")
    $cpuVisibleLogical = Get-JsonValue $Report @("Sections", "CpuScheduler", "VisibleLogicalProcessors")
    $cpuExpectedLogical = Get-JsonValue $Report @("Sections", "CpuScheduler", "ExpectedLogicalProcessors")
    $cpuVisibleThreadsPerCore = Get-JsonValue $Report @("Sections", "CpuScheduler", "VisibleThreadsPerCore")
    $cpuExpectedThreadsPerCore = Get-JsonValue $Report @("Sections", "CpuScheduler", "ExpectedThreadsPerCore")
    $cpuSmtState = Get-JsonValue $Report @("Sections", "CpuScheduler", "SmtState")
    $cpuSmtConfidence = Get-JsonValue $Report @("Sections", "CpuScheduler", "SmtConfidence")
    $cpuSmtRecommendation = Get-JsonValue $Report @("Sections", "CpuScheduler", "SmtRecommendation")
    $cpuBcdNumProcActive = Get-JsonValue $Report @("Sections", "CpuScheduler", "BcdNumProcActive")
    $cpuBcdNumProc = Get-JsonValue $Report @("Sections", "CpuScheduler", "BcdNumProc")
    $cpuSet16Allowed = Get-JsonValue $Report @("Sections", "CpuScheduler", "Set16Allowed")
    $cpuSet16BlockedReason = Get-JsonValue $Report @("Sections", "CpuScheduler", "Set16BlockedReason")
    $cpuRestoreAllowed = Get-JsonValue $Report @("Sections", "CpuScheduler", "RestoreAllowed")
    $cpuRestoreRecommended = Get-JsonValue $Report @("Sections", "CpuScheduler", "RestoreRecommended")
    $cpuSolverRecommendation = Get-JsonValue $Report @("Sections", "CpuScheduler", "SolverRecommendation")

    Update-CpuSolverButtons -Report $Report

    $state = "NO REPORT"
    $stateColor = "INFO"
    if ($null -ne $timer -and $timer -le 1.0 -and $null -ne $wait -and $wait -ge 10.0) {
        $state = "MIXED TIMER STATE"
        $stateColor = "WARN"
    }
    elseif ($null -ne $timer -and $timer -le 1.0 -and $null -ne $sleep -and $sleep -le 2.5 -and $null -ne $wait -and $wait -le 2.5) {
        $state = "CLEAN HIGH-RES TIMER"
        $stateColor = "OK"
    }
    elseif ($null -ne $timer) {
        $state = "CHECK TIMER WAKE PATHS"
        $stateColor = "WARN"
    }

    $bootBaselineOk = (
        [string]$dynamicTick -match "Yes|Ja|true|1" -and
        -not $platformClock -and
        -not $platformTick
    )
    $apiRejected = ($waitFallback -eq $true -and [int]$waitError -eq 87)

    $script:SolverStatusLabel.Text = "solver: $state"
    $script:SolverStatusLabel.ForeColor = Get-StatusColor $stateColor

    $timerHold = if ($script:TimerHoldActive) { "active at $script:TimerHoldCurrentMs ms" } else { "off" }
    $guiPolicyLine = if ($script:ProcessTimerPolicyApplied) {
        "OK - GUI process has IGNORE_TIMER_RESOLUTION disabled"
    }
    elseif ($script:ProcessTimerPolicyError) {
        "CHECK - GUI apply failed: $script:ProcessTimerPolicyError"
    }
    else {
        "not applied in GUI yet"
    }
    $reportPolicyLine = if ($reportPolicyApplied -eq $true) {
        "OK - scan process disabled IGNORE_TIMER_RESOLUTION"
    }
    elseif ($null -ne $reportPolicyApplied) {
        "CHECK - scan process could not apply policy ($reportPolicyError)"
    }
    else {
        "not present in latest report"
    }
    $globalTimerLine = if ($globalTimerEnabled -eq $true) {
        "OK - GlobalTimerResolutionRequests=1, reboot must have happened after set"
    }
    elseif ($null -ne $globalTimerValue) {
        "CHECK - value is $globalTimerValue, expected 1 for legacy global mode"
    }
    else {
        "OFF - external old apps/tests may still Sleep(1) at ~15.6 ms"
    }
    $bootLine = if ($bootBaselineOk) {
        "OK - disabledynamictick is set and platform clock/tick are not forced"
    }
    else {
        "CHECK - use COPY CMDS or APPLY BCDEDIT only if you want the baseline"
    }
    $apiLine = if ($apiRejected) {
        if ($null -ne $wait -and $wait -le 2.5) {
            "REJECTED - high-res flag returns Win32 87, but fallback now wakes fast"
        }
        else {
            "REJECTED - high-res flag returns Win32 87; fix process timer policy and retest"
        }
    }
    else {
        "not rejected in latest report"
    }
    $actionLine = if ($globalTimerEnabled -ne $true -and $null -ne $timer -and $timer -le 1.0 -and $null -ne $sleep -and $sleep -le 2.5 -and $null -ne $wait -and $wait -le 2.5) {
        "For external testers still showing 15.6 ms, apply GLOBAL MODE, reboot, then retest that external tool."
    }
    elseif ($apiRejected -and $bootBaselineOk -and $null -ne $wait -and $wait -ge 10.0) {
        "Use FIX PROC POLICY first. This is a per-process Windows 11 timer behavior, not a BCDEdit-first problem."
    }
    elseif ($null -ne $wait -and $wait -le 2.5) {
        "No BCDEdit fix is recommended from this report. The scan process wake path is clean."
    }
    else {
        "Apply only one change at a time, reboot after BCDEdit, then retest."
    }

    $lines = @(
        "Timer solver",
        "============",
        "Action guide: $actionVerdict",
        "Actions: MUST $mustFix | SHOULD $shouldFix | REVIEW $reviewCount | OPTIONAL $optionalCount",
        "Legend: MUST FIX=change now | SHOULD FIX=fix before trusting | REVIEW=retest/check | OPTIONAL=A/B only | KEEP=leave",
        "",
        "State: $state",
        "Analysis: $analysisOverall",
        "Competitive target: $analysisCompetitiveTarget",
        "Lowest supported: $lowestSupportedResolution ms | current: $currentResolution ms",
        "Global timer mode: $analysisGlobalMode",
        "External Sleep tester: $analysisExternalSleep",
        "Remaining jitter: $analysisRemainingJitter",
        "",
        "Timer hold: $timerHold",
        "GUI process policy: $guiPolicyLine",
        "Scan process policy: $reportPolicyLine",
        "Global timer mode: $globalTimerLine",
        "Boot baseline: $bootLine",
        "High-res waitable API: $apiLine",
        "",
        "Last report:",
        "  NtQueryTimerResolution: $timer ms",
        "  Thread.Sleep(1) p95:    $sleep ms",
        "  Waitable timer p95:     $wait ms",
        "  Waitable method:        $waitMethod",
        "  Waitable error:         $waitError",
        "  Waitable timer request: $waitTimerRequest at $waitTimerRequestMs ms",
        "  Policy note:            $reportPolicyNote",
        "",
        "Power unlocker:",
        "  hidden settings:        $powerHidden / $powerTotal",
        "  show all command:       powercfg /qh SCHEME_CURRENT",
        "  unhide all effect:      sets PowerSettings Attributes=2, values unchanged",
        "  USB power saving:       $usbPowerEnabled enabled / $usbPowerMatched matched",
        "",
        "Boot/kernel:",
        "  disabledynamictick:     $dynamicTick",
        "  useplatformclock:       $platformClock",
        "  useplatformtick:        $platformTick",
        "  VBS status:             $vbs",
        "",
        "CPU scheduler / logical processors:",
        "  CPU:                    $cpuName",
        "  profile:                $cpuProfile",
        "  physical cores:         $cpuCores",
        "  expected cores:         $cpuExpectedCores",
        "  CCD layout:             $cpuCcdCount CCD(s), $cpuCoresPerCcd core(s) per CCD",
        "  visible logical:        $cpuVisibleLogical",
        "  expected logical:       $cpuExpectedLogical",
        "  visible threads/core:   $cpuVisibleThreadsPerCore",
        "  expected threads/core:  $cpuExpectedThreadsPerCore",
        "  SMT/HT state:           $cpuSmtState ($cpuSmtConfidence)",
        "  SMT/HT recommendation:  $cpuSmtRecommendation",
        "  BCD numproc active:     $cpuBcdNumProcActive",
        "  BCD numproc:            $cpuBcdNumProc",
        "  CPU SET 16 allowed:     $cpuSet16Allowed",
        "  set reason:             $cpuSet16BlockedReason",
        "  CPU RESTORE allowed:    $cpuRestoreAllowed",
        "  restore recommended:    $cpuRestoreRecommended",
        "  recommendation:         $cpuSolverRecommendation",
        "",
        "Recommended order:",
        "  0. $actionLine",
        "  C. Competitive timer target: $analysisCompetitiveSteps",
        "  1. Use FIX PROC POLICY for this GUI/process, then RUN RETEST.",
        "  2. Use HOLD 0.5MS during tests if the current process needs a timer request.",
        "  3. If another timer tester still shows 15.6 ms, use APPLY GLOBAL MODE and reboot.",
        "  4. Keep disabledynamictick=yes for repeatable benchmark profiles.",
        "  5. Keep useplatformclock/useplatformtick deleted unless you measured a win.",
        "  6. Use GAME DVR OFF for capture/replay warnings; use GAME MODE ON only when Game Mode is off/custom.",
        "  7. Use POWER SHOW ALL to inspect hidden/current power settings; POWER UNHIDE ALL only unlocks UI visibility.",
        "  8. Use CPU RESTORE when numproc is active and unintended; CPU SET 16 cannot enable SMT/Hyper-Threading.",
        "  9. Use USB POWER SAVE OFF only for a strict input-latency benchmark profile, then rescan.",
        "  10. Reboot after registry/BCDEdit changes when the Fixes tab says reboot=true.",
        "  11. Open the fixes tab for exact steps, commands, admin/reboot flags and risk notes.",
        "  12. For final game proof, compare CapFrameX/PresentMon/LDAT style evidence.",
        "",
        "Important:",
        "  Windows can report 0.5 ms globally while a specific process still wakes coarse.",
        "  GLOBAL MODE is for legacy apps/tests that do not make their own timer request.",
        "  numproc is a boot processor-count override, not a universal FPS tweak."
    )

    $script:SolverBox.Text = ($lines -join "`r`n")
}

$bg = [Drawing.Color]::FromArgb(4, 7, 7)
$panel = [Drawing.Color]::FromArgb(8, 13, 12)
$panel2 = [Drawing.Color]::FromArgb(13, 21, 19)
$line = [Drawing.Color]::FromArgb(35, 75, 58)
$green = [Drawing.Color]::FromArgb(98, 255, 153)
$muted = [Drawing.Color]::FromArgb(118, 172, 142)
$cyan = [Drawing.Color]::FromArgb(99, 208, 255)
$amber = [Drawing.Color]::FromArgb(247, 199, 91)
$red = [Drawing.Color]::FromArgb(255, 94, 94)

$script:Form = New-Object System.Windows.Forms.Form
$script:Form.Text = "Gaming Status Bench // terminal GUI"
$script:Form.StartPosition = "CenterScreen"
$script:Form.MinimumSize = New-Object Drawing.Size(1080, 720)
$script:Form.Size = New-Object Drawing.Size(1240, 820)
$script:Form.BackColor = $bg
$script:Form.ForeColor = $green
$script:Form.Font = New-Object Drawing.Font("Consolas", 9)
$script:Form.Add_FormClosing({
    if ($script:TimerHoldActive) {
        Set-TimerHold $false
    }
})

$top = New-Object System.Windows.Forms.Panel
$top.Dock = "Top"
$top.Height = 86
$top.BackColor = $panel
$top.Padding = New-Object System.Windows.Forms.Padding(14, 10, 14, 10)
$script:Form.Controls.Add($top)

$title = New-Object System.Windows.Forms.Label
$title.Text = "GAMING STATUS BENCH"
$title.Font = New-Object Drawing.Font("Consolas", 20, [Drawing.FontStyle]::Bold)
$title.ForeColor = $green
$title.Location = New-Object Drawing.Point(16, 10)
$title.Size = New-Object Drawing.Size(420, 32)
$top.Controls.Add($title)

$script:StatusLabel = New-Object System.Windows.Forms.Label
$script:StatusLabel.Text = "READY"
$script:StatusLabel.Font = New-Object Drawing.Font("Consolas", 16, [Drawing.FontStyle]::Bold)
$script:StatusLabel.ForeColor = $cyan
$script:StatusLabel.TextAlign = "MiddleRight"
$script:StatusLabel.Anchor = "Top,Right"
$script:StatusLabel.Location = New-Object Drawing.Point(934, 13)
$script:StatusLabel.Size = New-Object Drawing.Size(270, 28)
$top.Controls.Add($script:StatusLabel)

$script:HostLabel = New-Object System.Windows.Forms.Label
$script:HostLabel.Text = "host pending | admin=$(Test-IsAdmin) | reports: $script:OutputDir"
$script:HostLabel.ForeColor = $muted
$script:HostLabel.Location = New-Object Drawing.Point(18, 50)
$script:HostLabel.Size = New-Object Drawing.Size(960, 22)
$top.Controls.Add($script:HostLabel)

$body = New-Object System.Windows.Forms.TableLayoutPanel
$body.Dock = "Fill"
$body.ColumnCount = 2
$body.RowCount = 1
$body.BackColor = $bg
$body.Margin = New-Object System.Windows.Forms.Padding(0)
$body.Padding = New-Object System.Windows.Forms.Padding(0)
$body.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 330))) | Out-Null
$body.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$body.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$script:Form.Controls.Add($body)

$left = New-Object System.Windows.Forms.Panel
$left.Dock = "Fill"
$left.BackColor = $panel
$left.Padding = New-Object System.Windows.Forms.Padding(12)
$body.Controls.Add($left, 0, 0)

$configLabel = New-Object System.Windows.Forms.Label
$configLabel.Text = "SCAN CONFIG"
$configLabel.ForeColor = $cyan
$configLabel.Font = New-Object Drawing.Font("Consolas", 11, [Drawing.FontStyle]::Bold)
$configLabel.Location = New-Object Drawing.Point(12, 12)
$configLabel.Size = New-Object Drawing.Size(280, 24)
$left.Controls.Add($configLabel)

$gameLabel = New-Object System.Windows.Forms.Label
$gameLabel.Text = "game exe paths (optional; newline/semicolon)"
$gameLabel.ForeColor = $muted
$gameLabel.Location = New-Object Drawing.Point(12, 46)
$gameLabel.Size = New-Object Drawing.Size(290, 18)
$left.Controls.Add($gameLabel)

$script:GameExeBox = New-Object System.Windows.Forms.TextBox
$script:GameExeBox.Multiline = $true
$script:GameExeBox.ScrollBars = "Vertical"
$script:GameExeBox.BackColor = [Drawing.Color]::Black
$script:GameExeBox.ForeColor = $green
$script:GameExeBox.BorderStyle = "FixedSingle"
$script:GameExeBox.Font = New-Object Drawing.Font("Consolas", 9)
$script:GameExeBox.Location = New-Object Drawing.Point(12, 68)
$script:GameExeBox.Size = New-Object Drawing.Size(295, 88)
$script:GameExeBox.Anchor = "Top,Left,Right"
$left.Controls.Add($script:GameExeBox)

$pingLabel = New-Object System.Windows.Forms.Label
$pingLabel.Text = "ping targets"
$pingLabel.ForeColor = $muted
$pingLabel.Location = New-Object Drawing.Point(12, 170)
$pingLabel.Size = New-Object Drawing.Size(110, 18)
$left.Controls.Add($pingLabel)

$script:PingTargetBox = New-Object System.Windows.Forms.TextBox
$script:PingTargetBox.Text = "1.1.1.1, 8.8.8.8"
$script:PingTargetBox.BackColor = [Drawing.Color]::Black
$script:PingTargetBox.ForeColor = $green
$script:PingTargetBox.BorderStyle = "FixedSingle"
$script:PingTargetBox.Font = New-Object Drawing.Font("Consolas", 9)
$script:PingTargetBox.Location = New-Object Drawing.Point(12, 192)
$script:PingTargetBox.Size = New-Object Drawing.Size(295, 22)
$script:PingTargetBox.Anchor = "Top,Left,Right"
$left.Controls.Add($script:PingTargetBox)

$gamePingProfileLabel = New-Object System.Windows.Forms.Label
$gamePingProfileLabel.Text = "game ping profile(s)"
$gamePingProfileLabel.ForeColor = $muted
$gamePingProfileLabel.Location = New-Object Drawing.Point(12, 224)
$gamePingProfileLabel.Size = New-Object Drawing.Size(180, 18)
$left.Controls.Add($gamePingProfileLabel)

$script:GamePingProfileBox = New-Object System.Windows.Forms.ComboBox
$script:GamePingProfileBox.DropDownStyle = "DropDown"
$script:GamePingProfileBox.BackColor = [Drawing.Color]::Black
$script:GamePingProfileBox.ForeColor = $green
$script:GamePingProfileBox.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$script:GamePingProfileBox.Font = New-Object Drawing.Font("Consolas", 9)
$script:GamePingProfileBox.Location = New-Object Drawing.Point(12, 244)
$script:GamePingProfileBox.Size = New-Object Drawing.Size(295, 24)
$script:GamePingProfileBox.Anchor = "Top,Left,Right"
@("none", "all", "cs2", "valorant", "apex", "cod", "bf6", "fortnite", "trackmania", "tracknations", "marvel-rivals", "rainbow-six-siege") | ForEach-Object {
    $script:GamePingProfileBox.Items.Add($_) | Out-Null
}
$script:GamePingProfileBox.Text = "none"
$left.Controls.Add($script:GamePingProfileBox)

$script:NetworkBox = New-Object System.Windows.Forms.CheckBox
$script:NetworkBox.Text = "network benchmark"
$script:NetworkBox.Checked = $true
$script:NetworkBox.ForeColor = $green
$script:NetworkBox.Location = New-Object Drawing.Point(12, 284)
$script:NetworkBox.Size = New-Object Drawing.Size(190, 22)
$left.Controls.Add($script:NetworkBox)

$pingCountLabel = New-Object System.Windows.Forms.Label
$pingCountLabel.Text = "ping count"
$pingCountLabel.ForeColor = $muted
$pingCountLabel.Location = New-Object Drawing.Point(12, 320)
$pingCountLabel.Size = New-Object Drawing.Size(110, 18)
$left.Controls.Add($pingCountLabel)

$script:PingCountBox = New-Object System.Windows.Forms.NumericUpDown
$script:PingCountBox.Minimum = 1
$script:PingCountBox.Maximum = 30
$script:PingCountBox.Value = 8
$script:PingCountBox.BackColor = [Drawing.Color]::Black
$script:PingCountBox.ForeColor = $green
$script:PingCountBox.BorderStyle = "FixedSingle"
$script:PingCountBox.Location = New-Object Drawing.Point(150, 316)
$script:PingCountBox.Size = New-Object Drawing.Size(78, 22)
$left.Controls.Add($script:PingCountBox)

$timerLabel = New-Object System.Windows.Forms.Label
$timerLabel.Text = "timer samples"
$timerLabel.ForeColor = $muted
$timerLabel.Location = New-Object Drawing.Point(12, 350)
$timerLabel.Size = New-Object Drawing.Size(130, 18)
$left.Controls.Add($timerLabel)

$script:TimerSamplesBox = New-Object System.Windows.Forms.NumericUpDown
$script:TimerSamplesBox.Minimum = 10
$script:TimerSamplesBox.Maximum = 2000
$script:TimerSamplesBox.Increment = 10
$script:TimerSamplesBox.Value = 300
$script:TimerSamplesBox.BackColor = [Drawing.Color]::Black
$script:TimerSamplesBox.ForeColor = $green
$script:TimerSamplesBox.BorderStyle = "FixedSingle"
$script:TimerSamplesBox.Location = New-Object Drawing.Point(150, 346)
$script:TimerSamplesBox.Size = New-Object Drawing.Size(78, 22)
$left.Controls.Add($script:TimerSamplesBox)

$script:RunButton = New-Object System.Windows.Forms.Button
$script:RunButton.Text = "RUN SCAN"
$script:RunButton.Location = New-Object Drawing.Point(12, 392)
$script:RunButton.Size = New-Object Drawing.Size(140, 34)
Set-FlatButtonStyle $script:RunButton $green
$script:RunButton.Add_Click({ Start-GuiScan })
$left.Controls.Add($script:RunButton)

$script:AdminButton = New-Object System.Windows.Forms.Button
$script:AdminButton.Text = "ADMIN"
$script:AdminButton.Location = New-Object Drawing.Point(166, 392)
$script:AdminButton.Size = New-Object Drawing.Size(95, 34)
Set-FlatButtonStyle $script:AdminButton $amber
$script:AdminButton.Add_Click({ Restart-AsAdmin })
$left.Controls.Add($script:AdminButton)

$script:OpenHtmlButton = New-Object System.Windows.Forms.Button
$script:OpenHtmlButton.Text = "OPEN HTML"
$script:OpenHtmlButton.Location = New-Object Drawing.Point(12, 440)
$script:OpenHtmlButton.Size = New-Object Drawing.Size(140, 34)
$script:OpenHtmlButton.Enabled = $false
Set-FlatButtonStyle $script:OpenHtmlButton $cyan
$script:OpenHtmlButton.Add_Click({ Open-Path $script:LastHtmlPath })
$left.Controls.Add($script:OpenHtmlButton)

$script:OpenJsonButton = New-Object System.Windows.Forms.Button
$script:OpenJsonButton.Text = "OPEN JSON"
$script:OpenJsonButton.Location = New-Object Drawing.Point(166, 440)
$script:OpenJsonButton.Size = New-Object Drawing.Size(140, 34)
$script:OpenJsonButton.Enabled = $false
Set-FlatButtonStyle $script:OpenJsonButton $cyan
$script:OpenJsonButton.Add_Click({ Open-Path $script:LastJsonPath })
$left.Controls.Add($script:OpenJsonButton)

$reportsButton = New-Object System.Windows.Forms.Button
$reportsButton.Text = "REPORTS"
$reportsButton.Location = New-Object Drawing.Point(12, 488)
$reportsButton.Size = New-Object Drawing.Size(140, 34)
Set-FlatButtonStyle $reportsButton $muted
$reportsButton.Add_Click({ Open-Path $script:OutputDir })
$left.Controls.Add($reportsButton)

$script:CopySummaryButton = New-Object System.Windows.Forms.Button
$script:CopySummaryButton.Text = "COPY SUM"
$script:CopySummaryButton.Location = New-Object Drawing.Point(166, 488)
$script:CopySummaryButton.Size = New-Object Drawing.Size(140, 34)
$script:CopySummaryButton.Enabled = $false
Set-FlatButtonStyle $script:CopySummaryButton $muted
$script:CopySummaryButton.Add_Click({ Copy-Summary })
$left.Controls.Add($script:CopySummaryButton)

$hint = New-Object System.Windows.Forms.Label
$hint.Text = "Quick answer: scan is read-only. It finds common Windows gaming/latency setup problems and tells you what to keep, review, or fix."
$hint.ForeColor = $muted
$hint.Location = New-Object Drawing.Point(12, 542)
$hint.Size = New-Object Drawing.Size(295, 80)
$hint.Anchor = "Top,Left,Right"
$left.Controls.Add($hint)

$right = New-Object System.Windows.Forms.Panel
$right.Dock = "Fill"
$right.BackColor = $bg
$right.Padding = New-Object System.Windows.Forms.Padding(12, 12, 14, 12)
$body.Controls.Add($right, 1, 0)

$rightLayout = New-Object System.Windows.Forms.TableLayoutPanel
$rightLayout.Dock = "Fill"
$rightLayout.ColumnCount = 1
$rightLayout.RowCount = 2
$rightLayout.BackColor = $bg
$rightLayout.Margin = New-Object System.Windows.Forms.Padding(0)
$rightLayout.Padding = New-Object System.Windows.Forms.Padding(0)
$rightLayout.ColumnStyles.Clear()
$rightLayout.RowStyles.Clear()
$rightLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$rightLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 112))) | Out-Null
$rightLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$right.Controls.Add($rightLayout)

$summary = New-Object System.Windows.Forms.Panel
$summary.Dock = "Fill"
$summary.Height = 112
$summary.BackColor = $bg
$rightLayout.Controls.Add($summary, 0, 0)

$script:OkLabel = New-Object System.Windows.Forms.Label
$script:OkLabel.Text = "OK 0"
$script:OkLabel.Font = New-Object Drawing.Font("Consolas", 18, [Drawing.FontStyle]::Bold)
$script:OkLabel.Location = New-Object Drawing.Point(10, 8)
$script:OkLabel.Size = New-Object Drawing.Size(130, 32)
$summary.Controls.Add($script:OkLabel)

$script:WarnLabel = New-Object System.Windows.Forms.Label
$script:WarnLabel.Text = "WARN 0"
$script:WarnLabel.Font = New-Object Drawing.Font("Consolas", 18, [Drawing.FontStyle]::Bold)
$script:WarnLabel.Location = New-Object Drawing.Point(150, 8)
$script:WarnLabel.Size = New-Object Drawing.Size(150, 32)
$summary.Controls.Add($script:WarnLabel)

$script:FailLabel = New-Object System.Windows.Forms.Label
$script:FailLabel.Text = "FAIL 0"
$script:FailLabel.Font = New-Object Drawing.Font("Consolas", 18, [Drawing.FontStyle]::Bold)
$script:FailLabel.Location = New-Object Drawing.Point(315, 8)
$script:FailLabel.Size = New-Object Drawing.Size(140, 32)
$summary.Controls.Add($script:FailLabel)

$script:InfoLabel = New-Object System.Windows.Forms.Label
$script:InfoLabel.Text = "INFO 0"
$script:InfoLabel.Font = New-Object Drawing.Font("Consolas", 18, [Drawing.FontStyle]::Bold)
$script:InfoLabel.Location = New-Object Drawing.Point(470, 8)
$script:InfoLabel.Size = New-Object Drawing.Size(140, 32)
$summary.Controls.Add($script:InfoLabel)

$script:UnknownLabel = New-Object System.Windows.Forms.Label
$script:UnknownLabel.Text = "UNKNOWN 0"
$script:UnknownLabel.Font = New-Object Drawing.Font("Consolas", 18, [Drawing.FontStyle]::Bold)
$script:UnknownLabel.Location = New-Object Drawing.Point(625, 8)
$script:UnknownLabel.Size = New-Object Drawing.Size(180, 32)
$summary.Controls.Add($script:UnknownLabel)

$script:TimerLabel = New-Object System.Windows.Forms.Label
$script:TimerLabel.Text = "timer pending"
$script:TimerLabel.ForeColor = $green
$script:TimerLabel.Location = New-Object Drawing.Point(12, 52)
$script:TimerLabel.Size = New-Object Drawing.Size(620, 20)
$summary.Controls.Add($script:TimerLabel)

$script:DisplayLabel = New-Object System.Windows.Forms.Label
$script:DisplayLabel.Text = "display pending"
$script:DisplayLabel.ForeColor = $muted
$script:DisplayLabel.Location = New-Object Drawing.Point(390, 52)
$script:DisplayLabel.Size = New-Object Drawing.Size(480, 20)
$summary.Controls.Add($script:DisplayLabel)

$script:NetworkLabel = New-Object System.Windows.Forms.Label
$script:NetworkLabel.Text = "network pending"
$script:NetworkLabel.ForeColor = $muted
$script:NetworkLabel.Location = New-Object Drawing.Point(12, 78)
$script:NetworkLabel.Size = New-Object Drawing.Size(720, 20)
$summary.Controls.Add($script:NetworkLabel)

$tabs = New-Object System.Windows.Forms.TabControl
$tabs.Dock = "Fill"
$tabs.Appearance = "Normal"
$tabs.BackColor = $bg
$tabs.ForeColor = $green
$tabs.Margin = New-Object System.Windows.Forms.Padding(0, 8, 0, 0)
$rightLayout.Controls.Add($tabs, 0, 1)

$findingsTab = New-Object System.Windows.Forms.TabPage
$findingsTab.Text = "findings"
$findingsTab.BackColor = $bg
$findingsTab.Padding = New-Object System.Windows.Forms.Padding(6, 8, 6, 6)
$tabs.TabPages.Add($findingsTab) | Out-Null

$script:FindingsList = New-Object System.Windows.Forms.ListView
$script:FindingsList.Dock = "Fill"
$script:FindingsList.View = "Details"
$script:FindingsList.FullRowSelect = $true
$script:FindingsList.GridLines = $true
$script:FindingsList.BackColor = [Drawing.Color]::Black
$script:FindingsList.ForeColor = $green
$script:FindingsList.Font = New-Object Drawing.Font("Consolas", 9)
$script:FindingsList.Columns.Add("status", 72) | Out-Null
$script:FindingsList.Columns.Add("decision", 112) | Out-Null
$script:FindingsList.Columns.Add("area", 130) | Out-Null
$script:FindingsList.Columns.Add("name", 260) | Out-Null
$script:FindingsList.Columns.Add("value", 170) | Out-Null
$script:FindingsList.Columns.Add("action", 420) | Out-Null
$script:FindingsList.Columns.Add("note", 420) | Out-Null
$findingsTab.Controls.Add($script:FindingsList)

$solverTab = New-Object System.Windows.Forms.TabPage
$solverTab.Text = "solver"
$solverTab.BackColor = $bg
$solverTab.Padding = New-Object System.Windows.Forms.Padding(8)
$tabs.TabPages.Add($solverTab) | Out-Null

$solverLayout = New-Object System.Windows.Forms.TableLayoutPanel
$solverLayout.Dock = "Fill"
$solverLayout.ColumnCount = 1
$solverLayout.RowCount = 3
$solverLayout.BackColor = $bg
$solverLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$solverLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 38))) | Out-Null
$solverLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$solverLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 172))) | Out-Null
$solverTab.Controls.Add($solverLayout)

$script:SolverStatusLabel = New-Object System.Windows.Forms.Label
$script:SolverStatusLabel.Text = "solver: no report"
$script:SolverStatusLabel.Dock = "Fill"
$script:SolverStatusLabel.ForeColor = $cyan
$script:SolverStatusLabel.Font = New-Object Drawing.Font("Consolas", 13, [Drawing.FontStyle]::Bold)
$solverLayout.Controls.Add($script:SolverStatusLabel, 0, 0)

$script:SolverBox = New-Object System.Windows.Forms.RichTextBox
$script:SolverBox.Dock = "Fill"
$script:SolverBox.ReadOnly = $true
$script:SolverBox.BackColor = [Drawing.Color]::Black
$script:SolverBox.ForeColor = $green
$script:SolverBox.BorderStyle = "FixedSingle"
$script:SolverBox.Font = New-Object Drawing.Font("Consolas", 9)
$script:SolverBox.Text = "Run a scan, then open this tab for timer/network/display solver actions."
$solverLayout.Controls.Add($script:SolverBox, 0, 1)

$solverButtons = New-Object System.Windows.Forms.FlowLayoutPanel
$solverButtons.Dock = "Fill"
$solverButtons.BackColor = $bg
$solverButtons.FlowDirection = "LeftToRight"
$solverButtons.WrapContents = $true
$solverButtons.Padding = New-Object System.Windows.Forms.Padding(0, 10, 0, 0)
$solverLayout.Controls.Add($solverButtons, 0, 2)

$processPolicyButton = New-Object System.Windows.Forms.Button
$processPolicyButton.Text = "FIX PROC POLICY"
$processPolicyButton.Size = New-Object Drawing.Size(155, 34)
Set-FlatButtonStyle $processPolicyButton $cyan
$processPolicyButton.Add_Click({ Apply-ProcessTimerPolicy | Out-Null })
$solverButtons.Controls.Add($processPolicyButton)

$timerHoldButton = New-Object System.Windows.Forms.Button
$timerHoldButton.Text = "HOLD 0.5MS"
$timerHoldButton.Size = New-Object Drawing.Size(130, 34)
Set-FlatButtonStyle $timerHoldButton $green
$timerHoldButton.Add_Click({ Set-TimerHold $true })
$solverButtons.Controls.Add($timerHoldButton)

$timerReleaseButton = New-Object System.Windows.Forms.Button
$timerReleaseButton.Text = "RELEASE"
$timerReleaseButton.Size = New-Object Drawing.Size(110, 34)
Set-FlatButtonStyle $timerReleaseButton $amber
$timerReleaseButton.Add_Click({ Set-TimerHold $false })
$solverButtons.Controls.Add($timerReleaseButton)

$timerRetestButton = New-Object System.Windows.Forms.Button
$timerRetestButton.Text = "RUN RETEST"
$timerRetestButton.Size = New-Object Drawing.Size(125, 34)
Set-FlatButtonStyle $timerRetestButton $cyan
$timerRetestButton.Add_Click({
    $script:NetworkBox.Checked = $false
    $script:TimerSamplesBox.Value = 120
    Start-GuiScan
})
$solverButtons.Controls.Add($timerRetestButton)

$copySolverButton = New-Object System.Windows.Forms.Button
$copySolverButton.Text = "COPY CMDS"
$copySolverButton.Size = New-Object Drawing.Size(120, 34)
Set-FlatButtonStyle $copySolverButton $muted
$copySolverButton.Add_Click({ Copy-TimerSolverCommands })
$solverButtons.Controls.Add($copySolverButton)

$applyGlobalTimerButton = New-Object System.Windows.Forms.Button
$applyGlobalTimerButton.Text = "APPLY GLOBAL MODE"
$applyGlobalTimerButton.Size = New-Object Drawing.Size(170, 34)
Set-FlatButtonStyle $applyGlobalTimerButton $red
$applyGlobalTimerButton.Add_Click({ Apply-GlobalTimerResolutionRequests })
$solverButtons.Controls.Add($applyGlobalTimerButton)

$applyBcdeditButton = New-Object System.Windows.Forms.Button
$applyBcdeditButton.Text = "APPLY BCDEDIT"
$applyBcdeditButton.Size = New-Object Drawing.Size(145, 34)
Set-FlatButtonStyle $applyBcdeditButton $red
$applyBcdeditButton.Add_Click({ Apply-BcdeditBaseline })
$solverButtons.Controls.Add($applyBcdeditButton)

$script:CpuSet16Button = New-Object System.Windows.Forms.Button
$script:CpuSet16Button.Text = "CPU SET 16"
$script:CpuSet16Button.Size = New-Object Drawing.Size(125, 34)
Set-FlatButtonStyle $script:CpuSet16Button $red
$script:CpuSet16Button.Enabled = $false
$script:CpuSet16Button.Add_Click({ Apply-CpuSet16 })
$solverButtons.Controls.Add($script:CpuSet16Button)

$script:CpuRestoreButton = New-Object System.Windows.Forms.Button
$script:CpuRestoreButton.Text = "CPU RESTORE"
$script:CpuRestoreButton.Size = New-Object Drawing.Size(135, 34)
Set-FlatButtonStyle $script:CpuRestoreButton $amber
$script:CpuRestoreButton.Enabled = $false
$script:CpuRestoreButton.Add_Click({ Apply-CpuRestore })
$solverButtons.Controls.Add($script:CpuRestoreButton)

$script:CopyCpuFixButton = New-Object System.Windows.Forms.Button
$script:CopyCpuFixButton.Text = "COPY CPU FIX"
$script:CopyCpuFixButton.Size = New-Object Drawing.Size(135, 34)
Set-FlatButtonStyle $script:CopyCpuFixButton $muted
$script:CopyCpuFixButton.Add_Click({ Copy-CpuFixCommands })
$solverButtons.Controls.Add($script:CopyCpuFixButton)

$gameDvrButton = New-Object System.Windows.Forms.Button
$gameDvrButton.Text = "GAME DVR OFF"
$gameDvrButton.Size = New-Object Drawing.Size(135, 34)
Set-FlatButtonStyle $gameDvrButton $amber
$gameDvrButton.Add_Click({ Apply-GameDvrBenchmarkOff })
$solverButtons.Controls.Add($gameDvrButton)

$gameModeButton = New-Object System.Windows.Forms.Button
$gameModeButton.Text = "GAME MODE ON"
$gameModeButton.Size = New-Object Drawing.Size(145, 34)
Set-FlatButtonStyle $gameModeButton $green
$gameModeButton.Add_Click({ Apply-GameModeOn })
$solverButtons.Controls.Add($gameModeButton)

$capturesButton = New-Object System.Windows.Forms.Button
$capturesButton.Text = "OPEN CAPTURES"
$capturesButton.Size = New-Object Drawing.Size(150, 34)
Set-FlatButtonStyle $capturesButton $cyan
$capturesButton.Add_Click({ Open-CapturesSettings })
$solverButtons.Controls.Add($capturesButton)

$copyFixesButton = New-Object System.Windows.Forms.Button
$copyFixesButton.Text = "COPY FIXES"
$copyFixesButton.Size = New-Object Drawing.Size(125, 34)
Set-FlatButtonStyle $copyFixesButton $muted
$copyFixesButton.Add_Click({ Copy-FixGuideCommands })
$solverButtons.Controls.Add($copyFixesButton)

$powerShowAllButton = New-Object System.Windows.Forms.Button
$powerShowAllButton.Text = "POWER SHOW ALL"
$powerShowAllButton.Size = New-Object Drawing.Size(155, 34)
Set-FlatButtonStyle $powerShowAllButton $cyan
$powerShowAllButton.Add_Click({ Copy-PowerShowAll })
$solverButtons.Controls.Add($powerShowAllButton)

$powerUnhideAllButton = New-Object System.Windows.Forms.Button
$powerUnhideAllButton.Text = "POWER UNHIDE ALL"
$powerUnhideAllButton.Size = New-Object Drawing.Size(175, 34)
Set-FlatButtonStyle $powerUnhideAllButton $red
$powerUnhideAllButton.Add_Click({ Apply-PowerUnhideAll })
$solverButtons.Controls.Add($powerUnhideAllButton)

$usbPowerSaveOffButton = New-Object System.Windows.Forms.Button
$usbPowerSaveOffButton.Text = "USB POWER SAVE OFF"
$usbPowerSaveOffButton.Size = New-Object Drawing.Size(185, 34)
Set-FlatButtonStyle $usbPowerSaveOffButton $amber
$usbPowerSaveOffButton.Add_Click({ Apply-UsbPowerSavingOff })
$solverButtons.Controls.Add($usbPowerSaveOffButton)

$fixesTab = New-Object System.Windows.Forms.TabPage
$fixesTab.Text = "fixes"
$fixesTab.BackColor = $bg
$fixesTab.Padding = New-Object System.Windows.Forms.Padding(8)
$tabs.TabPages.Add($fixesTab) | Out-Null

$script:FixesBox = New-Object System.Windows.Forms.RichTextBox
$script:FixesBox.Dock = "Fill"
$script:FixesBox.ReadOnly = $true
$script:FixesBox.BackColor = [Drawing.Color]::Black
$script:FixesBox.ForeColor = $green
$script:FixesBox.BorderStyle = "FixedSingle"
$script:FixesBox.Font = New-Object Drawing.Font("Consolas", 9)
$script:FixesBox.Text = "Run a scan, then open this tab for concrete fix steps, commands, admin/reboot flags and risk notes."
$fixesTab.Controls.Add($script:FixesBox)

$logTab = New-Object System.Windows.Forms.TabPage
$logTab.Text = "terminal"
$logTab.BackColor = $bg
$tabs.TabPages.Add($logTab) | Out-Null

$script:LogBox = New-Object System.Windows.Forms.RichTextBox
$script:LogBox.Dock = "Fill"
$script:LogBox.ReadOnly = $true
$script:LogBox.BackColor = [Drawing.Color]::Black
$script:LogBox.ForeColor = $green
$script:LogBox.BorderStyle = "FixedSingle"
$script:LogBox.Font = New-Object Drawing.Font("Consolas", 9)
$logTab.Controls.Add($script:LogBox)

$detailsTab = New-Object System.Windows.Forms.TabPage
$detailsTab.Text = "json"
$detailsTab.BackColor = $bg
$tabs.TabPages.Add($detailsTab) | Out-Null

$script:DetailsBox = New-Object System.Windows.Forms.TextBox
$script:DetailsBox.Dock = "Fill"
$script:DetailsBox.Multiline = $true
$script:DetailsBox.ScrollBars = "Both"
$script:DetailsBox.ReadOnly = $true
$script:DetailsBox.WordWrap = $false
$script:DetailsBox.BackColor = [Drawing.Color]::Black
$script:DetailsBox.ForeColor = $green
$script:DetailsBox.BorderStyle = "FixedSingle"
$script:DetailsBox.Font = New-Object Drawing.Font("Consolas", 8.5)
$detailsTab.Controls.Add($script:DetailsBox)

Set-SummaryLabel $script:OkLabel "OK 0" "OK"
Set-SummaryLabel $script:WarnLabel "WARN 0" "WARN"
Set-SummaryLabel $script:FailLabel "FAIL 0" "FAIL"
Set-SummaryLabel $script:InfoLabel "INFO 0" "INFO"
Set-SummaryLabel $script:UnknownLabel "UNKNOWN 0" "UNKNOWN"

Write-TerminalLog "ready"
Write-TerminalLog "collector: $script:CollectorPath"
Write-TerminalLog "reports: $script:OutputDir"
if (-not (Test-IsAdmin)) {
    Write-TerminalLog "not elevated; use ADMIN button for full adapter/BCDEdit visibility" $amber
}

[void]$script:Form.ShowDialog()
