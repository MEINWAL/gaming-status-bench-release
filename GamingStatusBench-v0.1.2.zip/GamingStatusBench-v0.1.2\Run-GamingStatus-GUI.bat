@echo off
setlocal
set "SCRIPT=%~dp0tools\gaming-status\GamingStatusGui.ps1"

if not exist "%SCRIPT%" (
  echo GamingStatusGui.ps1 was not found:
  echo %SCRIPT%
  exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%SCRIPT%" %*
