@echo off
setlocal
set "SCRIPT=%~dp0tools\gaming-status\GamingStatus.ps1"

if not exist "%SCRIPT%" (
  echo GamingStatus.ps1 was not found:
  echo %SCRIPT%
  exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -OpenHtml %*
echo.
pause
