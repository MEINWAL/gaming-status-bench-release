[CmdletBinding(PositionalBinding=$false)]
param(
    [string[]]$GameExePath = @(),
    [string[]]$PingTarget = @("1.1.1.1", "8.8.8.8"),
    [string[]]$GamePingProfile = @(),
    [int]$PingCount = 8,
    [int]$TimerSampleCount = 300,
    [int]$SleepMs = 1,
    [string]$OutputDir = "",
    [switch]$NoNetworkBenchmark,
    [switch]$NoHtml,
    [switch]$OpenHtml,
    [switch]$Quiet
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = "Continue"

$script:Findings = New-Object System.Collections.Generic.List[object]
$script:Raw = [ordered]@{}

if (-not $OutputDir) {
    $OutputDir = Join-Path $PSScriptRoot "..\..\reports"
}

function Split-InputList {
    param(
        [string[]]$Values,
        [string]$Pattern
    )

    $items = New-Object System.Collections.Generic.List[string]
    foreach ($value in @($Values)) {
        if (-not $value) { continue }
        foreach ($part in ([string]$value -split $Pattern)) {
            $trimmed = $part.Trim()
            if ($trimmed) {
                $items.Add($trimmed) | Out-Null
            }
        }
    }
    return [string[]]$items.ToArray()
}

function New-GamePingTarget {
    param(
        [string]$Profile,
        [string]$Game,
        [string]$Target,
        [string]$Kind,
        [string]$Note
    )

    return [pscustomobject]@{
        Profile = $Profile
        Game = $Game
        Target = $Target
        Kind = $Kind
        Note = $Note
    }
}

function Get-GamePingProfileCatalog {
    $catalog = [ordered]@{}

    $catalog["cs2"] = @(
        (New-GamePingTarget "cs2" "Counter-Strike 2" "steamcommunity.com" "Valve/Steam route probe" "CS2 uses Valve matchmaking/SDR routing; this is not exact in-match ping."),
        (New-GamePingTarget "cs2" "Counter-Strike 2" "api.steampowered.com" "Valve API route probe" "Useful for Steam/Valve reachability, not a specific match server.")
    )
    $catalog["valorant"] = @(
        (New-GamePingTarget "valorant" "VALORANT" "auth.riotgames.com" "Riot service route probe" "VALORANT match routing is region/account dependent; use in-game ping as source of truth."),
        (New-GamePingTarget "valorant" "VALORANT" "valorant.secure.dyn.riotcdn.net" "Riot CDN route probe" "CDN/service probe, not exact match server.")
    )
    $catalog["apex"] = @(
        (New-GamePingTarget "apex" "Apex Legends" "signin.ea.com" "EA service route probe" "Apex exposes data-center latency in game; this is an EA route probe."),
        (New-GamePingTarget "apex" "Apex Legends" "ea.com" "EA web route probe" "Service reachability only.")
    )
    $catalog["cod"] = @(
        (New-GamePingTarget "cod" "Call of Duty" "profile.callofduty.com" "Activision service route probe" "Call of Duty matchmaking servers are dynamic; this is not exact lobby ping."),
        (New-GamePingTarget "cod" "Call of Duty" "callofduty.com" "Activision web route probe" "Service reachability only.")
    )
    $catalog["bf6"] = @(
        (New-GamePingTarget "bf6" "Battlefield" "signin.ea.com" "EA service route probe" "Battlefield server routing is game/session dependent; this is an EA route probe."),
        (New-GamePingTarget "bf6" "Battlefield" "ea.com" "EA web route probe" "Service reachability only.")
    )
    $catalog["fortnite"] = @(
        (New-GamePingTarget "fortnite" "Fortnite" "ping-eu.ds.on.epicgames.com" "Epic datacenter ping endpoint" "Official Epic Games data-center ping endpoint."),
        (New-GamePingTarget "fortnite" "Fortnite" "ping-nae.ds.on.epicgames.com" "Epic datacenter ping endpoint" "Official Epic Games data-center ping endpoint."),
        (New-GamePingTarget "fortnite" "Fortnite" "ping-naw.ds.on.epicgames.com" "Epic datacenter ping endpoint" "Official Epic Games data-center ping endpoint."),
        (New-GamePingTarget "fortnite" "Fortnite" "ping-br.ds.on.epicgames.com" "Epic datacenter ping endpoint" "Official Epic Games data-center ping endpoint."),
        (New-GamePingTarget "fortnite" "Fortnite" "ping-asia.ds.on.epicgames.com" "Epic datacenter ping endpoint" "Official Epic Games data-center ping endpoint."),
        (New-GamePingTarget "fortnite" "Fortnite" "ping-oce.ds.on.epicgames.com" "Epic datacenter ping endpoint" "Official Epic Games data-center ping endpoint."),
        (New-GamePingTarget "fortnite" "Fortnite" "ping-me.ds.on.epicgames.com" "Epic datacenter ping endpoint" "Official Epic Games data-center ping endpoint.")
    )
    $catalog["trackmania"] = @(
        (New-GamePingTarget "trackmania" "Trackmania" "public-ubiservices.ubi.com" "Ubisoft service route probe" "Trackmania online services run through Ubisoft services; not exact lobby ping."),
        (New-GamePingTarget "trackmania" "Trackmania" "ubisoftconnect.com" "Ubisoft Connect route probe" "Service reachability only.")
    )
    $catalog["tracknations"] = @(
        (New-GamePingTarget "tracknations" "Trackmania Nations" "public-ubiservices.ubi.com" "Ubisoft service route probe" "Legacy/community routing can vary; not exact server ping."),
        (New-GamePingTarget "tracknations" "Trackmania Nations" "ubisoftconnect.com" "Ubisoft Connect route probe" "Service reachability only.")
    )
    $catalog["marvel-rivals"] = @(
        (New-GamePingTarget "marvel-rivals" "Marvel Rivals" "marvelrivals.com" "Marvel Rivals service route probe" "Use the game's own network test/in-game ping for exact region results."),
        (New-GamePingTarget "marvel-rivals" "Marvel Rivals" "neteasegames.com" "NetEase service route probe" "Publisher/service route only.")
    )
    $catalog["rainbow-six-siege"] = @(
        (New-GamePingTarget "rainbow-six-siege" "Rainbow Six Siege" "public-ubiservices.ubi.com" "Ubisoft service route probe" "Rainbow Six Siege uses session/region-dependent routing; not exact match ping."),
        (New-GamePingTarget "rainbow-six-siege" "Rainbow Six Siege" "ubisoftconnect.com" "Ubisoft Connect route probe" "Service reachability only.")
    )

    return $catalog
}

function Resolve-GamePingProfiles {
    param([string[]]$Profiles)

    $catalog = Get-GamePingProfileCatalog
    $aliases = @{
        "counterstrike2" = "cs2"
        "counter-strike2" = "cs2"
        "counterstrike" = "cs2"
        "val" = "valorant"
        "apexlegends" = "apex"
        "callofduty" = "cod"
        "warzone" = "cod"
        "battlefield" = "bf6"
        "battlefield6" = "bf6"
        "tm" = "trackmania"
        "trackmanianations" = "tracknations"
        "trackmania-nations" = "tracknations"
        "marvelrivals" = "marvel-rivals"
        "r6" = "rainbow-six-siege"
        "r6s" = "rainbow-six-siege"
        "rainbowsix" = "rainbow-six-siege"
        "rainbowsixsiege" = "rainbow-six-siege"
    }

    $resolved = New-Object System.Collections.Generic.List[object]
    foreach ($profile in @($Profiles)) {
        if (-not $profile) { continue }
        $key = ([string]$profile).Trim().ToLowerInvariant() -replace "[\s_]+", "-"
        $compact = $key -replace "-", ""
        if ($key -eq "all") {
            foreach ($name in $catalog.Keys) {
                foreach ($target in @($catalog[$name])) {
                    $resolved.Add($target) | Out-Null
                }
            }
            continue
        }
        if ($aliases.ContainsKey($key)) { $key = $aliases[$key] }
        elseif ($aliases.ContainsKey($compact)) { $key = $aliases[$compact] }

        if ($catalog.Contains($key)) {
            foreach ($target in @($catalog[$key])) {
                $resolved.Add($target) | Out-Null
            }
        }
        else {
            Add-Finding "Network" "Game ping profile - $profile" "UNKNOWN" "unknown profile" "Known profiles: $($catalog.Keys -join ', ')" "Profile was ignored." 3
        }
    }

    return @($resolved.ToArray())
}

$GameExePath = @(Split-InputList -Values $GameExePath -Pattern "[;`r`n]+")
$PingTarget = @(Split-InputList -Values $PingTarget -Pattern "[,;`r`n\s]+")
$GamePingProfile = @(Split-InputList -Values $GamePingProfile -Pattern "[,;`r`n]+")
if ($PingTarget.Count -eq 0) {
    $PingTarget = @("1.1.1.1", "8.8.8.8")
}

function Test-IsAdmin {
    try {
        $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object Security.Principal.WindowsPrincipal($identity)
        return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    }
    catch {
        return $false
    }
}

function ConvertTo-FirstDouble {
    param([object]$Value)

    if ($null -eq $Value) { return $null }
    if ($Value -is [double] -or $Value -is [float] -or $Value -is [decimal] -or $Value -is [int]) {
        return [double]$Value
    }

    $text = [string]$Value
    if ($text -match "[-+]?\d+(?:[\.,]\d+)?") {
        return [double]::Parse((($matches[0]) -replace ",", "."), [Globalization.CultureInfo]::InvariantCulture)
    }
    return $null
}

function Get-FindingAdvice {
    param(
        [string]$Area,
        [string]$Name,
        [string]$Status,
        [object]$Value,
        [int]$Priority
    )

    $number = ConvertTo-FirstDouble $Value
    $decision = switch ($Status) {
        "OK" { "KEEP" }
        "INFO" { "OPTIONAL" }
        "WARN" { if ($Priority -le 1) { "SHOULD FIX" } else { "REVIEW" } }
        "FAIL" { "MUST FIX" }
        "UNKNOWN" { "CHECK" }
        default { "CHECK" }
    }
    $action = switch ($decision) {
        "KEEP" { "No change needed. Keep this state for repeatable tests." }
        "OPTIONAL" { "Not automatically bad. Benchmark both states before changing." }
        "REVIEW" { "Review before benchmarking; change only if it matches your test goal." }
        "SHOULD FIX" { "Fix before trusting latency/FPS benchmark results." }
        "MUST FIX" { "Fix this before benchmarking; the current state can invalidate results." }
        "CHECK" { "The tool could not verify this. Check manually before relying on it." }
        default { "Review manually." }
    }

    switch -Wildcard ("$Area|$Name") {
        "Timer|Timer analysis verdict" {
            if ($Status -eq "OK") { $decision = "KEEP"; $action = "Timer wake path is clean. No timer change needed." }
            elseif ($Status -eq "FAIL" -or [string]$Value -match "bad") { $decision = "MUST FIX"; $action = "Fix timer wake behavior first; p95 near 15.6 ms means coarse/default clock." }
            elseif ([string]$Value -match "mixed") { $decision = "REVIEW"; $action = "No 15.6 ms blocker detected, but retest idle with more samples before judging final latency." }
            else { $decision = "SHOULD FIX"; $action = "Use the Solver tab, retest idle, and resolve any 15.6 ms/coarse wake path before benchmarking." }
        }
        "Timer|Legacy global timer mode" {
            if ($Status -eq "OK") { $decision = "KEEP"; $action = "Legacy global timer mode is enabled. Keep it if it fixed old tools/games that slept near 15.6 ms." }
            else { $decision = "OPTIONAL"; $action = "Leave this off unless an external Sleep tester or old game still wakes around 15.6 ms; then use APPLY GLOBAL MODE and reboot." }
        }
        "Timer|Global timer-resolution requests" {
            if ($Status -eq "OK") { $decision = "KEEP"; $action = "Legacy global timer mode is enabled. Keep it if it fixed old tools/games that slept near 15.6 ms." }
            else { $decision = "OPTIONAL"; $action = "Leave this off unless an external Sleep tester or old game still wakes around 15.6 ms; then use APPLY GLOBAL MODE and reboot." }
        }
        "Timer|Process timer-resolution policy" {
            if ($Status -eq "OK") {
                $decision = "KEEP"
                $action = "Scan process timer policy is fixed. No user action needed."
            }
            elseif ($Status -eq "WARN") {
                $decision = "REVIEW"
                $action = "If Sleep/Wait p95 are still <= 2.5 ms, this is not a blocker. If they show ~15.6 ms, open the Solver tab, click FIX PROC POLICY, then RUN RETEST."
            }
            else {
                $decision = "CHECK"
                $action = "Could not verify process timer policy. Judge by Sleep/Wait p95 first; fix only if wake tests are coarse."
            }
        }
        "Timer|Thread.Sleep(1) wake p95" {
            if ($Status -eq "OK") { $decision = "KEEP"; $action = "Sleep wake latency is good for this process." }
            elseif ($null -ne $number -and $number -ge 10.0) { $decision = "MUST FIX"; $action = "Sleep is on a ~15.6 ms coarse cadence. Fix timer mode before benchmarking." }
            else { $decision = "REVIEW"; $action = "Minor wake delay or background load. Retest idle with more samples before changing system settings." }
        }
        "Timer|Waitable timer p95" {
            if ($Status -eq "OK") { $decision = "KEEP"; $action = "Waitable timer wake path is good." }
            elseif ($null -ne $number -and $number -ge 10.0) { $decision = "MUST FIX"; $action = "Waitable timers wake coarse. Apply process policy/global timer steps and retest." }
            else { $decision = "REVIEW"; $action = "Visible scheduling delay. Retest idle; compare with game frametime evidence before changing more." }
        }
        "Timer|Current timer resolution" {
            if ($Status -eq "OK") { $decision = "KEEP"; $action = "Reported timer resolution is fine. Judge final state by Sleep/Wait wake tests too." }
            else { $decision = "SHOULD FIX"; $action = "Start a 0.5-1.0 ms timer request or use the Solver timer hold, then retest." }
        }
        "Timer|Competitive timer target" {
            if ($Status -eq "OK") {
                $decision = "KEEP"
                $action = "Timer resolution is already at the lowest supported level for this PC. Do not chase lower numbers; verify Sleep/Wait and game frametimes instead."
            }
            else {
                $decision = "REVIEW"
                $action = "For the absolute timer target, use Solver: FIX PROC POLICY, HOLD 0.5MS, retest. If old external tools still show ~15.6 ms, APPLY GLOBAL MODE and reboot."
            }
        }
        "Kernel|Forced platform clock / HPET" {
            if ($Status -eq "WARN") { $decision = "SHOULD FIX"; $action = "Usually delete useplatformclock unless you measured a win on this exact PC." }
            else { $decision = "KEEP"; $action = "HPET/platform clock is not forced. Good default for modern gaming PCs." }
        }
        "Kernel|Dynamic tick" {
            if ($Status -eq "OK") { $decision = "KEEP"; $action = "Good benchmark baseline. Keep disabledynamictick=yes if this is your tuned profile." }
            else { $decision = "OPTIONAL"; $action = "Default can be fine. Only change if you are building a strict low-latency benchmark profile." }
        }
        "Kernel|Platform tick" {
            if ($Status -eq "WARN") { $decision = "SHOULD FIX"; $action = "Usually delete useplatformtick unless you measured a win on this exact PC." }
            else { $decision = "KEEP"; $action = "Platform tick is not forced. Good default for modern gaming PCs." }
        }
        "Power|Active power plan" {
            if ($Status -eq "OK") { $decision = "KEEP"; $action = "Power plan is good for repeatable benchmarks." }
            else { $decision = "OPTIONAL"; $action = "Compare against High/Ultimate Performance; keep the plan that wins in your games." }
        }
        "Power|Hidden power settings" {
            if ($Status -eq "OK") { $decision = "KEEP"; $action = "All discovered power settings are already visible/unlocked." }
            elseif ($Status -eq "INFO") { $decision = "OPTIONAL"; $action = "Use the power unlocker only if you want Windows Advanced Power Settings to show every hidden setting." }
            else { $decision = "CHECK"; $action = "Power setting visibility could not be verified. Run as Administrator if you want to use the unlocker." }
        }
        "Fullscreen/Game|GameDVR capture" {
            if ($Status -eq "OK") { $decision = "KEEP"; $action = "Capture is off. Good clean benchmark state." }
            elseif ([string]$Value -match "enabled") { $decision = "SHOULD FIX"; $action = "Disable capture if you do not use it while benchmarking." }
            else { $decision = "OPTIONAL"; $action = "Check Windows Settings > Gaming > Captures if you want the leanest benchmark state." }
        }
        "Fullscreen/Game|GameDVR background recording" {
            if ($Status -eq "OK") { $decision = "KEEP"; $action = "Background recording is off. Good clean benchmark state." }
            elseif ($Status -eq "WARN") { $decision = "SHOULD FIX"; $action = "Disable Windows 'Record what happened' before gaming benchmarks unless you intentionally use it." }
            else { $decision = "OPTIONAL"; $action = "Check Windows Settings > Gaming > Captures if you want the leanest benchmark state." }
        }
        "Fullscreen/Game|Windows Game Mode" {
            if ($Status -eq "OK") { $decision = "KEEP"; $action = "Game Mode is enabled. Usually keep it on for gaming." }
            else { $decision = "OPTIONAL"; $action = "Usually enable Game Mode, then compare on your main games." }
        }
        "Fullscreen/Game|Global FSO/FSE behavior" {
            $decision = "OPTIONAL"; $action = "Not automatically good or bad. Use per-game flags and PresentMon/CapFrameX proof."
        }
        "Display/GPU|Hardware accelerated GPU scheduling" {
            $decision = "OPTIONAL"; $action = "Benchmark HAGS on/off per driver and game. There is no universal best state."
        }
        "Display/GPU|Multiplane Overlay (MPO)" {
            $decision = "OPTIONAL"; $action = "Keep default unless troubleshooting flicker, stutter, overlays or capture issues."
        }
        "Network|Receive-side scaling" {
            if ($Status -eq "OK") { $decision = "KEEP"; $action = "RSS is enabled. Good for modern NICs." }
            else { $decision = "SHOULD FIX"; $action = "Enable RSS for modern wired adapters unless your NIC testing says otherwise." }
        }
        "Network|Interface MTU*" {
            if ($Status -eq "OK") { $decision = "KEEP"; $action = "Interface MTU is standard for Ethernet gaming. Leave it as-is." }
            elseif ([string]$Value -match "1492") { $decision = "OPTIONAL"; $action = "1492 is often normal for PPPoE. Do not force 1500 unless the path supports it." }
            elseif ([string]$Value -match "jumbo|[2-9]\d{3,}") { $decision = "OPTIONAL"; $action = "Jumbo MTU is only useful when the whole LAN path supports it; internet gaming still needs path proof." }
            else { $decision = "REVIEW"; $action = "Verify whether a VPN/tunnel/ISP requires this MTU before changing it." }
        }
        "Network|Path MTU*" {
            if ($Status -eq "OK") { $decision = "KEEP"; $action = "DF ping confirms a clean 1500-byte path to this target." }
            elseif ([string]$Value -match "1492") { $decision = "OPTIONAL"; $action = "1492 path MTU is common on PPPoE. Leave it if this matches your ISP/router path." }
            elseif ($Status -eq "WARN") { $decision = "SHOULD FIX"; $action = "Path MTU looks low or fragmented. Check VPN/router/adapter MTU before network-sensitive benchmarks." }
            else { $decision = "CHECK"; $action = "Path MTU probe could not verify this target, often because ICMP/DF ping is blocked." }
        }
        "Network|Game ping profile*" {
            if ($Status -eq "OK") { $decision = "KEEP"; $action = "Game route probe targets were added. Treat them as route/service probes, not exact match-server ping." }
            elseif ($Status -eq "UNKNOWN") { $decision = "CHECK"; $action = "Unknown game profile. Use one of the listed profile names." }
            else { $decision = "OPTIONAL"; $action = "Game profiles are route probes. In-game ping remains the source of truth for exact match latency." }
        }
        "Network|NIC advanced*" {
            $decision = "OPTIONAL"; $action = "Driver-specific. Keep benchmark state consistent; change one NIC option at a time and retest ping/jitter."
        }
        "Network|Ping*" {
            if ($Status -eq "OK") { $decision = "KEEP"; $action = "Ping/loss looks good for this target." }
            elseif ($Status -eq "INFO") { $decision = "OPTIONAL"; $action = "This probe target did not answer ICMP. For game profiles, this is not proof of bad networking." }
            else { $decision = "SHOULD FIX"; $action = "Fix loss or large jitter before network-sensitive benchmarks." }
        }
        "Security|Virtualization-based security" {
            $decision = "OPTIONAL"; $action = "Security/performance tradeoff. Only change for A/B benchmarks and understand the security cost."
        }
        "Security|Memory integrity / HVCI" {
            $decision = "OPTIONAL"; $action = "Security/performance tradeoff. Do not change blindly; compare both states if needed."
        }
        "Overlays|Overlay/helper processes" {
            if ($Status -eq "OK") { $decision = "KEEP"; $action = "No watched overlays detected. Good clean benchmark state." }
            else { $decision = "SHOULD FIX"; $action = "Close overlays/helpers for clean A/B benchmarks, or keep them identical across runs." }
        }
        "Tool|Administrator rights" {
            if ($Status -eq "OK") { $decision = "KEEP"; $action = "Admin is active; full report visibility is available." }
            else { $decision = "SHOULD FIX"; $action = "Run as Administrator for full adapter, BCDEdit and solver visibility." }
        }
    }

    return [pscustomobject]@{
        Decision = $decision
        Action = $action
    }
}

function New-FixAdvice {
    param(
        [string]$Area,
        [string]$Name,
        [string]$Status,
        [object]$Value,
        [string]$Decision
    )

    $fixAvailable = $false
    $fixSummary = switch ($Decision) {
        "KEEP" { "No fix needed." }
        "OPTIONAL" { "Optional A/B test only; do not change blindly." }
        "REVIEW" { "Retest or verify manually before changing settings." }
        "SHOULD FIX" { "Fix recommended before trusting benchmark results." }
        "MUST FIX" { "Fix required before benchmarking." }
        "CHECK" { "Manual check required; the tool could not verify this." }
        default { "Review manually." }
    }
    $fixSteps = @($fixSummary)
    $fixCommands = @()
    $requiresAdmin = $false
    $requiresReboot = $false
    $solverAction = ""
    $risk = "low"

    switch -Wildcard ("$Area|$Name") {
        "Timer|Current timer resolution" {
            $fixAvailable = $true
            $fixSummary = "Reach the practical minimum timer state, then judge by Sleep/Wait p95."
            $fixSteps = @(
                "Run the GUI as Administrator.",
                "Open solver and click FIX PROC POLICY.",
                "Click HOLD 0.5MS while testing, then RUN RETEST.",
                "If this tool is clean but an old external Sleep tester still shows about 15.6 ms, click APPLY GLOBAL MODE and reboot."
            )
            $fixCommands = @(
                'reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" /v GlobalTimerResolutionRequests /t REG_DWORD /d 1 /f'
            )
            $requiresAdmin = $true
            $requiresReboot = $true
            $solverAction = "FIX PROC POLICY -> HOLD 0.5MS -> RUN RETEST; APPLY GLOBAL MODE only for old external 15.6 ms tools."
            $risk = "medium: global mode can increase power use while a high timer request is active"
        }
        "Timer|Competitive timer target" {
            $fixAvailable = $true
            $fixSummary = "For competitive users: current should match the lowest supported timer resolution; do not chase below hardware/OS minimum."
            $fixSteps = @(
                "Check Lowest supported vs Current in Timer Analysis.",
                "If Current is higher, use solver: FIX PROC POLICY, HOLD 0.5MS, RUN RETEST.",
                "If external legacy tools stay at about 15.6 ms, enable legacy global mode and reboot.",
                "When Current is about 0.5 ms and Sleep/Wait p95 are below 2.5 ms, the timer side is done."
            )
            $fixCommands = @(
                'reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" /v GlobalTimerResolutionRequests /t REG_DWORD /d 1 /f'
            )
            $requiresAdmin = $true
            $requiresReboot = $true
            $solverAction = "Use the timer solver order shown in the GUI."
            $risk = "medium: global mode is compatibility mode, not a universal FPS boost"
        }
        "Timer|Timer analysis verdict" {
            if ($Decision -ne "KEEP") {
                $fixAvailable = $true
                $fixSummary = "Resolve any coarse 15.6 ms wake path before using timer results."
                $fixSteps = @(
                    "Run timer-only retest while the desktop is idle.",
                    "Use FIX PROC POLICY first, then HOLD 0.5MS and RUN RETEST.",
                    "Use APPLY GLOBAL MODE plus reboot only if old external apps still Sleep(1) near 15.6 ms.",
                    "Do not use BCDEdit first unless platform clock/tick findings ask for it."
                )
                $fixCommands = @(
                    'reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" /v GlobalTimerResolutionRequests /t REG_DWORD /d 1 /f'
                )
                $requiresAdmin = $true
                $requiresReboot = $true
                $solverAction = "Timer solver sequence."
                $risk = "medium"
            }
        }
        "Timer|Thread.Sleep(1) wake p95" {
            if ($Decision -in @("MUST FIX", "SHOULD FIX", "REVIEW")) {
                $fixAvailable = $true
                $fixSummary = "Fix coarse Sleep(1) wakeups with process policy/local timer request first."
                $fixSteps = @(
                    "Close obvious background load and run timer-only retest.",
                    "Click FIX PROC POLICY, then HOLD 0.5MS, then RUN RETEST.",
                    "If an external old test still shows about 15.6 ms, APPLY GLOBAL MODE and reboot."
                )
                $fixCommands = @(
                    'reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" /v GlobalTimerResolutionRequests /t REG_DWORD /d 1 /f'
                )
                $requiresAdmin = $true
                $requiresReboot = $true
                $solverAction = "FIX PROC POLICY -> HOLD 0.5MS -> RUN RETEST."
                $risk = "medium"
            }
        }
        "Timer|Waitable timer p95" {
            if ($Decision -in @("MUST FIX", "SHOULD FIX", "REVIEW")) {
                $fixAvailable = $true
                $fixSummary = "Fix coarse waitable timer wakeups with process policy/local timer request first."
                $fixSteps = @(
                    "Run timer-only retest with no game running.",
                    "Click FIX PROC POLICY, then HOLD 0.5MS, then RUN RETEST.",
                    "If p95 remains near 15.6 ms, check legacy global mode and reboot after enabling it."
                )
                $fixCommands = @(
                    'reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" /v GlobalTimerResolutionRequests /t REG_DWORD /d 1 /f'
                )
                $requiresAdmin = $true
                $requiresReboot = $true
                $solverAction = "FIX PROC POLICY -> HOLD 0.5MS -> RUN RETEST."
                $risk = "medium"
            }
        }
        "Timer|Process timer-resolution policy" {
            $fixAvailable = $true
            $fixSummary = "This is fixed per process; use the GUI solver before touching boot settings."
            $fixSteps = @(
                "If Sleep/Wait p95 are already below 2.5 ms, no fix is needed.",
                "If Sleep/Wait p95 are near 15.6 ms, click FIX PROC POLICY and RUN RETEST.",
                "Use HOLD 0.5MS during test sessions if the target process needs an active timer request."
            )
            $solverAction = "FIX PROC POLICY."
            $risk = "low"
        }
        "Timer|Legacy global timer mode" {
            $fixAvailable = $true
            $fixSummary = "Only enable legacy global timer mode when old apps/tools still wake at about 15.6 ms."
            $fixSteps = @(
                "First confirm this tool's Sleep/Wait p95 are clean.",
                "If an external old tester still sleeps around 15.6 ms, enable GlobalTimerResolutionRequests=1.",
                "Reboot, then retest that external tool.",
                "Leave it off if every app you care about requests timers correctly."
            )
            $fixCommands = @(
                'reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" /v GlobalTimerResolutionRequests /t REG_DWORD /d 1 /f',
                'reg delete "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" /v GlobalTimerResolutionRequests /f'
            )
            $requiresAdmin = $true
            $requiresReboot = $true
            $solverAction = "APPLY GLOBAL MODE."
            $risk = "medium: compatibility switch, possible extra power use"
        }
        "Kernel|Forced platform clock / HPET" {
            if ($Decision -ne "KEEP") {
                $fixAvailable = $true
                $fixSummary = "Remove forced platform clock unless you measured it faster on this exact PC."
                $fixSteps = @(
                    "Run Command Prompt or PowerShell as Administrator.",
                    "Delete the forced platform clock override.",
                    "Reboot before retesting timers or games."
                )
                $fixCommands = @('bcdedit /deletevalue useplatformclock')
                $requiresAdmin = $true
                $requiresReboot = $true
                $solverAction = "APPLY BCDEDIT."
                $risk = "medium: boot configuration change"
            }
        }
        "Kernel|Platform tick" {
            if ($Decision -ne "KEEP") {
                $fixAvailable = $true
                $fixSummary = "Remove forced platform tick unless you measured it faster on this exact PC."
                $fixSteps = @(
                    "Run Command Prompt or PowerShell as Administrator.",
                    "Delete the forced platform tick override.",
                    "Reboot before retesting timers or games."
                )
                $fixCommands = @('bcdedit /deletevalue useplatformtick')
                $requiresAdmin = $true
                $requiresReboot = $true
                $solverAction = "APPLY BCDEDIT."
                $risk = "medium: boot configuration change"
            }
        }
        "Kernel|Dynamic tick" {
            if ($Decision -ne "KEEP") {
                $fixAvailable = $true
                $fixSummary = "Optional benchmark-profile baseline; not a universal requirement."
                $fixSteps = @(
                    "Only apply if you want the same strict benchmark baseline as the tool expects.",
                    "Set disabledynamictick=yes.",
                    "Reboot and retest."
                )
                $fixCommands = @('bcdedit /set disabledynamictick yes')
                $requiresAdmin = $true
                $requiresReboot = $true
                $solverAction = "APPLY BCDEDIT."
                $risk = "medium: boot configuration change"
            }
        }
        "Fullscreen/Game|GameDVR capture" {
            if ($Decision -ne "KEEP") {
                $fixAvailable = $true
                $fixSummary = "Disable Windows GameDVR capture for a lean benchmark state."
                $fixSteps = @(
                    "Open Settings > Gaming > Captures and disable capture/background recording.",
                    "Or use the GUI solver button GAME DVR OFF.",
                    "Restart the game before retesting."
                )
                $fixCommands = @(
                    'reg add "HKCU\System\GameConfigStore" /v GameDVR_Enabled /t REG_DWORD /d 0 /f',
                    'reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR" /v AppCaptureEnabled /t REG_DWORD /d 0 /f',
                    'reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR" /v HistoricalCaptureEnabled /t REG_DWORD /d 0 /f'
                )
                $solverAction = "GAME DVR OFF or OPEN CAPTURES."
                $risk = "low: disables Windows capture features"
            }
        }
        "Fullscreen/Game|GameDVR background recording" {
            if ($Decision -ne "KEEP") {
                $fixAvailable = $true
                $fixSummary = "Disable Windows 'Record what happened' before clean gaming benchmarks."
                $fixSteps = @(
                    "Open Settings > Gaming > Captures.",
                    "Disable 'Record what happened' / background recording.",
                    "Or use GAME DVR OFF in the solver.",
                    "Restart the game before retesting."
                )
                $fixCommands = @(
                    'reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR" /v HistoricalCaptureEnabled /t REG_DWORD /d 0 /f'
                )
                $solverAction = "GAME DVR OFF or OPEN CAPTURES."
                $risk = "low: disables replay buffer"
            }
        }
        "Fullscreen/Game|Windows Game Mode" {
            if ($Decision -ne "KEEP") {
                $fixAvailable = $true
                $fixSummary = "Enable Game Mode, then compare on your main games."
                $fixSteps = @(
                    "Use the solver button GAME MODE ON or open Windows Gaming settings.",
                    "Restart the game before retesting.",
                    "Keep it only if it improves or does not hurt your games."
                )
                $fixCommands = @(
                    'reg add "HKCU\Software\Microsoft\GameBar" /v AutoGameModeEnabled /t REG_DWORD /d 1 /f',
                    'reg add "HKCU\Software\Microsoft\GameBar" /v AllowAutoGameMode /t REG_DWORD /d 1 /f'
                )
                $solverAction = "GAME MODE ON."
                $risk = "low"
            }
        }
        "Network|Receive-side scaling" {
            if ($Decision -ne "KEEP") {
                $fixAvailable = $true
                $fixSummary = "Enable RSS on modern wired adapters unless your NIC-specific test says otherwise."
                $fixSteps = @(
                    "Run PowerShell as Administrator.",
                    "Enable RSS for the active adapter name shown in the report.",
                    "Retest ping/jitter and game networking."
                )
                $fixCommands = @('Enable-NetAdapterRss -Name "<adapter name>"')
                $requiresAdmin = $true
                $solverAction = "Manual PowerShell command; adapter name is system-specific."
                $risk = "low-medium: NIC driver-specific"
            }
        }
        "Power|Hidden power settings" {
            if ($Decision -ne "KEEP") {
                $fixAvailable = $true
                $fixSummary = "Show hidden Windows Advanced Power Settings for inspection/tuning."
                $fixSteps = @(
                    "Use POWER SHOW ALL first to inspect the full current plan.",
                    "Use POWER UNHIDE ALL only if you want hidden Advanced Power Settings visible in Windows.",
                    "This does not tune values by itself; it only unlocks UI visibility.",
                    "Export or document your active plan before changing actual power values."
                )
                $fixCommands = @(
                    'powercfg /qh SCHEME_CURRENT',
                    'powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem ''HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings'' -Recurse | Where-Object { $_.PSChildName -match ''^[0-9a-fA-F-]{36}$'' -and $_.PSParentPath -match ''PowerSettings\\[0-9a-fA-F-]{36}$'' } | ForEach-Object { New-ItemProperty -Path $_.PSPath -Name Attributes -Value 2 -PropertyType DWord -Force | Out-Null }"'
                )
                $requiresAdmin = $true
                $solverAction = "POWER SHOW ALL, then POWER UNHIDE ALL if wanted."
                $risk = "medium: unlocks Windows power-setting UI globally, but does not change active values"
            }
        }
        "Network|Interface MTU*" {
            if ($Decision -ne "KEEP") {
                $fixAvailable = $true
                $fixSummary = "Use 1500 for normal Ethernet, 1492 for PPPoE when required, and only use jumbo MTU on a proven LAN path."
                $fixSteps = @(
                    "Do not blindly force MTU; first check whether you use PPPoE, VPN, tunnel software or jumbo frames.",
                    "For normal wired internet gaming, local interface MTU is usually 1500.",
                    "For PPPoE, 1492 can be correct.",
                    "After changing MTU, run the MTU path probe again and retest ping/jitter."
                )
                $fixCommands = @(
                    'Set-NetIPInterface -InterfaceAlias "<adapter name>" -AddressFamily IPv4 -NlMtuBytes 1500',
                    'Set-NetIPInterface -InterfaceAlias "<adapter name>" -AddressFamily IPv4 -NlMtuBytes 1492'
                )
                $requiresAdmin = $true
                $solverAction = "Manual PowerShell command; adapter name and ISP path are system-specific."
                $risk = "medium: wrong MTU can cause fragmentation, blocked sites or unstable networking"
            }
        }
        "Network|Path MTU*" {
            if ($Decision -ne "KEEP") {
                $fixAvailable = $true
                $fixSummary = "Find the highest DF payload that passes, then align router/adapter MTU only if the low value is unexpected."
                $fixSteps = @(
                    "1500 MTU path means ping payload 1472 with DF should pass.",
                    "1492 MTU path means payload 1464 passes; this is often normal on PPPoE.",
                    "If only much smaller payloads pass, check VPN, router WAN MTU, tunneling and jumbo-frame settings.",
                    "Change one layer at a time and retest."
                )
                $fixCommands = @(
                    'ping -f -l 1472 <target>',
                    'ping -f -l 1464 <target>',
                    'Set-NetIPInterface -InterfaceAlias "<adapter name>" -AddressFamily IPv4 -NlMtuBytes 1500'
                )
                $requiresAdmin = $true
                $solverAction = "Manual MTU validation; no safe universal auto-fix."
                $risk = "medium: MTU depends on ISP/router/VPN path"
            }
        }
        "Network|Game ping profile*" {
            $fixAvailable = $true
            $fixSummary = "Use these as game-route probes only; exact match ping belongs to the game client/server browser."
            $fixSteps = @(
                "Select only the games you actually test to keep scans quick.",
                "Compare loss and jitter first; raw ping can differ from in-game ping because matchmaking/relays are dynamic.",
                "If a game profile target blocks ICMP, use the game's built-in network display or server browser for exact numbers."
            )
            $solverAction = "Select a game profile in the GUI or use -GamePingProfile."
            $risk = "low: read-only probes"
        }
        "Network|Ping*" {
            if ($Decision -ne "KEEP") {
                $fixAvailable = $true
                $fixSummary = "Fix packet loss or jitter before judging network-sensitive games."
                $fixSteps = @(
                    "Retest wired Ethernet directly to router.",
                    "Stop downloads/cloud sync/VPN for the test.",
                    "Retest local gateway first, then internet targets.",
                    "If gateway is bad, fix LAN/router/NIC before changing game settings."
                )
                $solverAction = "Retest network; no safe universal command."
                $risk = "low"
            }
        }
        "Overlays|Overlay/helper processes" {
            if ($Decision -ne "KEEP") {
                $fixAvailable = $true
                $fixSummary = "Close overlays/helpers for clean A/B benchmarks, or keep them identical across runs."
                $fixSteps = @(
                    "Close detected overlays before benchmark runs.",
                    "If you need an overlay, keep the same overlay state for every comparison.",
                    "Retest after closing capture/overlay tools."
                )
                $solverAction = "Manual close apps."
                $risk = "low"
            }
        }
        "Tool|Administrator rights" {
            if ($Decision -ne "KEEP") {
                $fixAvailable = $true
                $fixSummary = "Run the tool elevated so BCDEdit, adapter and solver checks are complete."
                $fixSteps = @(
                    "Close the current non-admin window.",
                    "Right-click Run-GamingStatus-GUI.bat and choose Run as administrator, or use the ADMIN button in the GUI.",
                    "Run the scan again."
                )
                $solverAction = "ADMIN button / Run as administrator."
                $risk = "low"
            }
        }
        "Display/GPU|Hardware accelerated GPU scheduling" {
            $fixAvailable = $true
            $fixSummary = "A/B test HAGS per game and driver; there is no universal best state."
            $fixSteps = @(
                "Open Windows graphics settings.",
                "Benchmark HAGS on and off with the same driver/game/settings.",
                "Keep the state that wins in your actual game evidence."
            )
            $solverAction = "Manual A/B test."
            $risk = "medium: requires reboot/sign-out on many systems"
        }
        "Display/GPU|Multiplane Overlay (MPO)" {
            $fixAvailable = $true
            $fixSummary = "Keep MPO default unless troubleshooting flicker, stutter, overlays or capture issues."
            $fixSteps = @(
                "Do not disable MPO just because it exists.",
                "If troubleshooting display/overlay bugs, change only MPO and retest.",
                "Reboot after MPO registry changes."
            )
            $solverAction = "Manual troubleshooting only."
            $requiresReboot = $true
            $risk = "medium: display pipeline change"
        }
        "Security|Virtualization-based security" {
            $fixAvailable = $true
            $fixSummary = "Security/performance tradeoff; only A/B test if you understand the security cost."
            $fixSteps = @(
                "Do not disable VBS blindly.",
                "If you test it, document the current state and benchmark both states.",
                "Prefer keeping security features unless measured game evidence justifies the tradeoff."
            )
            $solverAction = "Manual security decision."
            $requiresAdmin = $true
            $requiresReboot = $true
            $risk = "high: reduces Windows security if disabled"
        }
        "Security|Memory integrity / HVCI" {
            $fixAvailable = $true
            $fixSummary = "Security/performance tradeoff; only A/B test if needed."
            $fixSteps = @(
                "Do not change Memory Integrity blindly.",
                "If you test it, use Windows Security settings and benchmark both states.",
                "Reboot after changing."
            )
            $solverAction = "Manual security decision."
            $requiresAdmin = $true
            $requiresReboot = $true
            $risk = "high: reduces Windows security if disabled"
        }
    }

    return [pscustomobject]@{
        FixAvailable = $fixAvailable
        FixSummary = $fixSummary
        FixSteps = $fixSteps
        FixCommands = $fixCommands
        RequiresAdmin = $requiresAdmin
        RequiresReboot = $requiresReboot
        SolverAction = $solverAction
        Risk = $risk
    }
}

function Add-Finding {
    param(
        [string]$Area,
        [string]$Name,
        [string]$Status,
        [object]$Value,
        [string]$Expected = "",
        [string]$Note = "",
        [int]$Priority = 3
    )

    $advice = Get-FindingAdvice -Area $Area -Name $Name -Status $Status -Value $Value -Priority $Priority
    $fix = New-FixAdvice -Area $Area -Name $Name -Status $Status -Value $Value -Decision $advice.Decision
    $script:Findings.Add([pscustomobject]@{
        Area = $Area
        Name = $Name
        Status = $Status
        Value = $Value
        Expected = $Expected
        Note = $Note
        Decision = $advice.Decision
        Action = $advice.Action
        FixAvailable = $fix.FixAvailable
        FixSummary = $fix.FixSummary
        FixSteps = $fix.FixSteps
        FixCommands = $fix.FixCommands
        RequiresAdmin = $fix.RequiresAdmin
        RequiresReboot = $fix.RequiresReboot
        SolverAction = $fix.SolverAction
        Risk = $fix.Risk
        Priority = $Priority
    }) | Out-Null
}

function Invoke-TextCommand {
    param(
        [string]$FilePath,
        [string[]]$Arguments = @()
    )

    try {
        $argText = ($Arguments | ForEach-Object {
            $part = [string]$_
            if ($part -eq "") {
                '""'
            }
            elseif ($part -match '[\s"]') {
                $escaped = $part -replace '"', '\"'
                '"' + $escaped + '"'
            }
            else {
                $part
            }
        }) -join " "

        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = $FilePath
        $psi.Arguments = $argText
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError = $true
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow = $true

        $process = [System.Diagnostics.Process]::Start($psi)
        $stdout = $process.StandardOutput.ReadToEnd()
        $stderr = $process.StandardError.ReadToEnd()
        $process.WaitForExit()

        $text = (($stdout + "`n" + $stderr) -replace "^\s+|\s+$", "")
        return $text
    }
    catch {
        return "ERROR: $($_.Exception.Message)"
    }
}

function Get-RegistryValueSafe {
    param(
        [string]$Path,
        [string]$Name
    )

    try {
        $item = Get-ItemProperty -Path $Path -ErrorAction Stop
        if ($null -ne $item.PSObject.Properties[$Name]) {
            return $item.$Name
        }
        return $null
    }
    catch {
        return $null
    }
}

function Get-Percentile {
    param(
        [double[]]$Values,
        [double]$Percentile
    )

    if (-not $Values -or $Values.Count -eq 0) {
        return $null
    }

    $sorted = @($Values | Sort-Object)
    if ($sorted.Count -eq 1) {
        return [double]$sorted[0]
    }

    $rank = ($Percentile / 100.0) * ($sorted.Count - 1)
    $low = [Math]::Floor($rank)
    $high = [Math]::Ceiling($rank)
    if ($low -eq $high) {
        return [double]$sorted[$low]
    }

    $weight = $rank - $low
    return ([double]$sorted[$low] * (1 - $weight)) + ([double]$sorted[$high] * $weight)
}

function Format-Number {
    param(
        [Nullable[double]]$Value,
        [int]$Digits = 3
    )

    if ($null -eq $Value) {
        return ""
    }

    return ([double]$Value).ToString("N$Digits", [Globalization.CultureInfo]::InvariantCulture)
}

function ConvertTo-Hashtable {
    param([object]$InputObject)

    if ($null -eq $InputObject) {
        return $null
    }

    if ($InputObject -is [System.Collections.IDictionary]) {
        $hash = [ordered]@{}
        foreach ($key in $InputObject.Keys) {
            $hash[$key] = ConvertTo-Hashtable $InputObject[$key]
        }
        return $hash
    }

    if ($InputObject -is [System.Collections.IEnumerable] -and $InputObject -isnot [string]) {
        $list = @()
        foreach ($item in $InputObject) {
            $list += ConvertTo-Hashtable $item
        }
        return $list
    }

    $props = @($InputObject.PSObject.Properties | Where-Object { $_.MemberType -in @("NoteProperty", "Property", "AliasProperty") })
    $isSimple = (
        $InputObject -is [string] -or
        $InputObject -is [ValueType] -or
        $InputObject -is [DateTime]
    )

    if (-not $isSimple -and $props.Count -gt 0) {
        $hash = [ordered]@{}
        foreach ($prop in $props) {
            $hash[$prop.Name] = ConvertTo-Hashtable $prop.Value
        }
        return $hash
    }

    return $InputObject
}

function Ensure-NativeTimer {
    if (-not ("GamingStatusNativeTimer" -as [type])) {
        Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Sequential)]
public struct GamingStatusProcessPowerThrottlingState
{
    public uint Version;
    public uint ControlMask;
    public uint StateMask;
}

public static class GamingStatusNativeTimer
{
    [DllImport("ntdll.dll")]
    public static extern int NtQueryTimerResolution(out uint MinimumResolution, out uint MaximumResolution, out uint CurrentResolution);

    [DllImport("ntdll.dll")]
    public static extern int NtSetTimerResolution(uint DesiredResolution, bool SetResolution, out uint CurrentResolution);

    [DllImport("kernel32.dll", EntryPoint="CreateWaitableTimerExW", CharSet=CharSet.Unicode, SetLastError=true)]
    public static extern IntPtr CreateWaitableTimerEx(IntPtr lpTimerAttributes, string lpTimerName, uint dwFlags, uint dwDesiredAccess);

    [DllImport("kernel32.dll", SetLastError=true)]
    public static extern bool SetWaitableTimer(IntPtr hTimer, ref long lpDueTime, int lPeriod, IntPtr pfnCompletionRoutine, IntPtr lpArgToCompletionRoutine, bool fResume);

    [DllImport("kernel32.dll", SetLastError=true)]
    public static extern uint WaitForSingleObject(IntPtr hHandle, uint dwMilliseconds);

    [DllImport("kernel32.dll", SetLastError=true)]
    public static extern bool CloseHandle(IntPtr hObject);

    [DllImport("kernel32.dll")]
    public static extern IntPtr GetCurrentProcess();

    [DllImport("kernel32.dll", SetLastError=true)]
    public static extern bool SetProcessInformation(IntPtr hProcess, int ProcessInformationClass, ref GamingStatusProcessPowerThrottlingState ProcessInformation, int ProcessInformationSize);

    public const int ProcessPowerThrottling = 4;
    public const uint PROCESS_POWER_THROTTLING_CURRENT_VERSION = 1;
    public const uint PROCESS_POWER_THROTTLING_IGNORE_TIMER_RESOLUTION = 0x00000004;
    public const uint CREATE_WAITABLE_TIMER_HIGH_RESOLUTION = 0x00000002;
    public const uint TIMER_ALL_ACCESS = 0x001F0003;
    public const uint WAIT_OBJECT_0 = 0x00000000;
}
"@ -ErrorAction Stop
    }
}

function Get-TimerResolutionStatus {
    $timer = [ordered]@{
        Supported = $false
        MinimumMs = $null
        MaximumMs = $null
        CurrentMs = $null
        NativeStatus = ""
    }

    try {
        Ensure-NativeTimer

        [uint32]$minimum = 0
        [uint32]$maximum = 0
        [uint32]$current = 0
        $status = [GamingStatusNativeTimer]::NtQueryTimerResolution([ref]$minimum, [ref]$maximum, [ref]$current)

        $timer.Supported = ($status -eq 0)
        $timer.MinimumMs = [Math]::Round($minimum / 10000.0, 4)
        $timer.MaximumMs = [Math]::Round($maximum / 10000.0, 4)
        $timer.CurrentMs = [Math]::Round($current / 10000.0, 4)
        $timer.NativeStatus = $status

        if ($timer.CurrentMs -le 1.0) {
            Add-Finding "Timer" "Current timer resolution" "OK" "$($timer.CurrentMs) ms" "<= 1.0 ms for latency-sensitive sessions" "Reported timer resolution is fine; check Sleep/Wait wake tests separately." 1
        }
        elseif ($timer.CurrentMs -le 2.0) {
            Add-Finding "Timer" "Current timer resolution" "WARN" "$($timer.CurrentMs) ms" "<= 1.0 ms for strict low-latency checks" "Playable, but not the typical tuned 0.5-1.0 ms gaming state." 2
        }
        else {
            Add-Finding "Timer" "Current timer resolution" "WARN" "$($timer.CurrentMs) ms" "<= 1.0 ms for strict low-latency checks" "Windows is on a coarse timer interval right now." 2
        }
    }
    catch {
        $timer.NativeStatus = $_.Exception.Message
        Add-Finding "Timer" "Current timer resolution" "UNKNOWN" "not readable" "NtQueryTimerResolution available" $_.Exception.Message 3
    }

    return [pscustomobject]$timer
}

function Set-ProcessTimerResolutionPolicy {
    $policy = [ordered]@{
        Supported = $false
        Applied = $false
        ErrorCode = $null
        IgnoreTimerResolutionDisabled = $false
        Version = 1
        ControlMask = 4
        StateMask = 0
        Note = ""
    }

    try {
        Ensure-NativeTimer

        $state = New-Object GamingStatusProcessPowerThrottlingState
        $state.Version = [GamingStatusNativeTimer]::PROCESS_POWER_THROTTLING_CURRENT_VERSION
        $state.ControlMask = [GamingStatusNativeTimer]::PROCESS_POWER_THROTTLING_IGNORE_TIMER_RESOLUTION
        $state.StateMask = 0

        $size = [Runtime.InteropServices.Marshal]::SizeOf([type][GamingStatusProcessPowerThrottlingState])
        $ok = [GamingStatusNativeTimer]::SetProcessInformation(
            [GamingStatusNativeTimer]::GetCurrentProcess(),
            [GamingStatusNativeTimer]::ProcessPowerThrottling,
            [ref]$state,
            $size
        )

        $policy.Supported = $true
        $policy.Applied = [bool]$ok
        $policy.IgnoreTimerResolutionDisabled = [bool]$ok

        if ($ok) {
            $policy.Note = "Current process explicitly opts out of Windows 11 timer-resolution ignoring."
            Add-Finding "Timer" "Process timer-resolution policy" "OK" "ignore disabled" "Timer requests should be honored in this process" "Cleared PROCESS_POWER_THROTTLING_IGNORE_TIMER_RESOLUTION for this scan process before wake tests." 1
        }
        else {
            $errorCode = [Runtime.InteropServices.Marshal]::GetLastWin32Error()
            $policy.ErrorCode = $errorCode
            $policy.Note = "SetProcessInformation failed with Win32 error $errorCode."
            Add-Finding "Timer" "Process timer-resolution policy" "WARN" "not applied" "Sleep/Wait p95 decides whether this is a real problem" "$($policy.Note) If Sleep/Wait p95 are near 1-2 ms, no immediate fix is needed." 2
        }
    }
    catch {
        $policy.ErrorCode = $_.Exception.Message
        $policy.Note = $_.Exception.Message
        Add-Finding "Timer" "Process timer-resolution policy" "UNKNOWN" "not available" "SetProcessInformation ProcessPowerThrottling support" $_.Exception.Message 3
    }

    return [pscustomobject]$policy
}

function Get-GlobalTimerResolutionRequestStatus {
    $path = "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\kernel"
    $name = "GlobalTimerResolutionRequests"
    $value = Get-RegistryValueSafe $path $name
    $enabled = ($value -eq 1)

    if ($enabled) {
        Add-Finding "Timer" "Legacy global timer mode" "OK" "enabled" "Optional compatibility mode for old apps/tests" "GlobalTimerResolutionRequests=1 is set. Keep it if it fixed old tools/games that slept near 15.6 ms." 3
    }
    elseif ($null -eq $value) {
        Add-Finding "Timer" "Legacy global timer mode" "INFO" "not set" "Usually OK unless old/external apps sleep at 15.6 ms" "This is not a game-performance warning by itself. Enable only if a specific old tool/game needs global timer behavior." 3
    }
    elseif ($value -eq 0) {
        Add-Finding "Timer" "Legacy global timer mode" "INFO" "disabled" "Usually OK unless old/external apps sleep at 15.6 ms" "This is not a game-performance warning by itself. Enable only if a specific old tool/game needs global timer behavior." 3
    }
    else {
        Add-Finding "Timer" "Legacy global timer mode" "INFO" $value "Known value: 1 enabled" "Unexpected GlobalTimerResolutionRequests value." 3
    }

    return [pscustomobject]@{
        Path = $path
        Name = $name
        Value = $value
        Enabled = $enabled
        Note = "Windows 11 legacy/global timer request compatibility switch; reboot after changes."
    }
}

function Test-SleepJitter {
    param(
        [int]$Samples,
        [int]$DelayMs
    )

    $values = New-Object System.Collections.Generic.List[double]
    $timerRequestActive = $false
    $requestedCurrentMs = $null

    try {
        Ensure-NativeTimer
        [uint32]$currentResolution = 0
        $setStatus = [GamingStatusNativeTimer]::NtSetTimerResolution(5000, $true, [ref]$currentResolution)
        $timerRequestActive = ($setStatus -eq 0)
        $requestedCurrentMs = [Math]::Round($currentResolution / 10000.0, 4)
    }
    catch {
    }

    $sw = [Diagnostics.Stopwatch]::StartNew()
    $last = $sw.Elapsed.TotalMilliseconds

    try {
        for ($i = 0; $i -lt $Samples; $i++) {
            [Threading.Thread]::Sleep($DelayMs)
            $now = $sw.Elapsed.TotalMilliseconds
            $values.Add($now - $last) | Out-Null
            $last = $now
        }
    }
    finally {
        if ($timerRequestActive) {
            try {
                [uint32]$unusedResolution = 0
                [GamingStatusNativeTimer]::NtSetTimerResolution(5000, $false, [ref]$unusedResolution) | Out-Null
            }
            catch {
            }
        }
    }

    $array = [double[]]$values.ToArray()
    $avg = ($array | Measure-Object -Average).Average
    $min = ($array | Measure-Object -Minimum).Minimum
    $max = ($array | Measure-Object -Maximum).Maximum
    $p50 = Get-Percentile $array 50
    $p95 = Get-Percentile $array 95
    $p99 = Get-Percentile $array 99

    $result = [pscustomobject]@{
        Samples = $Samples
        RequestedSleepMs = $DelayMs
        Method = "Thread.Sleep(1) with local NtSetTimerResolution request"
        TimerRequestActive = $timerRequestActive
        TimerRequestCurrentMs = $requestedCurrentMs
        CoarseWakeCadence = ([Math]::Round($p50, 4) -ge 10.0)
        MinMs = [Math]::Round($min, 4)
        AvgMs = [Math]::Round($avg, 4)
        P50Ms = [Math]::Round($p50, 4)
        P95Ms = [Math]::Round($p95, 4)
        P99Ms = [Math]::Round($p99, 4)
        MaxMs = [Math]::Round($max, 4)
    }

    if ($result.P95Ms -le 2.5) {
        Add-Finding "Timer" "Thread.Sleep(1) wake p95" "OK" "$($result.P95Ms) ms" "Low and stable for a 1 ms Thread.Sleep wake" "Thread.Sleep wakeups are fine in this process, but real game latency still needs frametime/input measurement." 2
    }
    elseif ($result.P95Ms -le 8.0) {
        Add-Finding "Timer" "Thread.Sleep(1) wake p95" "WARN" "$($result.P95Ms) ms" "Lower is better" "Thread.Sleep wakeups are delayed in this process; this is separate from NtQueryTimerResolution." 2
    }
    else {
        Add-Finding "Timer" "Thread.Sleep(1) wake p95" "WARN" "$($result.P95Ms) ms" "Lower is better" "Thread.Sleep is waking on a coarse/default-tick cadence despite the reported timer resolution; treat Sleep as bad on this system/process." 1
    }

    return $result
}

function Test-HighResolutionWaitableTimer {
    param(
        [int]$Samples,
        [int]$DelayMs
    )

    $values = New-Object System.Collections.Generic.List[double]
    $handle = [IntPtr]::Zero
    $supported = $false
    $fallbackUsed = $false
    $errorCode = 0
    $waitFailures = 0
    $timerRequestActive = $false
    $requestedCurrentMs = $null

    try {
        Ensure-NativeTimer

        try {
            [uint32]$currentResolution = 0
            $setStatus = [GamingStatusNativeTimer]::NtSetTimerResolution(5000, $true, [ref]$currentResolution)
            $timerRequestActive = ($setStatus -eq 0)
            $requestedCurrentMs = [Math]::Round($currentResolution / 10000.0, 4)
        }
        catch {
        }

        $handle = [GamingStatusNativeTimer]::CreateWaitableTimerEx(
            [IntPtr]::Zero,
            $null,
            [GamingStatusNativeTimer]::CREATE_WAITABLE_TIMER_HIGH_RESOLUTION,
            [GamingStatusNativeTimer]::TIMER_ALL_ACCESS
        )
        $supported = ($handle -ne [IntPtr]::Zero)
        if (-not $supported) {
            $errorCode = [Runtime.InteropServices.Marshal]::GetLastWin32Error()
            $handle = [GamingStatusNativeTimer]::CreateWaitableTimerEx(
                [IntPtr]::Zero,
                $null,
                0,
                [GamingStatusNativeTimer]::TIMER_ALL_ACCESS
            )
            $fallbackUsed = ($handle -ne [IntPtr]::Zero)
            if (-not $fallbackUsed) {
                Add-Finding "Timer" "Waitable timer" "UNKNOWN" "not available" "CreateWaitableTimerEx support" "High-res create failed with Win32 error $errorCode; fallback also failed with Win32 error $([Runtime.InteropServices.Marshal]::GetLastWin32Error())." 3
                return [pscustomobject]@{
                    Samples = $Samples
                    RequestedWaitMs = $DelayMs
                    Method = "CreateWaitableTimerEx HIGH_RESOLUTION + local NtSetTimerResolution"
                    Supported = $false
                    HighResolutionRequested = $true
                    FallbackUsed = $false
                    ErrorCode = $errorCode
                    TimerRequestActive = $timerRequestActive
                    TimerRequestCurrentMs = $requestedCurrentMs
                    WaitFailures = $waitFailures
                    MinMs = $null
                    AvgMs = $null
                    P50Ms = $null
                    P95Ms = $null
                    P99Ms = $null
                    MaxMs = $null
                }
            }
        }

        $sw = [Diagnostics.Stopwatch]::StartNew()
        for ($i = 0; $i -lt $Samples; $i++) {
            $dueTime = [long](-1 * $DelayMs * 10000)
            $last = $sw.Elapsed.TotalMilliseconds
            $setOk = [GamingStatusNativeTimer]::SetWaitableTimer($handle, [ref]$dueTime, 0, [IntPtr]::Zero, [IntPtr]::Zero, $false)
            if (-not $setOk) {
                $waitFailures++
                continue
            }
            $waitResult = [GamingStatusNativeTimer]::WaitForSingleObject($handle, 5000)
            $now = $sw.Elapsed.TotalMilliseconds
            if ($waitResult -eq [GamingStatusNativeTimer]::WAIT_OBJECT_0) {
                $values.Add($now - $last) | Out-Null
            }
            else {
                $waitFailures++
            }
        }
    }
    finally {
        if ($handle -ne [IntPtr]::Zero) {
            [GamingStatusNativeTimer]::CloseHandle($handle) | Out-Null
        }
        if ($timerRequestActive) {
            try {
                [uint32]$unusedResolution = 0
                [GamingStatusNativeTimer]::NtSetTimerResolution(5000, $false, [ref]$unusedResolution) | Out-Null
            }
            catch {
            }
        }
    }

    $array = [double[]]$values.ToArray()
    if ($array.Count -eq 0) {
        Add-Finding "Timer" "High-res waitable timer p95" "UNKNOWN" "no samples" "High-res waits should produce samples" "Wait failures: $waitFailures." 3
        return [pscustomobject]@{
            Samples = $Samples
            RequestedWaitMs = $DelayMs
            Method = if ($fallbackUsed) { "CreateWaitableTimerEx fallback + local NtSetTimerResolution" } else { "CreateWaitableTimerEx HIGH_RESOLUTION + local NtSetTimerResolution" }
            Supported = ($supported -or $fallbackUsed)
            HighResolutionRequested = $true
            FallbackUsed = $fallbackUsed
            ErrorCode = $errorCode
            TimerRequestActive = $timerRequestActive
            TimerRequestCurrentMs = $requestedCurrentMs
            WaitFailures = $waitFailures
            MinMs = $null
            AvgMs = $null
            P50Ms = $null
            P95Ms = $null
            P99Ms = $null
            MaxMs = $null
        }
    }

    $avg = ($array | Measure-Object -Average).Average
    $min = ($array | Measure-Object -Minimum).Minimum
    $max = ($array | Measure-Object -Maximum).Maximum
    $p50 = Get-Percentile $array 50
    $p95 = Get-Percentile $array 95
    $p99 = Get-Percentile $array 99

    $result = [pscustomobject]@{
        Samples = $Samples
        RequestedWaitMs = $DelayMs
        Method = if ($fallbackUsed) { "CreateWaitableTimerEx fallback + local NtSetTimerResolution" } else { "CreateWaitableTimerEx HIGH_RESOLUTION + local NtSetTimerResolution" }
        Supported = ($supported -or $fallbackUsed)
        HighResolutionRequested = $true
        FallbackUsed = $fallbackUsed
        ErrorCode = $errorCode
        TimerRequestActive = $timerRequestActive
        TimerRequestCurrentMs = $requestedCurrentMs
        WaitFailures = $waitFailures
        MinMs = [Math]::Round($min, 4)
        AvgMs = [Math]::Round($avg, 4)
        P50Ms = [Math]::Round($p50, 4)
        P95Ms = [Math]::Round($p95, 4)
        P99Ms = [Math]::Round($p99, 4)
        MaxMs = [Math]::Round($max, 4)
    }

    if ($result.P95Ms -le 2.5) {
        $note = if ($fallbackUsed) { "High-res flag failed with Win32 error $errorCode, but normal waitable timers honor the process timer policy and requested resolution." } else { "High-resolution waitable timers are working in this process." }
        Add-Finding "Timer" "Waitable timer p95" "OK" "$($result.P95Ms) ms" "Close to requested 1 ms wait" $note 1
    }
    elseif ($result.P95Ms -le 8.0) {
        $note = if ($fallbackUsed) { "Normal waitable timer fallback has visible scheduling delay; high-res flag failed with Win32 error $errorCode." } else { "High-res waits work but have visible scheduling delay." }
        Add-Finding "Timer" "Waitable timer p95" "WARN" "$($result.P95Ms) ms" "Close to requested 1 ms wait" $note 2
    }
    else {
        $note = if ($fallbackUsed) { "Normal waitable timer fallback also wakes coarse; high-res flag failed with Win32 error $errorCode." } else { "Even high-res waits are waking on a coarse cadence or this process is delayed." }
        Add-Finding "Timer" "Waitable timer p95" "WARN" "$($result.P95Ms) ms" "Close to requested 1 ms wait" $note 1
    }

    return $result
}

function Add-TimerCompositeFindings {
    param([object]$Timer)

    $resolution = $Timer.NtQueryTimerResolution.CurrentMs
    $sleepP95 = $Timer.SleepJitter.P95Ms
    $waitP95 = $Timer.HighResolutionWaitableTimer.P95Ms

    if ($null -ne $resolution -and $resolution -le 1.0 -and $null -ne $waitP95 -and $waitP95 -ge 10.0) {
        Add-Finding "Timer" "Timer resolution vs wake mismatch" "WARN" "$resolution ms reported / $waitP95 ms waitable p95" "Reported timer and actual wake behavior should agree" "The OS reports a fine timer resolution, but waitable timers still wake on a coarse cadence. Treat this as mixed timer state, not a clean low-latency timer state." 1
    }
    elseif ($null -ne $resolution -and $resolution -le 1.0 -and $null -ne $sleepP95 -and $sleepP95 -le 2.5 -and $null -ne $waitP95 -and $waitP95 -le 2.5) {
        Add-Finding "Timer" "Timer wake consistency" "OK" "$resolution ms / sleep $sleepP95 ms / wait $waitP95 ms" "All timer probes close to 1 ms" "Reported timer resolution and wake probes agree in this process." 2
    }
}

function New-AnalysisRow {
    param(
        [string]$Check,
        [string]$Status,
        [object]$Value,
        [string]$Good,
        [string]$Warn,
        [string]$Bad,
        [string]$Meaning
    )

    return [pscustomobject]@{
        Check = $Check
        Status = $Status
        Value = $Value
        Good = $Good
        Warn = $Warn
        Bad = $Bad
        Meaning = $Meaning
    }
}

function New-TimerAnalysis {
    param([object]$Timer)

    $resolution = $Timer.NtQueryTimerResolution.CurrentMs
    $lowestSupported = $Timer.NtQueryTimerResolution.MaximumMs
    $sleep = $Timer.SleepJitter
    $wait = $Timer.HighResolutionWaitableTimer
    $global = $Timer.GlobalTimerResolutionRequests
    $policy = $Timer.ProcessTimerPolicy

    $sleepP50 = $sleep.P50Ms
    $sleepP95 = $sleep.P95Ms
    $waitP95 = $wait.P95Ms
    $jitter = if ($null -ne $sleepP95 -and $null -ne $sleepP50) { [Math]::Round([double]$sleepP95 - [double]$sleepP50, 4) } else { $null }
    $coarse = (
        ($null -ne $sleepP95 -and [double]$sleepP95 -ge 10.0) -or
        ($null -ne $waitP95 -and [double]$waitP95 -ge 10.0)
    )

    $resolutionStatus = if ($null -eq $resolution) { "UNKNOWN" } elseif ([double]$resolution -le 1.0) { "OK" } elseif ([double]$resolution -le 2.0) { "WARN" } else { "FAIL" }
    $absoluteTimerStatus = if ($null -eq $resolution -or $null -eq $lowestSupported) {
        "UNKNOWN"
    }
    elseif ([double]$resolution -le ([double]$lowestSupported + 0.15)) {
        "OK"
    }
    elseif ([double]$resolution -le 1.0) {
        "INFO"
    }
    elseif ([double]$resolution -lt 10.0) {
        "WARN"
    }
    else {
        "FAIL"
    }
    $sleepStatus = if ($null -eq $sleepP95) { "UNKNOWN" } elseif ([double]$sleepP95 -le 2.5) { "OK" } elseif ([double]$sleepP95 -lt 10.0) { "WARN" } else { "FAIL" }
    $waitStatus = if ($null -eq $waitP95) { "UNKNOWN" } elseif ([double]$waitP95 -le 2.5) { "OK" } elseif ([double]$waitP95 -lt 10.0) { "WARN" } else { "FAIL" }
    $globalStatus = if ($global.Enabled -eq $true) { "OK" } else { "WARN" }
    $policyStatus = if ($policy.Applied -eq $true) { "OK" } else { "WARN" }
    $coarseStatus = if ($coarse) { "FAIL" } else { "OK" }
    $jitterStatus = if ($null -eq $jitter) { "UNKNOWN" } elseif ($coarse) { "FAIL" } elseif ($jitter -le 0.25) { "OK" } elseif ($jitter -le 1.0) { "INFO" } elseif ($jitter -le 4.0) { "WARN" } else { "FAIL" }

    $globalMode = if ($global.Enabled -eq $true) { "fixed" } else { "not set / legacy external risk" }
    $externalSleep = if ($global.Enabled -eq $true -and -not $coarse) {
        "fixed / expected fixed for legacy tools"
    }
    elseif ($global.Enabled -eq $true -and $coarse) {
        "global mode set, but this process still wakes coarse"
    }
    else {
        "not fixed for old external tools"
    }
    $remainingJitter = if ($coarse) {
        "bad / 15 ms coarse cadence"
    }
    elseif ($null -ne $jitter -and $jitter -le 0.25) {
        "normal / very good"
    }
    elseif ($null -ne $jitter -and $jitter -le 1.0) {
        "normal"
    }
    elseif ($null -ne $jitter) {
        "watch / background scheduling noise"
    }
    else {
        "unknown"
    }
    $competitiveTarget = if ($absoluteTimerStatus -eq "OK" -and $sleepStatus -eq "OK" -and $waitStatus -eq "OK") {
        "at absolute practical minimum"
    }
    elseif ($absoluteTimerStatus -eq "OK") {
        "timer resolution at minimum; wake probes need review"
    }
    elseif ($coarse) {
        "not fixed / coarse wake path"
    }
    else {
        "not at lowest supported timer resolution"
    }
    $competitiveSteps = if ($competitiveTarget -eq "at absolute practical minimum") {
        "Done: current resolution is at the supported minimum and Sleep/Wait are clean."
    }
    else {
        "Use Solver: FIX PROC POLICY, HOLD 0.5MS, RUN RETEST. If external tools still sleep near 15.6 ms, APPLY GLOBAL MODE and reboot."
    }

    $overall = if ($coarse) {
        "bad timer wake path"
    }
    elseif ($sleepStatus -eq "OK" -and $waitStatus -eq "OK" -and $resolutionStatus -eq "OK") {
        "clean high-res timer"
    }
    else {
        "mixed timer state"
    }

    $matrix = @(
        New-AnalysisRow "Reported timer resolution" $resolutionStatus "$resolution ms" "<= 1.0 ms" "1.0-2.0 ms" "> 2.0 ms" "Reported OS timer interval. This alone does not prove Sleep(1) wakes fast."
        New-AnalysisRow "Competitive minimum target" $absoluteTimerStatus "$resolution ms current / $lowestSupported ms lowest supported" "current within ~0.15 ms of lowest supported" "current <= 1.0 ms but not at lowest supported" "> 1.0 ms or coarse wake behavior" "Absolute timer target is the lowest supported NtQueryTimerResolution value. On many gaming PCs this is about 0.5 ms; 0.511 ms is effectively the minimum."
        New-AnalysisRow "Thread.Sleep(1) wake p95" $sleepStatus "$sleepP95 ms" "<= 2.5 ms" "2.5-10 ms" ">= 10 ms, especially ~15.6 ms" "Actual Sleep(1) wake behavior in this process. Around 15.6 ms means default/coarse clock and is not good for latency checks."
        New-AnalysisRow "Waitable timer p95" $waitStatus "$waitP95 ms" "<= 2.5 ms" "2.5-10 ms" ">= 10 ms, especially ~15.6 ms" "Actual waitable timer wake behavior. This catches paths that ignore the reported timer resolution."
        New-AnalysisRow "Global timer mode" $globalStatus $(if ($global.Enabled) { "fixed" } else { "not set" }) "GlobalTimerResolutionRequests=1" "not set if every app requests timers itself" "not set while old external tools sleep at ~15.6 ms" "Compatibility mode for older tools/games that rely on another process keeping 0.5 ms globally active."
        New-AnalysisRow "Process timer policy" $policyStatus $(if ($policy.Applied) { "ignore disabled" } else { "not applied" }) "IGNORE_TIMER_RESOLUTION cleared" "unknown" "policy blocks timer requests" "Windows 11 can let a process ignore timer-resolution requests unless this policy is cleared."
        New-AnalysisRow "15.6 ms coarse cadence" $coarseStatus $(if ($coarse) { "detected" } else { "not detected" }) "not detected" "occasional isolated spikes only" "detected in p95" "If p95 is near 15.6 ms, the process is effectively on the default scheduler tick."
        New-AnalysisRow "Remaining Sleep jitter" $jitterStatus $(if ($null -ne $jitter) { "$jitter ms p95-p50" } else { "unknown" }) "<= 0.25 ms" "0.25-4.0 ms, depending on load/sample count" "> 4.0 ms or coarse cadence" "Small spread after the 15 ms problem is fixed is normal Windows scheduling noise."
    )

    $findingStatus = if ($overall -eq "clean high-res timer") { "OK" } elseif ($coarse) { "FAIL" } else { "WARN" }
    $competitiveFindingStatus = if ($competitiveTarget -eq "at absolute practical minimum") { "OK" } elseif ($coarse) { "WARN" } else { "INFO" }
    Add-Finding "Timer" "Competitive timer target" $competitiveFindingStatus $competitiveTarget "Current timer resolution at lowest supported value and Sleep/Wait wake probes clean" "$competitiveSteps Lowest supported on this PC: $lowestSupported ms; current: $resolution ms." 2
    Add-Finding "Timer" "Timer analysis verdict" $findingStatus $overall "No 15.6 ms wake cadence for gaming latency checks" "Global timer mode: $globalMode; External Sleep tester: $externalSleep; Remaining jitter: $remainingJitter." 1

    return [pscustomobject]@{
        Summary = [pscustomobject]@{
            Overall = $overall
            CompetitiveTimerTarget = $competitiveTarget
            CompetitiveTimerSteps = $competitiveSteps
            LowestSupportedResolutionMs = $lowestSupported
            CurrentResolutionMs = $resolution
            GlobalTimerMode = $globalMode
            ExternalSleepTester = $externalSleep
            RemainingJitter = $remainingJitter
            SleepJitterP95MinusP50Ms = $jitter
        }
        Matrix = $matrix
    }
}

function Get-DecisionRank {
    param([string]$Decision)

    switch ($Decision) {
        "MUST FIX" { return 1 }
        "SHOULD FIX" { return 2 }
        "CHECK" { return 3 }
        "REVIEW" { return 4 }
        "OPTIONAL" { return 5 }
        "KEEP" { return 6 }
        default { return 7 }
    }
}

function Get-ActionGuideLegend {
    return @(
        [pscustomobject]@{
            Decision = "MUST FIX"
            Meaning = "Hard blocker for reliable benchmark results"
            UserMove = "Change this before benchmarking"
        }
        [pscustomobject]@{
            Decision = "SHOULD FIX"
            Meaning = "Likely to distort latency/FPS comparisons"
            UserMove = "Fix before trusting results"
        }
        [pscustomobject]@{
            Decision = "REVIEW"
            Meaning = "Suspicious or context-dependent"
            UserMove = "Retest idle or verify manually before changing"
        }
        [pscustomobject]@{
            Decision = "OPTIONAL"
            Meaning = "Not automatically good or bad"
            UserMove = "Only change for A/B tests or your own goal"
        }
        [pscustomobject]@{
            Decision = "KEEP"
            Meaning = "Good or expected state"
            UserMove = "Leave it as-is"
        }
        [pscustomobject]@{
            Decision = "CHECK"
            Meaning = "The tool could not verify this"
            UserMove = "Check manually before relying on it"
        }
    )
}

function New-ActionGuide {
    param(
        [object]$Findings
    )

    $rowList = New-Object System.Collections.Generic.List[object]
    foreach ($finding in $Findings) {
        if ($null -eq $finding) { continue }
        $rowList.Add([pscustomobject]@{
            Rank = Get-DecisionRank $finding.Decision
            Decision = $finding.Decision
            Area = $finding.Area
            Check = $finding.Name
            Value = $finding.Value
            Why = if ($finding.Note) { $finding.Note } else { $finding.Expected }
            Action = $finding.Action
            Status = $finding.Status
            Priority = $finding.Priority
        }) | Out-Null
    }

    $sortedRows = @($rowList.ToArray() | Sort-Object Rank, Priority, Area, Check)
    $rows = @($sortedRows | ForEach-Object {
        [pscustomobject]@{
            Decision = $_.Decision
            Area = $_.Area
            Check = $_.Check
            Value = $_.Value
            Why = $_.Why
            Action = $_.Action
            Status = $_.Status
            Priority = $_.Priority
        }
    })

    $must = @($rows | Where-Object { $_.Decision -eq "MUST FIX" }).Count
    $should = @($rows | Where-Object { $_.Decision -eq "SHOULD FIX" }).Count
    $check = @($rows | Where-Object { $_.Decision -eq "CHECK" }).Count
    $review = @($rows | Where-Object { $_.Decision -eq "REVIEW" }).Count
    $optional = @($rows | Where-Object { $_.Decision -eq "OPTIONAL" }).Count
    $keep = @($rows | Where-Object { $_.Decision -eq "KEEP" }).Count

    $verdict = if ($must -gt 0) {
        "MUST FIX before benchmarking"
    }
    elseif ($should -gt 0) {
        "SHOULD FIX before trusting benchmark results"
    }
    elseif ($check -gt 0 -or $review -gt 0) {
        "REVIEW a few items; no hard blocker detected"
    }
    else {
        "GOOD baseline; optional A/B tests only"
    }

    $topActions = @($rows | Where-Object { @("MUST FIX", "SHOULD FIX", "CHECK", "REVIEW") -contains $_.Decision } | Select-Object -First 10)
    if ($topActions.Count -eq 0) {
        $topActions = @([pscustomobject]@{
            Decision = "KEEP"
            Area = "Summary"
            Check = "No required actions"
            Value = $verdict
            Why = "No MUST FIX, SHOULD FIX, CHECK or REVIEW items were detected."
            Action = "Keep this baseline; only run optional A/B tests if you want to compare settings."
            Status = "OK"
            Priority = 3
        })
    }

    return [pscustomobject]@{
        Summary = [pscustomobject]@{
            Verdict = $verdict
            MustFix = $must
            ShouldFix = $should
            Check = $check
            Review = $review
            Optional = $optional
            Keep = $keep
        }
        TopActions = $topActions
        Matrix = $rows
        Legend = Get-ActionGuideLegend
    }
}

function New-FixGuide {
    param(
        [object]$Findings
    )

    $rowList = New-Object System.Collections.Generic.List[object]
    foreach ($finding in $Findings) {
        if ($null -eq $finding) { continue }
        if (-not $finding.FixAvailable -and $finding.Decision -eq "KEEP") { continue }

        $rowList.Add([pscustomobject]@{
            Rank = Get-DecisionRank $finding.Decision
            Decision = $finding.Decision
            Area = $finding.Area
            Check = $finding.Name
            Value = $finding.Value
            FixSummary = $finding.FixSummary
            Steps = @($finding.FixSteps) -join " | "
            Commands = @($finding.FixCommands) -join " | "
            SolverAction = $finding.SolverAction
            RequiresAdmin = $finding.RequiresAdmin
            RequiresReboot = $finding.RequiresReboot
            Risk = $finding.Risk
            Priority = $finding.Priority
        }) | Out-Null
    }

    $sortedRows = @($rowList.ToArray() | Sort-Object Rank, Priority, Area, Check)
    $rows = @($sortedRows | ForEach-Object {
        [pscustomobject]@{
            Decision = $_.Decision
            Area = $_.Area
            Check = $_.Check
            Value = $_.Value
            FixSummary = $_.FixSummary
            Steps = $_.Steps
            Commands = $_.Commands
            SolverAction = $_.SolverAction
            RequiresAdmin = $_.RequiresAdmin
            RequiresReboot = $_.RequiresReboot
            Risk = $_.Risk
            Priority = $_.Priority
        }
    })

    $must = @($rows | Where-Object { $_.Decision -eq "MUST FIX" }).Count
    $should = @($rows | Where-Object { $_.Decision -eq "SHOULD FIX" }).Count
    $review = @($rows | Where-Object { $_.Decision -in @("CHECK", "REVIEW") }).Count
    $optional = @($rows | Where-Object { $_.Decision -eq "OPTIONAL" }).Count
    $withCommands = @($rows | Where-Object { $_.Commands -and $_.Decision -ne "KEEP" }).Count

    $topFixes = @($rows | Where-Object { @("MUST FIX", "SHOULD FIX", "CHECK", "REVIEW") -contains $_.Decision } | Select-Object -First 12)
    if ($topFixes.Count -eq 0) {
        $topFixes = @([pscustomobject]@{
            Decision = "KEEP"
            Area = "Summary"
            Check = "No required fixes"
            Value = "baseline clean"
            FixSummary = "No required fixes were detected. Only optional A/B tests remain."
            Steps = "Keep this baseline; change one optional setting at a time only if you want proof."
            Commands = ""
            SolverAction = ""
            RequiresAdmin = $false
            RequiresReboot = $false
            Risk = "low"
            Priority = 3
        })
    }

    return [pscustomobject]@{
        Summary = [pscustomobject]@{
            RequiredFixes = $must + $should
            MustFix = $must
            ShouldFix = $should
            ReviewOrCheck = $review
            Optional = $optional
            CommandBackedFixes = $withCommands
            Rule = "Apply one fix at a time, reboot when marked, then retest before stacking more changes."
        }
        TopFixes = $topFixes
        Matrix = $rows
    }
}

function Get-BcdeditStatus {
    $text = Invoke-TextCommand "bcdedit.exe" @("/enum", "{current}")
    $script:Raw["bcdedit_current"] = $text

    $items = [ordered]@{}
    foreach ($line in ($text -split "`r?`n")) {
        if ($line -match "^\s*([a-zA-Z0-9_]+)\s+(.+?)\s*$") {
            $items[$matches[1].ToLowerInvariant()] = $matches[2].Trim()
        }
    }

    $dyn = $items["disabledynamictick"]
    if ($dyn -match "Yes|Ja|true|1") {
        Add-Finding "Kernel" "Dynamic tick" "OK" "disabled" "Often disabled for repeatable low-latency tests" "BCDEdit disabledynamictick is set." 2
    }
    elseif ($null -eq $dyn -or $dyn -eq "") {
        Add-Finding "Kernel" "Dynamic tick" "INFO" "default/not set" "Default is fine unless you compare tuned profiles" "No disabledynamictick override found." 3
    }
    else {
        Add-Finding "Kernel" "Dynamic tick" "INFO" $dyn "Depends on your tuning profile" "BCDEdit disabledynamictick is explicitly set." 3
    }

    $platformClock = $items["useplatformclock"]
    if ($platformClock -match "Yes|Ja|true|1") {
        Add-Finding "Kernel" "Forced platform clock / HPET" "WARN" "enabled" "Usually do not force HPET for modern gaming PCs" "Forced HPET can add overhead on many systems; benchmark before keeping it." 1
    }
    elseif ($platformClock -match "No|Nein|false|0") {
        Add-Finding "Kernel" "Forced platform clock / HPET" "OK" "not forced" "Do not force unless you have measured a win" "useplatformclock is explicitly set to No." 2
    }
    elseif ($null -eq $platformClock -or $platformClock -eq "") {
        Add-Finding "Kernel" "Forced platform clock / HPET" "OK" "not forced" "Do not force unless you have measured a win" "No useplatformclock override found." 2
    }
    else {
        Add-Finding "Kernel" "Forced platform clock / HPET" "INFO" $platformClock "Measure per PC" "useplatformclock is explicitly configured." 3
    }

    $platformTick = $items["useplatformtick"]
    if ($platformTick -match "Yes|Ja|true|1") {
        Add-Finding "Kernel" "Platform tick" "WARN" "enabled" "Usually do not force platform tick for modern gaming PCs" "Platform tick is explicitly forced; delete it unless you measured a win." 1
    }
    elseif ($platformTick -match "No|Nein|false|0") {
        Add-Finding "Kernel" "Platform tick" "OK" "not forced" "Do not force unless you have measured a win" "useplatformtick is explicitly set to No." 2
    }

    return [pscustomobject]@{
        Parsed = $items
        Raw = $text
    }
}

function Get-PowerStatus {
    $active = Invoke-TextCommand "powercfg.exe" @("/GETACTIVESCHEME")
    $script:Raw["powercfg_active_scheme"] = $active

    $schemeName = $active
    if ($active -match "\((.+)\)") {
        $schemeName = $matches[1]
    }

    if ($schemeName -match "High performance|Ultimate Performance|Hoechstleistung|Ultimative Leistung|Hohe Leistung") {
        Add-Finding "Power" "Active power plan" "OK" $schemeName "High/Ultimate performance for benchmarks" "Good baseline for repeatable gaming tests." 1
    }
    else {
        Add-Finding "Power" "Active power plan" "INFO" $schemeName "High/Ultimate performance when benchmarking" "Balanced can be fine, but compare against a performance plan." 2
    }

    $processorMin = Invoke-TextCommand "powercfg.exe" @("/query", "SCHEME_CURRENT", "SUB_PROCESSOR", "PROCTHROTTLEMIN")
    $processorMax = Invoke-TextCommand "powercfg.exe" @("/query", "SCHEME_CURRENT", "SUB_PROCESSOR", "PROCTHROTTLEMAX")
    $powerQueryHidden = Invoke-TextCommand "powercfg.exe" @("/qh", "SCHEME_CURRENT")
    $script:Raw["powercfg_processor_min"] = $processorMin
    $script:Raw["powercfg_processor_max"] = $processorMax
    $script:Raw["powercfg_query_hidden_current"] = $powerQueryHidden

    $visibility = Get-PowerSettingVisibilityStatus

    return [pscustomobject]@{
        ActiveScheme = $active
        ProcessorMinRaw = $processorMin
        ProcessorMaxRaw = $processorMax
        HiddenSettings = $visibility
        ShowAllCommand = "powercfg /qh SCHEME_CURRENT"
    }
}

function Get-PowerSettingVisibilityStatus {
    $base = "HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings"
    $rows = @()

    try {
        foreach ($subgroup in @(Get-ChildItem -Path $base -ErrorAction Stop)) {
            foreach ($setting in @(Get-ChildItem -Path $subgroup.PSPath -ErrorAction SilentlyContinue)) {
                $props = Get-ItemProperty -Path $setting.PSPath -ErrorAction SilentlyContinue
                if ($null -eq $props -or $null -eq $props.PSObject.Properties["Attributes"]) { continue }

                $attributes = [int]$props.PSObject.Properties["Attributes"].Value
                $hidden = (($attributes -band 1) -ne 0)
                $friendlyProp = $props.PSObject.Properties["FriendlyName"]
                $friendly = if ($friendlyProp) { [string]$friendlyProp.Value } else { "" }
                if (-not $friendly) { $friendly = $setting.PSChildName }

                $rows += [pscustomobject]@{
                    SubgroupGuid = $subgroup.PSChildName
                    SettingGuid = $setting.PSChildName
                    FriendlyName = $friendly
                    Attributes = $attributes
                    Hidden = $hidden
                    RegistryPath = $setting.PSPath -replace "^Microsoft\.PowerShell\.Core\\Registry::", ""
                }
            }
        }

        $hiddenRows = @($rows | Where-Object { $_.Hidden })
        if ($hiddenRows.Count -eq 0) {
            Add-Finding "Power" "Hidden power settings" "OK" "0 hidden / $($rows.Count) total" "Visible/unlocked advanced power settings" "All discovered power settings are already visible or do not use the hidden attribute." 3
        }
        else {
            Add-Finding "Power" "Hidden power settings" "INFO" "$($hiddenRows.Count) hidden / $($rows.Count) total" "Optional unlocker can expose hidden Advanced Power Settings" "This only controls UI visibility. It does not change active power values." 3
        }

        return [pscustomobject]@{
            TotalCount = $rows.Count
            HiddenCount = $hiddenRows.Count
            VisibleCount = $rows.Count - $hiddenRows.Count
            HiddenPreview = @($hiddenRows | Select-Object -First 40)
            Note = "Attributes with bit 1 set are treated as hidden. POWER UNHIDE ALL sets Attributes=2 for discovered settings."
        }
    }
    catch {
        Add-Finding "Power" "Hidden power settings" "UNKNOWN" "not readable" "PowerSettings registry readable" $_.Exception.Message 3
        return [pscustomobject]@{
            TotalCount = 0
            HiddenCount = $null
            VisibleCount = $null
            HiddenPreview = @()
            Note = $_.Exception.Message
        }
    }
}

function Get-DisplayAndGpuStatus {
    $video = @()
    try {
        $video = @(Get-CimInstance -ClassName Win32_VideoController -ErrorAction Stop | Select-Object Name, VideoProcessor, DriverVersion, DriverDate, CurrentHorizontalResolution, CurrentVerticalResolution, CurrentRefreshRate, AdapterRAM, Status)
    }
    catch {
        Add-Finding "Display/GPU" "Win32_VideoController" "UNKNOWN" "not readable" "WMI available" $_.Exception.Message 3
    }

    foreach ($gpu in $video) {
        $res = "$($gpu.CurrentHorizontalResolution)x$($gpu.CurrentVerticalResolution)@$($gpu.CurrentRefreshRate)Hz"
        Add-Finding "Display/GPU" "Active display mode - $($gpu.Name)" "INFO" $res "Match monitor native/high refresh mode" "WMI value; verify in Windows Advanced display for exact VRR/HDR state." 3
    }

    $nvidiaSmi = Get-Command "nvidia-smi.exe" -ErrorAction SilentlyContinue
    $nvidia = @()
    if ($nvidiaSmi) {
        $queryArgs = @(
            "--query-gpu=name,driver_version,pstate,temperature.gpu,utilization.gpu,clocks.gr,clocks.mem,power.draw,power.limit",
            "--format=csv,noheader,nounits"
        )
        $raw = Invoke-TextCommand $nvidiaSmi.Source $queryArgs
        $script:Raw["nvidia_smi"] = $raw
        foreach ($line in ($raw -split "`r?`n")) {
            if ($line.Trim() -eq "" -or $line -match "^ERROR") { continue }
            $parts = @($line -split "\s*,\s*")
            if ($parts.Count -ge 9) {
                $nvidia += [pscustomobject]@{
                    Name = $parts[0]
                    Driver = $parts[1]
                    PState = $parts[2]
                    TemperatureC = $parts[3]
                    UtilizationPct = $parts[4]
                    GraphicsClockMHz = $parts[5]
                    MemoryClockMHz = $parts[6]
                    PowerDrawW = $parts[7]
                    PowerLimitW = $parts[8]
                }
            }
        }
    }
    else {
        Add-Finding "Display/GPU" "nvidia-smi" "INFO" "not found" "Optional for NVIDIA telemetry" "WMI GPU data is still collected." 3
    }

    $graphicsDriversPath = "HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers"
    $hags = Get-RegistryValueSafe $graphicsDriversPath "HwSchMode"
    switch ($hags) {
        2 { Add-Finding "Display/GPU" "Hardware accelerated GPU scheduling" "INFO" "enabled" "Benchmark both states on your main games" "HAGS can help or hurt depending on driver/game." 3 }
        1 { Add-Finding "Display/GPU" "Hardware accelerated GPU scheduling" "INFO" "disabled" "Benchmark both states on your main games" "Registry explicitly disables HAGS." 3 }
        $null { Add-Finding "Display/GPU" "Hardware accelerated GPU scheduling" "INFO" "default/not set" "Default is OK" "No HwSchMode override found." 3 }
        default { Add-Finding "Display/GPU" "Hardware accelerated GPU scheduling" "INFO" $hags "Known values: 1 disabled, 2 enabled" "Unexpected HwSchMode value." 3 }
    }

    $mpoPaths = @(
        "HKLM:\SOFTWARE\Microsoft\Windows\Dwm",
        $graphicsDriversPath
    )
    $mpoValues = @()
    foreach ($path in $mpoPaths) {
        $value = Get-RegistryValueSafe $path "OverlayTestMode"
        if ($null -ne $value) {
            $mpoValues += [pscustomobject]@{
                Path = $path
                OverlayTestMode = $value
            }
        }
    }

    $mpoDisabled = @($mpoValues | Where-Object { $_.OverlayTestMode -eq 5 })
    if ($mpoDisabled.Count -gt 0) {
        Add-Finding "Display/GPU" "Multiplane Overlay (MPO)" "INFO" "disabled via OverlayTestMode=5" "Keep only if it fixes flicker/stutter" "MPO disable override found at $($mpoDisabled[0].Path)." 3
    }
    elseif ($mpoValues.Count -eq 0) {
        Add-Finding "Display/GPU" "Multiplane Overlay (MPO)" "INFO" "default/enabled" "Default unless troubleshooting" "No MPO disable override found." 3
    }
    else {
        $mpoText = (($mpoValues | ForEach-Object { "$($_.OverlayTestMode) at $($_.Path)" }) -join "; ")
        Add-Finding "Display/GPU" "Multiplane Overlay (MPO)" "INFO" $mpoText "Known disable value: 5" "OverlayTestMode exists, but it is not the known disable value." 3
    }

    return [pscustomobject]@{
        VideoControllers = $video
        NvidiaSmi = $nvidia
        HagsHwSchMode = $hags
        MpoOverlayTestMode = $mpoValues
    }
}

function Get-GameModeAndFsoStatus {
    $gameConfigPath = "HKCU:\System\GameConfigStore"
    $gameBarPath = "HKCU:\Software\Microsoft\GameBar"
    $gameDvrPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR"

    $values = [ordered]@{
        GameDVR_Enabled = Get-RegistryValueSafe $gameConfigPath "GameDVR_Enabled"
        GameDVR_FSEBehavior = Get-RegistryValueSafe $gameConfigPath "GameDVR_FSEBehavior"
        GameDVR_FSEBehaviorMode = Get-RegistryValueSafe $gameConfigPath "GameDVR_FSEBehaviorMode"
        GameDVR_HonorUserFSEBehaviorMode = Get-RegistryValueSafe $gameConfigPath "GameDVR_HonorUserFSEBehaviorMode"
        GameDVR_DXGIHonorFSEWindowsCompatible = Get-RegistryValueSafe $gameConfigPath "GameDVR_DXGIHonorFSEWindowsCompatible"
        AppCaptureEnabled = Get-RegistryValueSafe $gameDvrPath "AppCaptureEnabled"
        HistoricalCaptureEnabled = Get-RegistryValueSafe $gameDvrPath "HistoricalCaptureEnabled"
        HistoricalCaptureLength = Get-RegistryValueSafe $gameDvrPath "HistoricalCaptureLength"
        AutoGameModeEnabled = Get-RegistryValueSafe $gameBarPath "AutoGameModeEnabled"
        AllowAutoGameMode = Get-RegistryValueSafe $gameBarPath "AllowAutoGameMode"
        UseNexusForGameBarEnabled = Get-RegistryValueSafe $gameBarPath "UseNexusForGameBarEnabled"
    }

    if ($values.AutoGameModeEnabled -eq 1 -or $values.AllowAutoGameMode -eq 1) {
        Add-Finding "Fullscreen/Game" "Windows Game Mode" "OK" "enabled" "Usually enabled for gaming" "Game Mode registry indicates enabled." 2
    }
    elseif ($null -eq $values.AutoGameModeEnabled -and $null -eq $values.AllowAutoGameMode) {
        Add-Finding "Fullscreen/Game" "Windows Game Mode" "INFO" "default/not set" "Usually enabled for gaming" "No explicit Game Mode values found." 3
    }
    else {
        Add-Finding "Fullscreen/Game" "Windows Game Mode" "INFO" "disabled or custom" "Usually enabled for gaming" "Compare both states if you have stutter." 2
    }

    if ($values.AppCaptureEnabled -eq 0 -or $values.GameDVR_Enabled -eq 0) {
        Add-Finding "Fullscreen/Game" "GameDVR capture" "OK" "disabled" "Disable captures if you do not use them" "Background capture path appears off." 2
    }
    elseif ($values.AppCaptureEnabled -eq 1 -or $values.GameDVR_Enabled -eq 1) {
        Add-Finding "Fullscreen/Game" "GameDVR capture" "INFO" "enabled" "Disable if you want a lean benchmark state" "Capture features can add overhead when active." 2
    }
    else {
        Add-Finding "Fullscreen/Game" "GameDVR capture" "INFO" "default/not set" "Disable if you want a lean benchmark state" "No explicit capture override found." 3
    }

    if ($values.HistoricalCaptureEnabled -eq 0) {
        Add-Finding "Fullscreen/Game" "GameDVR background recording" "OK" "disabled" "Disable Record what happened for clean benchmarks" "Windows background recording is off." 2
    }
    elseif ($values.HistoricalCaptureEnabled -eq 1) {
        $lengthNote = if ($values.HistoricalCaptureLength) { "Configured buffer length: $($values.HistoricalCaptureLength) seconds." } else { "Background recording buffer is enabled." }
        Add-Finding "Fullscreen/Game" "GameDVR background recording" "WARN" "enabled" "Disable Record what happened for clean benchmarks" "Windows may continuously record a gameplay buffer. $lengthNote" 1
    }
    else {
        Add-Finding "Fullscreen/Game" "GameDVR background recording" "INFO" "default/not set" "Disable Record what happened for clean benchmarks" "No explicit background recording value found." 3
    }

    $fsoMode = $values.GameDVR_FSEBehaviorMode
    if ($fsoMode -eq 2) {
        Add-Finding "Fullscreen/Game" "Global FSO/FSE behavior" "INFO" "FSE preference override visible" "Use per-game flags for exact control" "GameDVR_FSEBehaviorMode=2 is commonly used in FSO-disable tuning profiles." 2
    }
    elseif ($null -eq $fsoMode) {
        Add-Finding "Fullscreen/Game" "Global FSO/FSE behavior" "INFO" "default/not set" "Default is OK; tune per game" "Windows Fullscreen Optimizations usually remain enabled unless per-app disabled." 3
    }
    else {
        Add-Finding "Fullscreen/Game" "Global FSO/FSE behavior" "INFO" $fsoMode "Known tuned value often: 2" "Interpret together with per-game AppCompat flags." 3
    }

    $gameExe = @(Get-GameExeCompatibilityStatus -Paths $GameExePath)
    $windows = @(Get-RunningWindowStatus -KnownGamePaths $GameExePath)

    return [pscustomobject]@{
        Registry = [pscustomobject]$values
        GameExeCompatibility = $gameExe
        RunningWindows = $windows
        Note = "Windows does not expose a perfect external FSE-vs-FSO truth flag. This tool reports policy, per-exe compatibility flags, and window geometry."
    }
}

function Get-AppCompatLayers {
    $paths = @(
        "HKCU:\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers",
        "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers"
    )

    $rows = @()
    foreach ($path in $paths) {
        try {
            $item = Get-ItemProperty -Path $path -ErrorAction Stop
            foreach ($prop in $item.PSObject.Properties) {
                if ($prop.Name -like "PS*") { continue }
                $rows += [pscustomobject]@{
                    Hive = if ($path -like "HKCU:*") { "HKCU" } else { "HKLM" }
                    ExePath = $prop.Name
                    Flags = [string]$prop.Value
                    FsoDisabled = ([string]$prop.Value -match "DISABLEDXMAXIMIZEDWINDOWEDMODE")
                    RunAsAdmin = ([string]$prop.Value -match "RUNASADMIN")
                    DisableDpiScaling = ([string]$prop.Value -match "HIGHDPIAWARE|DPIUNAWARE")
                }
            }
        }
        catch {
        }
    }

    return $rows
}

function Get-GameExeCompatibilityStatus {
    param([string[]]$Paths)

    $layers = @(Get-AppCompatLayers)
    $result = @()

    if ($Paths.Count -eq 0) {
        $interesting = @($layers | Where-Object { $_.FsoDisabled -or $_.ExePath -match "\\(cs2|valorant|r5apex|FortniteClient|cod|bf|Overwatch|League of Legends|RocketLeague|EscapeFromTarkov|RainbowSix|osu!)" } | Select-Object -First 40)
        foreach ($row in $interesting) {
            $result += $row
            if ($row.FsoDisabled) {
                Add-Finding "Fullscreen/Game" "Per-game FSO disabled" "INFO" $row.ExePath "Per-game, only where measured useful" "AppCompat flag DISABLEDXMAXIMIZEDWINDOWEDMODE is set." 2
            }
        }

        if ($interesting.Count -eq 0) {
            Add-Finding "Fullscreen/Game" "Per-game FSO flags" "INFO" "none found" "Pass -GameExePath for exact game checks" "No obvious AppCompat game flags found." 3
        }

        return $result
    }

    foreach ($path in $Paths) {
        if ($path -notmatch "\.exe$" -and -not (Test-Path -LiteralPath $path -PathType Leaf)) {
            Add-Finding "Fullscreen/Game" "Ignored game exe input" "WARN" $path "Pass a .exe file path" "This value is not a Windows executable path, so it was not used for FSO/AppCompat checks." 2
            continue
        }

        $resolved = $path
        try {
            $resolved = (Resolve-Path -Path $path -ErrorAction Stop).Path
        }
        catch {
        }

        $match = @($layers | Where-Object { $_.ExePath -ieq $resolved -or $_.ExePath -ieq $path } | Select-Object -First 1)
        if ($match.Count -gt 0) {
            $result += $match[0]
            if ($match[0].FsoDisabled) {
                Add-Finding "Fullscreen/Game" "FSO flag for $([IO.Path]::GetFileName($path))" "INFO" "disabled" "Only disable if this game benefits" "Per-exe flag DISABLEDXMAXIMIZEDWINDOWEDMODE is set." 1
            }
            else {
                Add-Finding "Fullscreen/Game" "FSO flag for $([IO.Path]::GetFileName($path))" "INFO" "no disable flag" "Default FSO path" "Compatibility layer exists but does not disable FSO." 2
            }
        }
        else {
            $row = [pscustomobject]@{
                Hive = ""
                ExePath = $resolved
                Flags = ""
                FsoDisabled = $false
                RunAsAdmin = $false
                DisableDpiScaling = $false
            }
            $result += $row
            Add-Finding "Fullscreen/Game" "FSO flag for $([IO.Path]::GetFileName($path))" "INFO" "default/no per-exe flag" "Default FSO path" "No AppCompat layer found for this exe." 2
        }
    }

    return $result
}

function Ensure-WindowApi {
    try {
        if (-not ("GamingStatusWindowApi" -as [type])) {
            Add-Type -ReferencedAssemblies System.Windows.Forms -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

public static class GamingStatusWindowApi
{
    public const int GWL_STYLE = -16;
    public const long WS_CAPTION = 0x00C00000L;
    public const long WS_THICKFRAME = 0x00040000L;

    [StructLayout(LayoutKind.Sequential)]
    public struct RECT
    {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }

    [DllImport("user32.dll")]
    public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

    [DllImport("user32.dll", EntryPoint="GetWindowLong")]
    public static extern int GetWindowLong32(IntPtr hWnd, int nIndex);

    [DllImport("user32.dll", EntryPoint="GetWindowLongPtr")]
    public static extern IntPtr GetWindowLongPtr64(IntPtr hWnd, int nIndex);

    public static IntPtr GetWindowLongPtr(IntPtr hWnd, int nIndex)
    {
        if (IntPtr.Size == 8)
        {
            return GetWindowLongPtr64(hWnd, nIndex);
        }
        return new IntPtr(GetWindowLong32(hWnd, nIndex));
    }
}
"@ -ErrorAction Stop
        }

        return $true
    }
    catch {
        Add-Finding "Fullscreen/Game" "Window geometry probe" "UNKNOWN" "not available" "Interactive desktop/session" $_.Exception.Message 3
        return $false
    }
}

function Get-RunningWindowStatus {
    param([string[]]$KnownGamePaths)

    if (-not (Ensure-WindowApi)) {
        return @()
    }

    $screens = @()
    try {
        $screens = @([System.Windows.Forms.Screen]::AllScreens)
    }
    catch {
        return @()
    }

    $knownNames = @()
    foreach ($path in $KnownGamePaths) {
        try {
            $knownNames += [IO.Path]::GetFileNameWithoutExtension($path)
        }
        catch {
        }
    }

    if ($knownNames.Count -eq 0) {
        return @()
    }

    $processes = @(Get-Process -ErrorAction SilentlyContinue | Where-Object {
        $_.MainWindowHandle -ne 0 -and (
            $knownNames -contains $_.ProcessName
        )
    } | Sort-Object ProcessName | Select-Object -First 60)

    $rows = @()
    foreach ($process in $processes) {
        $rect = New-Object GamingStatusWindowApi+RECT
        $ok = [GamingStatusWindowApi]::GetWindowRect($process.MainWindowHandle, [ref]$rect)
        if (-not $ok) { continue }

        $width = $rect.Right - $rect.Left
        $height = $rect.Bottom - $rect.Top
        $stylePtr = [GamingStatusWindowApi]::GetWindowLongPtr($process.MainWindowHandle, [GamingStatusWindowApi]::GWL_STYLE)
        $style = $stylePtr.ToInt64()
        $hasCaption = (($style -band [GamingStatusWindowApi]::WS_CAPTION) -ne 0)
        $hasThickFrame = (($style -band [GamingStatusWindowApi]::WS_THICKFRAME) -ne 0)

        $matchedScreen = $null
        foreach ($screen in $screens) {
            $bounds = $screen.Bounds
            if ([Math]::Abs($rect.Left - $bounds.Left) -le 2 -and
                [Math]::Abs($rect.Top - $bounds.Top) -le 2 -and
                [Math]::Abs($width - $bounds.Width) -le 4 -and
                [Math]::Abs($height - $bounds.Height) -le 4) {
                $matchedScreen = $screen
                break
            }
        }

        $modeGuess = "windowed"
        if ($null -ne $matchedScreen -and -not $hasCaption) {
            $modeGuess = "borderless/fullscreen-size"
        }
        elseif ($null -ne $matchedScreen) {
            $modeGuess = "fullscreen-size with window chrome"
        }

        $path = ""
        try { $path = $process.Path } catch { }

        $rows += [pscustomobject]@{
            Process = $process.ProcessName
            Title = $process.MainWindowTitle
            Path = $path
            Rect = "$($rect.Left),$($rect.Top) $($width)x$($height)"
            Screen = if ($matchedScreen) { "$($matchedScreen.DeviceName) $($matchedScreen.Bounds.Width)x$($matchedScreen.Bounds.Height)" } else { "" }
            HasCaption = $hasCaption
            HasResizableFrame = $hasThickFrame
            ModeGuess = $modeGuess
        }
    }

    if ($rows.Count -gt 0) {
        foreach ($row in $rows | Where-Object { $_.ModeGuess -ne "windowed" } | Select-Object -First 10) {
            Add-Finding "Fullscreen/Game" "Running window mode - $($row.Process)" "INFO" $row.ModeGuess "Geometry probe only" "This does not prove DXGI exclusive mode; it shows window shape and FSO policy separately." 3
        }
    }

    return $rows
}

function Get-NetworkStatus {
    $net = [ordered]@{}

    $netshTcpGlobal = Invoke-TextCommand "netsh.exe" @("int", "tcp", "show", "global")
    $netshTcpSupplemental = Invoke-TextCommand "netsh.exe" @("int", "tcp", "show", "supplemental")
    $netshTcpHeuristics = Invoke-TextCommand "netsh.exe" @("int", "tcp", "show", "heuristics")
    $netshIpGlobal = Invoke-TextCommand "netsh.exe" @("int", "ip", "show", "global")
    $netshSubinterfaces = Invoke-TextCommand "netsh.exe" @("interface", "ipv4", "show", "subinterfaces")

    $script:Raw["netsh_tcp_global"] = $netshTcpGlobal
    $script:Raw["netsh_tcp_supplemental"] = $netshTcpSupplemental
    $script:Raw["netsh_tcp_heuristics"] = $netshTcpHeuristics
    $script:Raw["netsh_ip_global"] = $netshIpGlobal
    $script:Raw["netsh_ipv4_subinterfaces"] = $netshSubinterfaces

    try {
        $adapters = @(Get-NetAdapter -ErrorAction Stop | Sort-Object Status, Name | Select-Object Name, InterfaceDescription, Status, LinkSpeed, MacAddress, DriverInformation)
        $net["Adapters"] = $adapters
        foreach ($adapter in $adapters | Where-Object { $_.Status -eq "Up" }) {
            Add-Finding "Network" "Adapter up - $($adapter.Name)" "INFO" "$($adapter.LinkSpeed)" "Use wired Ethernet for strict latency tests" $adapter.InterfaceDescription 3
        }
    }
    catch {
        $net["Adapters"] = @()
        Add-Finding "Network" "Get-NetAdapter" "UNKNOWN" "not readable" "NetAdapter module available" $_.Exception.Message 3
    }

    try {
        $offloadRaw = Get-NetOffloadGlobalSetting -ErrorAction Stop
        $offload = $offloadRaw | Select-Object Chimney, NetworkDirect, NetworkDirectAcrossIPSubnets, PacketCoalescingFilter, ReceiveSegmentCoalescing, ReceiveSideScaling, TaskOffload
        $net["OffloadGlobal"] = $offload
        if ([string]$offload.ReceiveSideScaling -match "Enabled|1") {
            Add-Finding "Network" "Receive-side scaling" "OK" "enabled" "Enabled for modern NICs" "RSS helps distribute network processing across CPU cores." 2
        }
        else {
            Add-Finding "Network" "Receive-side scaling" "WARN" "$($offload.ReceiveSideScaling)" "Usually enabled" "RSS disabled can bottleneck fast adapters." 2
        }
        if ([string]$offload.ReceiveSegmentCoalescing -match "Enabled|1") {
            Add-Finding "Network" "Receive segment coalescing" "INFO" "enabled" "Measure per game/NIC" "RSC improves throughput but can add batching; low-latency profiles often test disabled." 3
        }
    }
    catch {
        $net["OffloadGlobal"] = $null
    }

    try {
        $rss = @(Get-NetAdapterRss -ErrorAction Stop | Select-Object Name, Enabled, BaseProcessorNumber, MaxProcessorNumber, NumberOfReceiveQueues, Profile)
        $net["AdapterRss"] = $rss
    }
    catch {
        $net["AdapterRss"] = @()
    }

    try {
        $rsc = @(Get-NetAdapterRsc -ErrorAction Stop | Select-Object Name, IPv4Enabled, IPv6Enabled, IPv4OperationalState, IPv6OperationalState)
        $net["AdapterRsc"] = $rsc
    }
    catch {
        $net["AdapterRsc"] = @()
    }

    try {
        $advancedNames = "Interrupt Moderation|Energy Efficient Ethernet|Green Ethernet|Large Send Offload|Receive Side Scaling|Flow Control|Jumbo|Speed.*Duplex|Packet Coalescing|EEE|Power Saving"
        $advanced = @(Get-NetAdapterAdvancedProperty -ErrorAction Stop | Where-Object { $_.DisplayName -match $advancedNames } | Select-Object Name, DisplayName, DisplayValue, RegistryKeyword, RegistryValue)
        $net["AdapterAdvancedGamingRelevant"] = $advanced
        foreach ($prop in $advanced | Where-Object { $_.DisplayName -match "Interrupt Moderation|Energy Efficient|Green Ethernet|Power Saving|Packet Coalescing" }) {
            Add-Finding "Network" "NIC advanced - $($prop.Name) / $($prop.DisplayName)" "INFO" "$($prop.DisplayValue)" "Measure per NIC; disable power-saving features for benchmark profiles" "Driver-specific setting." 3
        }
    }
    catch {
        $net["AdapterAdvancedGamingRelevant"] = @()
    }

    try {
        $ipInterfaces = @(Get-NetIPInterface -AddressFamily IPv4 -ErrorAction Stop | Sort-Object InterfaceMetric | Select-Object InterfaceAlias, AddressFamily, Dhcp, ConnectionState, NlMtu, InterfaceMetric)
        $net["IPInterfaces"] = $ipInterfaces
    }
    catch {
        $net["IPInterfaces"] = @()
    }
    Add-InterfaceMtuFindings -IPInterfaces @($net["IPInterfaces"]) -Adapters @($net["Adapters"])

    try {
        $dns = @(Get-DnsClientServerAddress -AddressFamily IPv4 -ErrorAction Stop | Select-Object InterfaceAlias, ServerAddresses)
        $net["DnsServers"] = $dns
    }
    catch {
        $net["DnsServers"] = @()
    }

    $benchmarkTargets = New-Object System.Collections.Generic.List[string]
    $gamePingTargets = @(Resolve-GamePingProfiles -Profiles $GamePingProfile)
    $gamePingTargetMap = @{}
    $net["GamePingProfiles"] = $gamePingTargets
    foreach ($group in @($gamePingTargets | Group-Object Profile)) {
        if ($group.Count -gt 0) {
            $gameName = @($group.Group | Select-Object -First 1)[0].Game
            Add-Finding "Network" "Game ping profile - $($group.Name)" "INFO" "$($group.Count) targets" "Route/service probe, not exact match-server ping" "$gameName targets added. Some games do not expose stable ICMP game servers." 3
        }
    }

    if (-not $NoNetworkBenchmark) {
        try {
            $gateway = Get-NetRoute -DestinationPrefix "0.0.0.0/0" -ErrorAction Stop |
                Sort-Object RouteMetric, InterfaceMetric |
                Select-Object -First 1 -ExpandProperty NextHop
            if ($gateway -and $gateway -ne "0.0.0.0") {
                $benchmarkTargets.Add($gateway) | Out-Null
            }
        }
        catch {
        }

        foreach ($target in $PingTarget) {
            if (-not $benchmarkTargets.Contains($target)) {
                $benchmarkTargets.Add($target) | Out-Null
            }
        }

        foreach ($gameTarget in $gamePingTargets) {
            if ($gameTarget.Target) {
                $gamePingTargetMap[[string]$gameTarget.Target] = [string]$gameTarget.Profile
            }
            if ($gameTarget.Target -and -not $benchmarkTargets.Contains([string]$gameTarget.Target)) {
                $benchmarkTargets.Add([string]$gameTarget.Target) | Out-Null
            }
        }
    }

    $mtuPath = @()
    if (-not $NoNetworkBenchmark) {
        foreach ($target in @($benchmarkTargets.ToArray() | Select-Object -First 3)) {
            $mtuPath += Test-MtuPathTarget -Target $target
        }
    }
    $net["MtuPathProbe"] = $mtuPath

    $ping = @()
    if (-not $NoNetworkBenchmark) {
        foreach ($target in $benchmarkTargets) {
            $isGameProbe = $gamePingTargetMap.ContainsKey([string]$target)
            $targetPingCount = if ($isGameProbe) { [Math]::Min($PingCount, 3) } else { $PingCount }
            $ping += Test-PingTarget -Target $target -Count $targetPingCount -IsGameProbe $isGameProbe
        }
    }
    $net["Ping"] = $ping

    return [pscustomobject]$net
}

function Add-InterfaceMtuFindings {
    param(
        [object[]]$IPInterfaces,
        [object[]]$Adapters
    )

    $activeAdapterNames = @($Adapters | Where-Object { $_.Status -eq "Up" } | ForEach-Object { [string]$_.Name })
    foreach ($iface in @($IPInterfaces)) {
        if ($null -eq $iface) { continue }
        if ($activeAdapterNames.Count -gt 0 -and -not ($activeAdapterNames -contains [string]$iface.InterfaceAlias)) { continue }
        if ($null -eq $iface.NlMtu) { continue }

        $mtu = [int]$iface.NlMtu
        if ($mtu -le 0 -or $mtu -gt 100000) { continue }

        $name = "Interface MTU - $($iface.InterfaceAlias)"
        if ($mtu -eq 1500) {
            Add-Finding "Network" $name "OK" "$mtu bytes" "1500 bytes for standard Ethernet" "Standard Ethernet MTU. Good default for normal internet gaming." 2
        }
        elseif ($mtu -eq 1492) {
            Add-Finding "Network" $name "INFO" "$mtu bytes" "1500 standard, 1492 common for PPPoE" "1492 can be correct for PPPoE. Do not force 1500 unless DF path probes prove it works." 3
        }
        elseif ($mtu -gt 1500) {
            Add-Finding "Network" $name "INFO" "$mtu bytes jumbo/local" "1500 for internet path unless jumbo LAN is intentional" "Jumbo MTU only helps on paths where every device supports it. Internet gaming usually still depends on 1500 path MTU." 3
        }
        elseif ($mtu -lt 1400) {
            Add-Finding "Network" $name "WARN" "$mtu bytes low" "Usually 1500 Ethernet or 1492 PPPoE" "Low MTU is often caused by VPN/tunnel/adapter overrides and can hurt throughput or cause odd connectivity." 2
        }
        else {
            Add-Finding "Network" $name "INFO" "$mtu bytes" "Usually 1500 Ethernet or 1492 PPPoE" "Non-standard MTU. Verify this is required by ISP, router, VPN or tunnel path." 3
        }
    }
}

function Test-MtuPathTarget {
    param([string]$Target)

    $payloads = @(1472, 1464, 1452, 1400, 1372, 1200)
    $rows = @()
    $bestPayload = $null
    $blocked = $false

    foreach ($payload in $payloads) {
        $output = Invoke-TextCommand "ping.exe" @("-n", "1", "-w", "900", "-f", "-l", [string]$payload, $Target)
        $success = ([string]$output -match "(?i)\bTTL=")
        $fragmented = ([string]$output -match "(?i)fragment|DF|fragmentiert|Paket.*fragment")
        $timeout = ([string]$output -match "(?i)timed out|timeout|Zeitüberschreitung|unreachable|nicht erreichbar|100%")

        $rows += [pscustomobject]@{
            Target = $Target
            PayloadBytes = $payload
            PacketBytes = $payload + 28
            Success = $success
            Fragmented = $fragmented
            TimedOutOrBlocked = (-not $success -and $timeout)
        }

        if ($success) {
            $bestPayload = $payload
            break
        }
        if (-not $fragmented -and $timeout) {
            $blocked = $true
        }
    }

    $estimate = if ($null -ne $bestPayload) { $bestPayload + 28 } else { $null }
    $status = "UNKNOWN"
    $note = "DF ping could not confirm path MTU. ICMP may be blocked by the target or network."
    $value = "not verified"

    if ($null -ne $estimate) {
        $value = "$estimate bytes path estimate"
        if ($estimate -ge 1500) {
            $status = "OK"
            $note = "1472-byte DF payload passed, so a standard 1500-byte IPv4 path works to this target."
        }
        elseif ($estimate -ge 1492) {
            $status = "INFO"
            $note = "1492-byte path is often normal for PPPoE. Do not force 1500 unless 1472-byte DF payload passes."
        }
        elseif ($estimate -ge 1400) {
            $status = "INFO"
            $note = "Path MTU is below standard Ethernet. This can be normal on some VPN/tunnel/ISP paths; verify before changing."
        }
        else {
            $status = "WARN"
            $note = "Path MTU looks unusually low. Check VPN, tunnel, router WAN MTU or jumbo-frame mismatch."
        }
    }
    elseif ($blocked) {
        $status = "UNKNOWN"
        $note = "DF ping appears blocked or timed out. This does not prove MTU is bad."
    }

    Add-Finding "Network" "Path MTU $Target" $status $value "1500 bytes path for normal Ethernet; 1492 often normal for PPPoE" $note 2

    return [pscustomobject]@{
        Target = $Target
        Status = $status
        EstimatedPathMtuBytes = $estimate
        BestPayloadBytes = $bestPayload
        TestedPayloads = ($payloads -join ",")
        Note = $note
        Probes = $rows
    }
}

function Test-PingTarget {
    param(
        [string]$Target,
        [int]$Count,
        [bool]$IsGameProbe = $false
    )

    $times = @()
    $loss = 100.0
    $status = "UNKNOWN"
    $note = ""

    try {
        $result = @(Test-Connection -ComputerName $Target -Count $Count -ErrorAction SilentlyContinue)
        foreach ($row in $result) {
            if ($null -ne $row.ResponseTime) {
                $times += [double]$row.ResponseTime
            }
            elseif ($null -ne $row.Latency) {
                $times += [double]$row.Latency
            }
        }

        $loss = [Math]::Round((($Count - $times.Count) / [double]$Count) * 100.0, 2)
        if ($times.Count -gt 0) {
            $avg = ($times | Measure-Object -Average).Average
            $min = ($times | Measure-Object -Minimum).Minimum
            $max = ($times | Measure-Object -Maximum).Maximum
            $p95 = Get-Percentile ([double[]]$times) 95
            $jitter = $max - $min
            $status = "OK"
            if ($loss -gt 0) { $status = "WARN" }
            elseif ($jitter -gt 20) { $status = "WARN" }

            if ($status -eq "OK") {
                Add-Finding "Network" "Ping $Target" "OK" "$([Math]::Round($avg, 2)) ms avg / $loss% loss" "0% loss, low jitter" "p95 $([Math]::Round($p95, 2)) ms, jitter $([Math]::Round($jitter, 2)) ms." 2
            }
            else {
                Add-Finding "Network" "Ping $Target" "WARN" "$([Math]::Round($avg, 2)) ms avg / $loss% loss" "0% loss, low jitter" "p95 $([Math]::Round($p95, 2)) ms, jitter $([Math]::Round($jitter, 2)) ms." 1
            }

            return [pscustomobject]@{
                Target = $Target
                Sent = $Count
                Received = $times.Count
                LossPct = $loss
                MinMs = [Math]::Round($min, 3)
                AvgMs = [Math]::Round($avg, 3)
                P95Ms = [Math]::Round($p95, 3)
                MaxMs = [Math]::Round($max, 3)
                JitterMs = [Math]::Round($jitter, 3)
                Status = $status
                Note = $note
                IsGameProbe = $IsGameProbe
            }
        }
    }
    catch {
        $note = $_.Exception.Message
    }

    if ($IsGameProbe) {
        Add-Finding "Network" "Ping $Target" "INFO" "no ICMP replies" "Reachable target or ICMP-blocked game service endpoint" "Game/profile target did not answer ICMP. This is common for some service/datacenter endpoints and does not prove bad in-game ping." 3
        $status = "INFO"
        $note = "Game/profile target did not answer ICMP; use in-game ping or server browser as source of truth."
    }
    else {
        Add-Finding "Network" "Ping $Target" "WARN" "no replies" "Reachable target" $note 2
    }
    return [pscustomobject]@{
        Target = $Target
        Sent = $Count
        Received = 0
        LossPct = 100
        MinMs = $null
        AvgMs = $null
        P95Ms = $null
        MaxMs = $null
        JitterMs = $null
        Status = $status
        Note = $note
        IsGameProbe = $IsGameProbe
    }
}

function Get-SecurityLatencyStatus {
    $status = [ordered]@{}

    try {
        $dg = Get-CimInstance -Namespace "root\Microsoft\Windows\DeviceGuard" -ClassName "Win32_DeviceGuard" -ErrorAction Stop
        $status["DeviceGuard"] = $dg | Select-Object SecurityServicesConfigured, SecurityServicesRunning, VirtualizationBasedSecurityStatus, RequiredSecurityProperties, AvailableSecurityProperties

        if ($dg.VirtualizationBasedSecurityStatus -eq 2) {
            Add-Finding "Security" "Virtualization-based security" "INFO" "running" "Benchmark both states before changing security" "VBS can affect some latency/FPS results, but disabling it is a security tradeoff." 3
        }
        elseif ($dg.VirtualizationBasedSecurityStatus -eq 1) {
            Add-Finding "Security" "Virtualization-based security" "INFO" "enabled, not running" "Benchmark both states before changing security" "VBS is configured but not currently running." 3
        }
        else {
            Add-Finding "Security" "Virtualization-based security" "INFO" "not running" "Security/performance tradeoff" "No running VBS reported by DeviceGuard WMI." 3
        }
    }
    catch {
        $status["DeviceGuard"] = $null
    }

    try {
        $hvci = Get-RegistryValueSafe "HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity" "Enabled"
        $status["MemoryIntegrityRegistry"] = $hvci
        if ($hvci -eq 1) {
            Add-Finding "Security" "Memory integrity / HVCI" "INFO" "enabled" "Security/performance tradeoff" "Can affect some systems; benchmark before changing." 3
        }
        elseif ($hvci -eq 0) {
            Add-Finding "Security" "Memory integrity / HVCI" "INFO" "disabled" "Security/performance tradeoff" "Registry reports HVCI disabled." 3
        }
    }
    catch {
    }

    return [pscustomobject]$status
}

function Get-OverlayProcessStatus {
    $names = @(
        "Discord", "steam", "GameBar", "GameBarFTServer", "XboxGameBar", "NVIDIA Share",
        "NVIDIA Overlay", "nvsphelper64", "RTSS", "MSIAfterburner", "obs64", "Overwolf",
        "medal", "SteelSeriesGG", "Razer Synapse", "iCUE"
    )

    $rows = @()
    foreach ($process in @(Get-Process -ErrorAction SilentlyContinue)) {
        foreach ($name in $names) {
            if ($process.ProcessName -ieq $name -or $process.ProcessName -like "$name*") {
                $rows += [pscustomobject]@{
                    Process = $process.ProcessName
                    Id = $process.Id
                    MainWindowTitle = $process.MainWindowTitle
                    Path = $(try { $process.Path } catch { "" })
                }
                break
            }
        }
    }

    if ($rows.Count -gt 0) {
        Add-Finding "Overlays" "Overlay/helper processes" "INFO" "$($rows.Count) detected" "Disable for clean A/B benchmarks if needed" "Overlay processes are not automatically bad; keep the state consistent between runs." 3
    }
    else {
        Add-Finding "Overlays" "Overlay/helper processes" "OK" "none from watchlist" "Clean benchmark state" "No common overlay helper process from the watchlist is running." 3
    }

    return $rows | Sort-Object Process, Id
}

function Get-HostStatus {
    $os = $null
    $computer = $null
    $cpu = $null

    try { $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop } catch { }
    try { $computer = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop } catch { }
    try { $cpu = Get-CimInstance Win32_Processor -ErrorAction Stop | Select-Object -First 1 } catch { }

    return [pscustomobject]@{
        ComputerName = $env:COMPUTERNAME
        UserName = $env:USERNAME
        IsAdmin = Test-IsAdmin
        TimestampLocal = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss zzz")
        PowerShell = $PSVersionTable.PSVersion.ToString()
        OS = if ($os) { "$($os.Caption) $($os.Version) build $($os.BuildNumber)" } else { "" }
        InstallDate = if ($os) { $os.InstallDate } else { $null }
        LastBoot = if ($os) { $os.LastBootUpTime } else { $null }
        Manufacturer = if ($computer) { $computer.Manufacturer } else { "" }
        Model = if ($computer) { $computer.Model } else { "" }
        CPU = if ($cpu) { $cpu.Name } else { "" }
        LogicalProcessors = if ($cpu) { $cpu.NumberOfLogicalProcessors } else { $null }
        MemoryGB = if ($computer) { [Math]::Round($computer.TotalPhysicalMemory / 1GB, 2) } else { $null }
    }
}

function Write-ConsoleReport {
    param([object]$Report)

    $colors = @{
        OK = "Green"
        WARN = "Yellow"
        FAIL = "Red"
        INFO = "Cyan"
        UNKNOWN = "DarkYellow"
    }

    Write-Host ""
    Write-Host "Gaming Status Bench - $($Report.Host.ComputerName)" -ForegroundColor White
    Write-Host "Timestamp: $($Report.Host.TimestampLocal) | Admin: $($Report.Host.IsAdmin) | Report: $($Report.Paths.Json)" -ForegroundColor DarkGray
    Write-Host ""

    if ($Report.Analysis -and $Report.Analysis.ActionGuide) {
        $guide = $Report.Analysis.ActionGuide
        Write-Host "Action guide" -ForegroundColor White
        Write-Host "  Verdict: $($guide.Summary.Verdict)" -ForegroundColor Cyan
        Write-Host "  Must fix: $($guide.Summary.MustFix) | Should fix: $($guide.Summary.ShouldFix) | Review: $($guide.Summary.Review) | Optional: $($guide.Summary.Optional) | Keep: $($guide.Summary.Keep)" -ForegroundColor DarkGray
        Write-Host "  Legend: MUST FIX=change now | SHOULD FIX=fix before trusting | REVIEW=retest/check | OPTIONAL=A/B only | KEEP=leave" -ForegroundColor DarkGray
        foreach ($row in @($guide.TopActions)) {
            $line = "  {0,-10} {1,-18} {2}" -f $row.Decision, $row.Area, $row.Check
            $color = switch ($row.Decision) {
                "MUST FIX" { "Red" }
                "SHOULD FIX" { "Yellow" }
                "CHECK" { "DarkYellow" }
                "REVIEW" { "Cyan" }
                default { "Gray" }
            }
            Write-Host $line -ForegroundColor $color
            Write-Host "    $($row.Action)" -ForegroundColor DarkGray
        }
        Write-Host ""
    }

    if ($Report.Analysis -and $Report.Analysis.FixGuide) {
        $fixGuide = $Report.Analysis.FixGuide
        Write-Host "Fix guide" -ForegroundColor White
        Write-Host "  Required fixes: $($fixGuide.Summary.RequiredFixes) | Review/check: $($fixGuide.Summary.ReviewOrCheck) | Command-backed: $($fixGuide.Summary.CommandBackedFixes)" -ForegroundColor Cyan
        Write-Host "  Rule: $($fixGuide.Summary.Rule)" -ForegroundColor DarkGray
        foreach ($row in @($fixGuide.TopFixes)) {
            $line = "  {0,-10} {1,-18} {2}" -f $row.Decision, $row.Area, $row.Check
            $color = switch ($row.Decision) {
                "MUST FIX" { "Red" }
                "SHOULD FIX" { "Yellow" }
                "CHECK" { "DarkYellow" }
                "REVIEW" { "Cyan" }
                default { "Gray" }
            }
            Write-Host $line -ForegroundColor $color
            Write-Host "    $($row.FixSummary)" -ForegroundColor DarkGray
            if ($row.SolverAction) {
                Write-Host "    Solver: $($row.SolverAction)" -ForegroundColor DarkGray
            }
        }
        Write-Host ""
    }

    if ($Report.Analysis -and $Report.Analysis.Timer) {
        $summary = $Report.Analysis.Timer.Summary
        Write-Host "Timer analysis" -ForegroundColor White
        Write-Host "  Overall:               $($summary.Overall)" -ForegroundColor Cyan
        Write-Host "  Competitive target:    $($summary.CompetitiveTimerTarget)" -ForegroundColor Cyan
        Write-Host "  Lowest supported:      $($summary.LowestSupportedResolutionMs) ms | current: $($summary.CurrentResolutionMs) ms" -ForegroundColor Cyan
        Write-Host "  Global timer mode:     $($summary.GlobalTimerMode)" -ForegroundColor Cyan
        Write-Host "  External Sleep tester: $($summary.ExternalSleepTester)" -ForegroundColor Cyan
        Write-Host "  Remaining jitter:      $($summary.RemainingJitter)" -ForegroundColor Cyan
        Write-Host "  Steps:                 $($summary.CompetitiveTimerSteps)" -ForegroundColor DarkGray
        Write-Host ""
        Write-Host "  Matrix" -ForegroundColor DarkGray
        foreach ($row in @($Report.Analysis.Timer.Matrix)) {
            $color = if ($colors.ContainsKey([string]$row.Status)) { $colors[[string]$row.Status] } else { "Gray" }
            $line = "    {0,-28} {1,-7} {2}" -f $row.Check, $row.Status, $row.Value
            Write-Host $line -ForegroundColor $color
            Write-Host "      good: $($row.Good) | warn: $($row.Warn) | bad: $($row.Bad)" -ForegroundColor DarkGray
        }
        Write-Host ""
    }

    $order = @("FAIL", "WARN", "OK", "INFO", "UNKNOWN")
    foreach ($status in $order) {
        $items = @($Report.Findings | Where-Object { $_.Status -eq $status } | Sort-Object Priority, Area, Name)
        if ($items.Count -eq 0) { continue }

        Write-Host "[$status] $($items.Count)" -ForegroundColor $colors[$status]
        foreach ($item in $items) {
            $line = "  {0,-18} {1,-42} {2}" -f $item.Area, $item.Name, $item.Value
            Write-Host $line -ForegroundColor $colors[$status]
            if ($item.Note) {
                Write-Host "    $($item.Note)" -ForegroundColor DarkGray
            }
        }
        Write-Host ""
    }

    if ($Report.Paths.Html) {
        Write-Host "HTML: $($Report.Paths.Html)" -ForegroundColor White
    }
}

function ConvertTo-HtmlEscaped {
    param([object]$Value)
    return [System.Net.WebUtility]::HtmlEncode([string]$Value)
}

function Convert-ListToHtmlTable {
    param(
        [object[]]$Rows,
        [string]$EmptyText = "No rows"
    )

    if (-not $Rows -or $Rows.Count -eq 0) {
        return "<p class=""empty"">$([System.Net.WebUtility]::HtmlEncode($EmptyText))</p>"
    }

    $props = @($Rows[0].PSObject.Properties | Select-Object -ExpandProperty Name)
    $html = "<div class=""table-wrap""><table><thead><tr>"
    foreach ($prop in $props) {
        $html += "<th>$(ConvertTo-HtmlEscaped $prop)</th>"
    }
    $html += "</tr></thead><tbody>"

    foreach ($row in $Rows) {
        $html += "<tr>"
        foreach ($prop in $props) {
            $value = $row.$prop
            if ($value -is [System.Collections.IEnumerable] -and $value -isnot [string]) {
                $value = ($value -join ", ")
            }
            $html += "<td>$(ConvertTo-HtmlEscaped $value)</td>"
        }
        $html += "</tr>"
    }

    $html += "</tbody></table></div>"
    return $html
}

function New-HtmlReport {
    param([object]$Report)

    $findingsHtml = Convert-ListToHtmlTable -Rows @($Report.Findings | Sort-Object Priority, Area, Name)
    $pingHtml = Convert-ListToHtmlTable -Rows @($Report.Sections.Network.Ping)
    $gamePingHtml = Convert-ListToHtmlTable -Rows @($Report.Sections.Network.GamePingProfiles)
    $gpuHtml = Convert-ListToHtmlTable -Rows @($Report.Sections.DisplayGpu.VideoControllers)
    $nvidiaHtml = Convert-ListToHtmlTable -Rows @($Report.Sections.DisplayGpu.NvidiaSmi)
    $gameExeHtml = Convert-ListToHtmlTable -Rows @($Report.Sections.FullscreenGame.GameExeCompatibility)
    $windowsHtml = Convert-ListToHtmlTable -Rows @($Report.Sections.FullscreenGame.RunningWindows)
    $adapterHtml = Convert-ListToHtmlTable -Rows @($Report.Sections.Network.Adapters)
    $ipInterfaceHtml = Convert-ListToHtmlTable -Rows @($Report.Sections.Network.IPInterfaces)
    $mtuPathHtml = Convert-ListToHtmlTable -Rows @($Report.Sections.Network.MtuPathProbe)
    $advancedHtml = Convert-ListToHtmlTable -Rows @($Report.Sections.Network.AdapterAdvancedGamingRelevant)
    $overlayHtml = Convert-ListToHtmlTable -Rows @($Report.Sections.Overlays)
    $timerMatrixHtml = Convert-ListToHtmlTable -Rows @($Report.Analysis.Timer.Matrix)
    $timerSummary = $Report.Analysis.Timer.Summary
    $actionGuide = $Report.Analysis.ActionGuide
    $actionTopHtml = Convert-ListToHtmlTable -Rows @($actionGuide.TopActions)
    $actionMatrixHtml = Convert-ListToHtmlTable -Rows @($actionGuide.Matrix)
    $actionLegendHtml = Convert-ListToHtmlTable -Rows @($actionGuide.Legend)
    $fixGuide = $Report.Analysis.FixGuide
    $fixTopHtml = Convert-ListToHtmlTable -Rows @($fixGuide.TopFixes)
    $fixMatrixHtml = Convert-ListToHtmlTable -Rows @($fixGuide.Matrix)
    $timerJson = ConvertTo-HtmlEscaped (($Report.Sections.Timer | ConvertTo-Json -Depth 6))
    $kernelJson = ConvertTo-HtmlEscaped (($Report.Sections.Kernel.Parsed | ConvertTo-Json -Depth 6))
    $powerJson = ConvertTo-HtmlEscaped (($Report.Sections.Power | ConvertTo-Json -Depth 6))
    $securityJson = ConvertTo-HtmlEscaped (($Report.Sections.Security | ConvertTo-Json -Depth 6))
    $rawJson = ConvertTo-HtmlEscaped (($Report.Raw | ConvertTo-Json -Depth 8))

    $counts = [ordered]@{}
    foreach ($status in @("OK", "WARN", "FAIL", "INFO", "UNKNOWN")) {
        $counts[$status] = @($Report.Findings | Where-Object { $_.Status -eq $status }).Count
    }

@"
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Gaming Status Bench - $(ConvertTo-HtmlEscaped $Report.Host.ComputerName)</title>
  <style>
    :root {
      color-scheme: dark;
      --bg: #101316;
      --panel: #181d22;
      --panel-2: #20262c;
      --text: #eef3f6;
      --muted: #9aa7b1;
      --line: #2d363e;
      --ok: #43d17a;
      --warn: #f2bc57;
      --fail: #ff6b6b;
      --info: #63c7f3;
      --unknown: #b7a6ff;
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      font-family: "Segoe UI", Arial, sans-serif;
      background: var(--bg);
      color: var(--text);
      letter-spacing: 0;
    }
    header {
      padding: 28px clamp(18px, 4vw, 48px) 18px;
      border-bottom: 1px solid var(--line);
      background: #151a1f;
    }
    h1 { margin: 0 0 8px; font-size: clamp(26px, 4vw, 42px); font-weight: 700; }
    h2 { margin: 0 0 14px; font-size: 20px; }
    h3 { margin: 0 0 10px; font-size: 16px; color: var(--muted); }
    .meta { color: var(--muted); line-height: 1.55; }
    main { padding: 22px clamp(18px, 4vw, 48px) 42px; }
    .summary {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
      gap: 12px;
      margin: 0 0 18px;
    }
    .tile {
      border: 1px solid var(--line);
      background: var(--panel);
      border-radius: 8px;
      padding: 14px;
      min-height: 88px;
    }
    .tile .label { color: var(--muted); font-size: 13px; }
    .tile .value { font-size: 32px; font-weight: 700; margin-top: 6px; }
    .OK { color: var(--ok); }
    .WARN { color: var(--warn); }
    .FAIL { color: var(--fail); }
    .INFO { color: var(--info); }
    .UNKNOWN { color: var(--unknown); }
    section {
      margin-top: 18px;
      padding: 18px;
      border: 1px solid var(--line);
      background: var(--panel);
      border-radius: 8px;
    }
    .grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
      gap: 18px;
    }
    .table-wrap {
      overflow: auto;
      border: 1px solid var(--line);
      border-radius: 8px;
      background: var(--panel-2);
    }
    table {
      width: 100%;
      border-collapse: collapse;
      min-width: 720px;
    }
    th, td {
      border-bottom: 1px solid var(--line);
      padding: 9px 10px;
      text-align: left;
      vertical-align: top;
      font-size: 13px;
      line-height: 1.4;
      overflow-wrap: anywhere;
    }
    th {
      color: var(--muted);
      font-weight: 600;
      background: #1b2127;
      position: sticky;
      top: 0;
    }
    pre {
      margin: 0;
      white-space: pre-wrap;
      overflow-wrap: anywhere;
      background: #0d1013;
      border: 1px solid var(--line);
      border-radius: 8px;
      padding: 12px;
      color: #d8e1e7;
      font-size: 12px;
      line-height: 1.45;
    }
    .empty { color: var(--muted); margin: 0; }
    .note { color: var(--muted); margin: 0 0 14px; }
  </style>
</head>
<body>
  <header>
    <h1>Gaming Status Bench</h1>
    <div class="meta">
      $(ConvertTo-HtmlEscaped $Report.Host.ComputerName) | $(ConvertTo-HtmlEscaped $Report.Host.OS)<br>
      $(ConvertTo-HtmlEscaped $Report.Host.CPU) | RAM $(ConvertTo-HtmlEscaped $Report.Host.MemoryGB) GB | Admin: $(ConvertTo-HtmlEscaped $Report.Host.IsAdmin)<br>
      $(ConvertTo-HtmlEscaped $Report.Host.TimestampLocal)
    </div>
  </header>
  <main>
    <div class="summary">
      <div class="tile"><div class="label">OK</div><div class="value OK">$($counts.OK)</div></div>
      <div class="tile"><div class="label">WARN</div><div class="value WARN">$($counts.WARN)</div></div>
      <div class="tile"><div class="label">FAIL</div><div class="value FAIL">$($counts.FAIL)</div></div>
      <div class="tile"><div class="label">INFO</div><div class="value INFO">$($counts.INFO)</div></div>
      <div class="tile"><div class="label">UNKNOWN</div><div class="value UNKNOWN">$($counts.UNKNOWN)</div></div>
	    </div>

	    <section>
	      <h2>Action Guide</h2>
	      <p class="note">
	        Verdict: $(ConvertTo-HtmlEscaped $actionGuide.Summary.Verdict)<br>
	        Must fix: $(ConvertTo-HtmlEscaped $actionGuide.Summary.MustFix) |
	        Should fix: $(ConvertTo-HtmlEscaped $actionGuide.Summary.ShouldFix) |
	        Review: $(ConvertTo-HtmlEscaped $actionGuide.Summary.Review) |
	        Optional: $(ConvertTo-HtmlEscaped $actionGuide.Summary.Optional) |
	        Keep: $(ConvertTo-HtmlEscaped $actionGuide.Summary.Keep)
	      </p>
	      <h3>Decision legend</h3>
	      $actionLegendHtml
	      <h3>Top actions</h3>
	      $actionTopHtml
	      <h3>All checks</h3>
	      $actionMatrixHtml
	    </section>

	    <section>
	      <h2>Fix Guide</h2>
	      <p class="note">
	        Required fixes: $(ConvertTo-HtmlEscaped $fixGuide.Summary.RequiredFixes) |
	        Review/check: $(ConvertTo-HtmlEscaped $fixGuide.Summary.ReviewOrCheck) |
	        Command-backed fixes: $(ConvertTo-HtmlEscaped $fixGuide.Summary.CommandBackedFixes)<br>
	        $(ConvertTo-HtmlEscaped $fixGuide.Summary.Rule)
	      </p>
	      <h3>Recommended fixes</h3>
	      $fixTopHtml
	      <h3>All available fixes and solution notes</h3>
	      $fixMatrixHtml
	    </section>

	    <section>
	      <h2>Timer Analysis</h2>
	      <p class="note">
	        Overall: $(ConvertTo-HtmlEscaped $timerSummary.Overall)<br>
	        Competitive target: $(ConvertTo-HtmlEscaped $timerSummary.CompetitiveTimerTarget)<br>
	        Lowest supported: $(ConvertTo-HtmlEscaped $timerSummary.LowestSupportedResolutionMs) ms |
	        Current: $(ConvertTo-HtmlEscaped $timerSummary.CurrentResolutionMs) ms<br>
	        Global timer mode: $(ConvertTo-HtmlEscaped $timerSummary.GlobalTimerMode)<br>
	        External Sleep tester: $(ConvertTo-HtmlEscaped $timerSummary.ExternalSleepTester)<br>
	        Remaining jitter: $(ConvertTo-HtmlEscaped $timerSummary.RemainingJitter)<br>
	        Steps: $(ConvertTo-HtmlEscaped $timerSummary.CompetitiveTimerSteps)
	      </p>
	      $timerMatrixHtml
	    </section>

	    <section>
	      <h2>Findings</h2>
	      $findingsHtml
	    </section>

    <div class="grid">
      <section>
        <h2>Timer</h2>
        <pre>$timerJson</pre>
      </section>
      <section>
        <h2>Kernel / BCDEdit</h2>
        <pre>$kernelJson</pre>
      </section>
      <section>
        <h2>Power</h2>
        <pre>$powerJson</pre>
      </section>
      <section>
        <h2>Security</h2>
        <pre>$securityJson</pre>
      </section>
    </div>

    <section>
      <h2>Display / GPU</h2>
      <h3>WMI video controllers</h3>
      $gpuHtml
      <h3>NVIDIA SMI</h3>
      $nvidiaHtml
    </section>

    <section>
      <h2>Fullscreen / Game</h2>
      <p class="note">FSE vs FSO is not exposed as one perfect public status flag. The report separates global policy, per-exe compatibility flags, and running window geometry.</p>
      <h3>Per-game compatibility flags</h3>
      $gameExeHtml
      <h3>Running windows</h3>
      $windowsHtml
    </section>

    <section>
      <h2>Network</h2>
      <h3>Game ping profiles</h3>
      <p class="note">Game profiles are route/service probes. Exact in-match ping can differ because games use dynamic matchmaking, regional relays, server browsers or internal network tests.</p>
      $gamePingHtml
      <h3>Ping</h3>
      $pingHtml
      <h3>MTU path probes</h3>
      $mtuPathHtml
      <h3>IP interfaces / local MTU</h3>
      $ipInterfaceHtml
      <h3>Adapters</h3>
      $adapterHtml
      <h3>Gaming-relevant NIC advanced properties</h3>
      $advancedHtml
    </section>

    <section>
      <h2>Overlays</h2>
      $overlayHtml
    </section>

    <section>
      <h2>Raw Command Output</h2>
      <pre>$rawJson</pre>
    </section>
  </main>
</body>
</html>
"@
}

function Save-Report {
    param([object]$Report)

    if (-not (Test-Path $OutputDir)) {
        New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
    }

    $stamp = Get-Date -Format "yyyyMMdd-HHmmss"
    $base = "gaming-status-$($env:COMPUTERNAME)-$stamp"
    $jsonPath = Join-Path $OutputDir "$base.json"
    $htmlPath = if ($NoHtml) { $null } else { Join-Path $OutputDir "$base.html" }

    $Report.Paths.Json = $jsonPath
    $Report.Paths.Html = $htmlPath

    $jsonObject = ConvertTo-Hashtable $Report
    $jsonObject | ConvertTo-Json -Depth 12 | Set-Content -Path $jsonPath -Encoding UTF8

    if (-not $NoHtml) {
        $html = New-HtmlReport -Report $Report
        Set-Content -Path $htmlPath -Value $html -Encoding UTF8
    }

    return $Report
}

function Main {
    $hostStatus = Get-HostStatus
    if (-not $hostStatus.IsAdmin) {
        Add-Finding "Tool" "Administrator rights" "INFO" "not elevated" "Run as admin for full adapter/BCDEdit visibility" "The report still runs, but some settings may be hidden." 2
    }
    else {
        Add-Finding "Tool" "Administrator rights" "OK" "elevated" "Admin recommended for full report" "Full system queries are more likely to work." 3
    }

    $timer = [ordered]@{
        NtQueryTimerResolution = Get-TimerResolutionStatus
        ProcessTimerPolicy = Set-ProcessTimerResolutionPolicy
        GlobalTimerResolutionRequests = Get-GlobalTimerResolutionRequestStatus
        SleepJitter = Test-SleepJitter -Samples $TimerSampleCount -DelayMs $SleepMs
        HighResolutionWaitableTimer = Test-HighResolutionWaitableTimer -Samples $TimerSampleCount -DelayMs $SleepMs
    }
    $timerObject = [pscustomobject]$timer
    Add-TimerCompositeFindings -Timer $timerObject
    $timerAnalysis = New-TimerAnalysis -Timer $timerObject
    $sections = [ordered]@{
        Timer = $timerObject
        Kernel = Get-BcdeditStatus
        Power = Get-PowerStatus
        DisplayGpu = Get-DisplayAndGpuStatus
        FullscreenGame = Get-GameModeAndFsoStatus
        Network = Get-NetworkStatus
        Security = Get-SecurityLatencyStatus
        Overlays = Get-OverlayProcessStatus
    }
    $actionGuide = New-ActionGuide -Findings $script:Findings
    $fixGuide = New-FixGuide -Findings $script:Findings

    $report = [pscustomobject]@{
        Tool = "GamingStatusBench"
        Version = "0.1.2"
        Host = $hostStatus
        Paths = [ordered]@{
            Json = ""
            Html = ""
        }
        Findings = $script:Findings
        Analysis = [ordered]@{
            Timer = $timerAnalysis
            ActionGuide = $actionGuide
            FixGuide = $fixGuide
        }
        Sections = $sections
        Raw = $script:Raw
    }

    $report = Save-Report -Report $report
    if (-not $Quiet) {
        Write-ConsoleReport -Report $report
    }

    if ($OpenHtml -and $report.Paths.Html) {
        Start-Process $report.Paths.Html
    }
}

Main
