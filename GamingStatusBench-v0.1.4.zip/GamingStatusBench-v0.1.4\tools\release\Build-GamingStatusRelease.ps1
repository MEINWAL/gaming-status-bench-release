[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [ValidatePattern('^\d+\.\d+\.\d+$')]
    [string]$Version,

    [string]$Root = "",
    [switch]$NoClobber
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"

if (-not $Root) {
    $Root = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot "..\.."))
}
else {
    $Root = [System.IO.Path]::GetFullPath($Root)
}

$packageName = "GamingStatusBench-v$Version"
$distDir = Join-Path $Root "dist"
$stageDir = Join-Path $distDir $packageName
$zipPath = Join-Path $distDir "$packageName.zip"
$shaPath = Join-Path $distDir "$packageName.zip.sha256.txt"

function Assert-FileExists {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "Required file missing: $Path"
    }
}

function Assert-TextContains {
    param(
        [string]$Path,
        [string]$Needle
    )
    $text = Get-Content -LiteralPath $Path -Raw
    if (-not $text.Contains($Needle)) {
        throw "Version/package text not found in ${Path}: $Needle"
    }
}

function Assert-PowerShellParses {
    param([string]$Path)
    $errors = $null
    [void][System.Management.Automation.PSParser]::Tokenize((Get-Content -LiteralPath $Path -Raw), [ref]$errors)
    if ($errors.Count -gt 0) {
        $message = ($errors | ForEach-Object { "$($_.Message) at line $($_.Token.StartLine)" }) -join "; "
        throw "PowerShell parse failed for ${Path}: $message"
    }
}

New-Item -ItemType Directory -Path $distDir -Force | Out-Null

$collectorPath = Join-Path $Root "tools\gaming-status\GamingStatus.ps1"
$guiPath = Join-Path $Root "tools\gaming-status\GamingStatusGui.ps1"
$releaseBuildPath = Join-Path $Root "tools\release\Build-GamingStatusRelease.ps1"
$readmePath = Join-Path $Root "README.md"
$privacyPath = Join-Path $Root "PRIVACY.md"
$licensePath = Join-Path $Root "LICENSE"
$notesPath = Join-Path $Root "RELEASE_NOTES-v$Version.md"
$verifyPath = Join-Path $Root "VERIFY.ps1"
$sampleReportPath = Join-Path $Root "sample-report.json"
$runGuiPath = Join-Path $Root "Run-GamingStatus-GUI.bat"
$runCliPath = Join-Path $Root "Run-GamingStatus.bat"

foreach ($path in @($collectorPath, $guiPath, $releaseBuildPath, $readmePath, $privacyPath, $licensePath, $notesPath, $verifyPath, $sampleReportPath, $runGuiPath, $runCliPath)) {
    Assert-FileExists $path
}

Assert-PowerShellParses $collectorPath
Assert-PowerShellParses $guiPath
Assert-PowerShellParses $releaseBuildPath
Assert-PowerShellParses $verifyPath
Assert-TextContains $collectorPath "`$script:ToolVersion = `"$Version`""
Assert-TextContains $readmePath "Current release: ``v$Version``"
Assert-TextContains $notesPath "# Gaming Status Bench v$Version"
Assert-TextContains $notesPath "$packageName.zip"
Assert-TextContains $sampleReportPath "`"Version`": `"$Version`""

if (-not $NoClobber) {
    foreach ($path in @($stageDir, $zipPath, $shaPath)) {
        if (Test-Path -LiteralPath $path) {
            Remove-Item -LiteralPath $path -Recurse -Force
        }
    }
}
elseif ((Test-Path -LiteralPath $stageDir) -or (Test-Path -LiteralPath $zipPath) -or (Test-Path -LiteralPath $shaPath)) {
    throw "Output already exists. Remove it or omit -NoClobber."
}

New-Item -ItemType Directory -Path (Join-Path $stageDir "tools\gaming-status") -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $stageDir "tools\release") -Force | Out-Null

Copy-Item -LiteralPath $licensePath -Destination $stageDir
Copy-Item -LiteralPath $readmePath -Destination $stageDir
Copy-Item -LiteralPath $privacyPath -Destination $stageDir
Copy-Item -LiteralPath $notesPath -Destination $stageDir
Copy-Item -LiteralPath $verifyPath -Destination $stageDir
Copy-Item -LiteralPath $sampleReportPath -Destination $stageDir
Copy-Item -LiteralPath $runGuiPath -Destination $stageDir
Copy-Item -LiteralPath $runCliPath -Destination $stageDir
Copy-Item -LiteralPath $collectorPath -Destination (Join-Path $stageDir "tools\gaming-status")
Copy-Item -LiteralPath $guiPath -Destination (Join-Path $stageDir "tools\gaming-status")
Copy-Item -LiteralPath $releaseBuildPath -Destination (Join-Path $stageDir "tools\release")

Compress-Archive -LiteralPath $stageDir -DestinationPath $zipPath -CompressionLevel Optimal
$hash = (Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash.ToLowerInvariant()
Set-Content -LiteralPath $shaPath -Value "$hash  $packageName.zip" -Encoding ASCII

Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = [System.IO.Compression.ZipFile]::OpenRead($zipPath)
try {
    $actualEntries = @($zip.Entries | ForEach-Object { $_.FullName } | Sort-Object)
}
finally {
    $zip.Dispose()
}

$expectedEntries = @(
    "$packageName\tools\",
    "$packageName\LICENSE",
    "$packageName\README.md",
    "$packageName\PRIVACY.md",
    "$packageName\RELEASE_NOTES-v$Version.md",
    "$packageName\VERIFY.ps1",
    "$packageName\sample-report.json",
    "$packageName\Run-GamingStatus-GUI.bat",
    "$packageName\Run-GamingStatus.bat",
    "$packageName\tools\gaming-status\GamingStatus.ps1",
    "$packageName\tools\gaming-status\GamingStatusGui.ps1",
    "$packageName\tools\release\Build-GamingStatusRelease.ps1"
) | Sort-Object

$missingEntries = @($expectedEntries | Where-Object { $actualEntries -notcontains $_ })
$unexpectedEntries = @($actualEntries | Where-Object { $expectedEntries -notcontains $_ })
if ($missingEntries.Count -gt 0 -or $unexpectedEntries.Count -gt 0) {
    throw "ZIP layout mismatch. Missing: $($missingEntries -join ', ') Unexpected: $($unexpectedEntries -join ', ')"
}

[pscustomobject]@{
    Version = $Version
    PackageName = $packageName
    StageDir = $stageDir
    ZipPath = $zipPath
    Sha256Path = $shaPath
    Sha256 = $hash
    Entries = $actualEntries
}
