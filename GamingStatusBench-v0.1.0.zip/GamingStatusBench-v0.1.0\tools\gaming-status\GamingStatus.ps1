[CmdletBinding(PositionalBinding=$false)]
param(
    [string[]]$GameExePath = @(),
    [string[]]$PingTarget = @("1.1.1.1", "8.8.8.8"),
    [int]$PingCount = 8,
    [int]$TimerSampleCount = 300,
    [int]$SleepMs = 1,
    [string]$OutputDir = "",
    [switch]$NoNetworkBenchmark,
    [switch]$NoHtml,
    [switch]$OpenHtml,
    [switch]$Quiet
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = "Continue"

$script:Findings = New-Object System.Collections.Generic.List[object]
$script:Raw = [ordered]@{}

if (-not $OutputDir) {
    $OutputDir = Join-Path $PSScriptRoot "..\..\reports"
}

function Split-InputList {
    param(
        [string[]]$Values,
        [string]$Pattern
    )

    $items = New-Object System.Collections.Generic.List[string]
    foreach ($value in @($Values)) {
        if (-not $value) { continue }
        foreach ($part in ([string]$value -split $Pattern)) {
            $trimmed = $part.Trim()
            if ($trimmed) {
                $items.Add($trimmed) | Out-Null
            }
        }
    }
    return [string[]]$items.ToArray()
}

$GameExePath = @(Split-InputList -Values $GameExePath -Pattern "[;`r`n]+")
$PingTarget = @(Split-InputList -Values $PingTarget -Pattern "[,;`r`n\s]+")
if ($PingTarget.Count -eq 0) {
    $PingTarget = @("1.1.1.1", "8.8.8.8")
}

function Test-IsAdmin {
    try {
        $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object Security.Principal.WindowsPrincipal($identity)
        return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    }
    catch {
        return $false
    }
}

function Add-Finding {
    param(
        [string]$Area,
        [string]$Name,
        [string]$Status,
        [object]$Value,
        [string]$Expected = "",
        [string]$Note = "",
        [int]$Priority = 3
    )

    $script:Findings.Add([pscustomobject]@{
        Area = $Area
        Name = $Name
        Status = $Status
        Value = $Value
        Expected = $Expected
        Note = $Note
        Priority = $Priority
    }) | Out-Null
}

function Invoke-TextCommand {
    param(
        [string]$FilePath,
        [string[]]$Arguments = @()
    )

    try {
        $argText = ($Arguments | ForEach-Object {
            $part = [string]$_
            if ($part -eq "") {
                '""'
            }
            elseif ($part -match '[\s"]') {
                $escaped = $part -replace '"', '\"'
                '"' + $escaped + '"'
            }
            else {
                $part
            }
        }) -join " "

        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = $FilePath
        $psi.Arguments = $argText
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError = $true
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow = $true

        $process = [System.Diagnostics.Process]::Start($psi)
        $stdout = $process.StandardOutput.ReadToEnd()
        $stderr = $process.StandardError.ReadToEnd()
        $process.WaitForExit()

        $text = (($stdout + "`n" + $stderr) -replace "^\s+|\s+$", "")
        return $text
    }
    catch {
        return "ERROR: $($_.Exception.Message)"
    }
}

function Get-RegistryValueSafe {
    param(
        [string]$Path,
        [string]$Name
    )

    try {
        $item = Get-ItemProperty -Path $Path -ErrorAction Stop
        if ($null -ne $item.PSObject.Properties[$Name]) {
            return $item.$Name
        }
        return $null
    }
    catch {
        return $null
    }
}

function Get-Percentile {
    param(
        [double[]]$Values,
        [double]$Percentile
    )

    if (-not $Values -or $Values.Count -eq 0) {
        return $null
    }

    $sorted = @($Values | Sort-Object)
    if ($sorted.Count -eq 1) {
        return [double]$sorted[0]
    }

    $rank = ($Percentile / 100.0) * ($sorted.Count - 1)
    $low = [Math]::Floor($rank)
    $high = [Math]::Ceiling($rank)
    if ($low -eq $high) {
        return [double]$sorted[$low]
    }

    $weight = $rank - $low
    return ([double]$sorted[$low] * (1 - $weight)) + ([double]$sorted[$high] * $weight)
}

function Format-Number {
    param(
        [Nullable[double]]$Value,
        [int]$Digits = 3
    )

    if ($null -eq $Value) {
        return ""
    }

    return ([double]$Value).ToString("N$Digits", [Globalization.CultureInfo]::InvariantCulture)
}

function ConvertTo-Hashtable {
    param([object]$InputObject)

    if ($null -eq $InputObject) {
        return $null
    }

    if ($InputObject -is [System.Collections.IDictionary]) {
        $hash = [ordered]@{}
        foreach ($key in $InputObject.Keys) {
            $hash[$key] = ConvertTo-Hashtable $InputObject[$key]
        }
        return $hash
    }

    if ($InputObject -is [System.Collections.IEnumerable] -and $InputObject -isnot [string]) {
        $list = @()
        foreach ($item in $InputObject) {
            $list += ConvertTo-Hashtable $item
        }
        return $list
    }

    $props = @($InputObject.PSObject.Properties | Where-Object { $_.MemberType -in @("NoteProperty", "Property", "AliasProperty") })
    $isSimple = (
        $InputObject -is [string] -or
        $InputObject -is [ValueType] -or
        $InputObject -is [DateTime]
    )

    if (-not $isSimple -and $props.Count -gt 0) {
        $hash = [ordered]@{}
        foreach ($prop in $props) {
            $hash[$prop.Name] = ConvertTo-Hashtable $prop.Value
        }
        return $hash
    }

    return $InputObject
}

function Ensure-NativeTimer {
    if (-not ("GamingStatusNativeTimer" -as [type])) {
        Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Sequential)]
public struct GamingStatusProcessPowerThrottlingState
{
    public uint Version;
    public uint ControlMask;
    public uint StateMask;
}

public static class GamingStatusNativeTimer
{
    [DllImport("ntdll.dll")]
    public static extern int NtQueryTimerResolution(out uint MinimumResolution, out uint MaximumResolution, out uint CurrentResolution);

    [DllImport("ntdll.dll")]
    public static extern int NtSetTimerResolution(uint DesiredResolution, bool SetResolution, out uint CurrentResolution);

    [DllImport("kernel32.dll", EntryPoint="CreateWaitableTimerExW", CharSet=CharSet.Unicode, SetLastError=true)]
    public static extern IntPtr CreateWaitableTimerEx(IntPtr lpTimerAttributes, string lpTimerName, uint dwFlags, uint dwDesiredAccess);

    [DllImport("kernel32.dll", SetLastError=true)]
    public static extern bool SetWaitableTimer(IntPtr hTimer, ref long lpDueTime, int lPeriod, IntPtr pfnCompletionRoutine, IntPtr lpArgToCompletionRoutine, bool fResume);

    [DllImport("kernel32.dll", SetLastError=true)]
    public static extern uint WaitForSingleObject(IntPtr hHandle, uint dwMilliseconds);

    [DllImport("kernel32.dll", SetLastError=true)]
    public static extern bool CloseHandle(IntPtr hObject);

    [DllImport("kernel32.dll")]
    public static extern IntPtr GetCurrentProcess();

    [DllImport("kernel32.dll", SetLastError=true)]
    public static extern bool SetProcessInformation(IntPtr hProcess, int ProcessInformationClass, ref GamingStatusProcessPowerThrottlingState ProcessInformation, int ProcessInformationSize);

    public const int ProcessPowerThrottling = 4;
    public const uint PROCESS_POWER_THROTTLING_CURRENT_VERSION = 1;
    public const uint PROCESS_POWER_THROTTLING_IGNORE_TIMER_RESOLUTION = 0x00000004;
    public const uint CREATE_WAITABLE_TIMER_HIGH_RESOLUTION = 0x00000002;
    public const uint TIMER_ALL_ACCESS = 0x001F0003;
    public const uint WAIT_OBJECT_0 = 0x00000000;
}
"@ -ErrorAction Stop
    }
}

function Get-TimerResolutionStatus {
    $timer = [ordered]@{
        Supported = $false
        MinimumMs = $null
        MaximumMs = $null
        CurrentMs = $null
        NativeStatus = ""
    }

    try {
        Ensure-NativeTimer

        [uint32]$minimum = 0
        [uint32]$maximum = 0
        [uint32]$current = 0
        $status = [GamingStatusNativeTimer]::NtQueryTimerResolution([ref]$minimum, [ref]$maximum, [ref]$current)

        $timer.Supported = ($status -eq 0)
        $timer.MinimumMs = [Math]::Round($minimum / 10000.0, 4)
        $timer.MaximumMs = [Math]::Round($maximum / 10000.0, 4)
        $timer.CurrentMs = [Math]::Round($current / 10000.0, 4)
        $timer.NativeStatus = $status

        if ($timer.CurrentMs -le 1.0) {
            Add-Finding "Timer" "Current timer resolution" "OK" "$($timer.CurrentMs) ms" "<= 1.0 ms for latency-sensitive sessions" "Reported timer resolution is fine; check Sleep/Wait wake tests separately." 1
        }
        elseif ($timer.CurrentMs -le 2.0) {
            Add-Finding "Timer" "Current timer resolution" "WARN" "$($timer.CurrentMs) ms" "<= 1.0 ms for strict low-latency checks" "Playable, but not the typical tuned 0.5-1.0 ms gaming state." 2
        }
        else {
            Add-Finding "Timer" "Current timer resolution" "WARN" "$($timer.CurrentMs) ms" "<= 1.0 ms for strict low-latency checks" "Windows is on a coarse timer interval right now." 2
        }
    }
    catch {
        $timer.NativeStatus = $_.Exception.Message
        Add-Finding "Timer" "Current timer resolution" "UNKNOWN" "not readable" "NtQueryTimerResolution available" $_.Exception.Message 3
    }

    return [pscustomobject]$timer
}

function Set-ProcessTimerResolutionPolicy {
    $policy = [ordered]@{
        Supported = $false
        Applied = $false
        ErrorCode = $null
        IgnoreTimerResolutionDisabled = $false
        Version = 1
        ControlMask = 4
        StateMask = 0
        Note = ""
    }

    try {
        Ensure-NativeTimer

        $state = New-Object GamingStatusProcessPowerThrottlingState
        $state.Version = [GamingStatusNativeTimer]::PROCESS_POWER_THROTTLING_CURRENT_VERSION
        $state.ControlMask = [GamingStatusNativeTimer]::PROCESS_POWER_THROTTLING_IGNORE_TIMER_RESOLUTION
        $state.StateMask = 0

        $size = [Runtime.InteropServices.Marshal]::SizeOf([type][GamingStatusProcessPowerThrottlingState])
        $ok = [GamingStatusNativeTimer]::SetProcessInformation(
            [GamingStatusNativeTimer]::GetCurrentProcess(),
            [GamingStatusNativeTimer]::ProcessPowerThrottling,
            [ref]$state,
            $size
        )

        $policy.Supported = $true
        $policy.Applied = [bool]$ok
        $policy.IgnoreTimerResolutionDisabled = [bool]$ok

        if ($ok) {
            $policy.Note = "Current process explicitly opts out of Windows 11 timer-resolution ignoring."
            Add-Finding "Timer" "Process timer-resolution policy" "OK" "ignore disabled" "Timer requests should be honored in this process" "Cleared PROCESS_POWER_THROTTLING_IGNORE_TIMER_RESOLUTION for this scan process before wake tests." 1
        }
        else {
            $errorCode = [Runtime.InteropServices.Marshal]::GetLastWin32Error()
            $policy.ErrorCode = $errorCode
            $policy.Note = "SetProcessInformation failed with Win32 error $errorCode."
            Add-Finding "Timer" "Process timer-resolution policy" "WARN" "not applied" "Timer requests should be honored in this process" $policy.Note 1
        }
    }
    catch {
        $policy.ErrorCode = $_.Exception.Message
        $policy.Note = $_.Exception.Message
        Add-Finding "Timer" "Process timer-resolution policy" "UNKNOWN" "not available" "SetProcessInformation ProcessPowerThrottling support" $_.Exception.Message 3
    }

    return [pscustomobject]$policy
}

function Get-GlobalTimerResolutionRequestStatus {
    $path = "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\kernel"
    $name = "GlobalTimerResolutionRequests"
    $value = Get-RegistryValueSafe $path $name
    $enabled = ($value -eq 1)

    if ($enabled) {
        Add-Finding "Timer" "Global timer-resolution requests" "OK" "enabled" "Optional legacy global timer behavior for old apps/tests" "GlobalTimerResolutionRequests=1 is set. Reboot is required after changing it." 1
    }
    elseif ($null -eq $value) {
        Add-Finding "Timer" "Global timer-resolution requests" "WARN" "not set" "Enable only if legacy apps/tests sleep at 15.6 ms" "External processes that do not make their own timer request can still wake on the default 15.6 ms cadence." 1
    }
    elseif ($value -eq 0) {
        Add-Finding "Timer" "Global timer-resolution requests" "WARN" "disabled" "Enable only if legacy apps/tests sleep at 15.6 ms" "Global legacy timer mode is explicitly disabled." 1
    }
    else {
        Add-Finding "Timer" "Global timer-resolution requests" "INFO" $value "Known value: 1 enabled" "Unexpected GlobalTimerResolutionRequests value." 2
    }

    return [pscustomobject]@{
        Path = $path
        Name = $name
        Value = $value
        Enabled = $enabled
        Note = "Windows 11 legacy/global timer request compatibility switch; reboot after changes."
    }
}

function Test-SleepJitter {
    param(
        [int]$Samples,
        [int]$DelayMs
    )

    $values = New-Object System.Collections.Generic.List[double]
    $timerRequestActive = $false
    $requestedCurrentMs = $null

    try {
        Ensure-NativeTimer
        [uint32]$currentResolution = 0
        $setStatus = [GamingStatusNativeTimer]::NtSetTimerResolution(5000, $true, [ref]$currentResolution)
        $timerRequestActive = ($setStatus -eq 0)
        $requestedCurrentMs = [Math]::Round($currentResolution / 10000.0, 4)
    }
    catch {
    }

    $sw = [Diagnostics.Stopwatch]::StartNew()
    $last = $sw.Elapsed.TotalMilliseconds

    try {
        for ($i = 0; $i -lt $Samples; $i++) {
            [Threading.Thread]::Sleep($DelayMs)
            $now = $sw.Elapsed.TotalMilliseconds
            $values.Add($now - $last) | Out-Null
            $last = $now
        }
    }
    finally {
        if ($timerRequestActive) {
            try {
                [uint32]$unusedResolution = 0
                [GamingStatusNativeTimer]::NtSetTimerResolution(5000, $false, [ref]$unusedResolution) | Out-Null
            }
            catch {
            }
        }
    }

    $array = [double[]]$values.ToArray()
    $avg = ($array | Measure-Object -Average).Average
    $min = ($array | Measure-Object -Minimum).Minimum
    $max = ($array | Measure-Object -Maximum).Maximum
    $p50 = Get-Percentile $array 50
    $p95 = Get-Percentile $array 95
    $p99 = Get-Percentile $array 99

    $result = [pscustomobject]@{
        Samples = $Samples
        RequestedSleepMs = $DelayMs
        Method = "Thread.Sleep(1) with local NtSetTimerResolution request"
        TimerRequestActive = $timerRequestActive
        TimerRequestCurrentMs = $requestedCurrentMs
        CoarseWakeCadence = ([Math]::Round($p50, 4) -ge 10.0)
        MinMs = [Math]::Round($min, 4)
        AvgMs = [Math]::Round($avg, 4)
        P50Ms = [Math]::Round($p50, 4)
        P95Ms = [Math]::Round($p95, 4)
        P99Ms = [Math]::Round($p99, 4)
        MaxMs = [Math]::Round($max, 4)
    }

    if ($result.P95Ms -le 2.5) {
        Add-Finding "Timer" "Thread.Sleep(1) wake p95" "OK" "$($result.P95Ms) ms" "Low and stable for a 1 ms Thread.Sleep wake" "Thread.Sleep wakeups are fine in this process, but real game latency still needs frametime/input measurement." 2
    }
    elseif ($result.P95Ms -le 8.0) {
        Add-Finding "Timer" "Thread.Sleep(1) wake p95" "WARN" "$($result.P95Ms) ms" "Lower is better" "Thread.Sleep wakeups are delayed in this process; this is separate from NtQueryTimerResolution." 2
    }
    else {
        Add-Finding "Timer" "Thread.Sleep(1) wake p95" "WARN" "$($result.P95Ms) ms" "Lower is better" "Thread.Sleep is waking on a coarse/default-tick cadence despite the reported timer resolution; treat Sleep as bad on this system/process." 1
    }

    return $result
}

function Test-HighResolutionWaitableTimer {
    param(
        [int]$Samples,
        [int]$DelayMs
    )

    $values = New-Object System.Collections.Generic.List[double]
    $handle = [IntPtr]::Zero
    $supported = $false
    $fallbackUsed = $false
    $errorCode = 0
    $waitFailures = 0
    $timerRequestActive = $false
    $requestedCurrentMs = $null

    try {
        Ensure-NativeTimer

        try {
            [uint32]$currentResolution = 0
            $setStatus = [GamingStatusNativeTimer]::NtSetTimerResolution(5000, $true, [ref]$currentResolution)
            $timerRequestActive = ($setStatus -eq 0)
            $requestedCurrentMs = [Math]::Round($currentResolution / 10000.0, 4)
        }
        catch {
        }

        $handle = [GamingStatusNativeTimer]::CreateWaitableTimerEx(
            [IntPtr]::Zero,
            $null,
            [GamingStatusNativeTimer]::CREATE_WAITABLE_TIMER_HIGH_RESOLUTION,
            [GamingStatusNativeTimer]::TIMER_ALL_ACCESS
        )
        $supported = ($handle -ne [IntPtr]::Zero)
        if (-not $supported) {
            $errorCode = [Runtime.InteropServices.Marshal]::GetLastWin32Error()
            $handle = [GamingStatusNativeTimer]::CreateWaitableTimerEx(
                [IntPtr]::Zero,
                $null,
                0,
                [GamingStatusNativeTimer]::TIMER_ALL_ACCESS
            )
            $fallbackUsed = ($handle -ne [IntPtr]::Zero)
            if (-not $fallbackUsed) {
                Add-Finding "Timer" "Waitable timer" "UNKNOWN" "not available" "CreateWaitableTimerEx support" "High-res create failed with Win32 error $errorCode; fallback also failed with Win32 error $([Runtime.InteropServices.Marshal]::GetLastWin32Error())." 3
                return [pscustomobject]@{
                    Samples = $Samples
                    RequestedWaitMs = $DelayMs
                    Method = "CreateWaitableTimerEx HIGH_RESOLUTION + local NtSetTimerResolution"
                    Supported = $false
                    HighResolutionRequested = $true
                    FallbackUsed = $false
                    ErrorCode = $errorCode
                    TimerRequestActive = $timerRequestActive
                    TimerRequestCurrentMs = $requestedCurrentMs
                    WaitFailures = $waitFailures
                    MinMs = $null
                    AvgMs = $null
                    P50Ms = $null
                    P95Ms = $null
                    P99Ms = $null
                    MaxMs = $null
                }
            }
        }

        $sw = [Diagnostics.Stopwatch]::StartNew()
        for ($i = 0; $i -lt $Samples; $i++) {
            $dueTime = [long](-1 * $DelayMs * 10000)
            $last = $sw.Elapsed.TotalMilliseconds
            $setOk = [GamingStatusNativeTimer]::SetWaitableTimer($handle, [ref]$dueTime, 0, [IntPtr]::Zero, [IntPtr]::Zero, $false)
            if (-not $setOk) {
                $waitFailures++
                continue
            }
            $waitResult = [GamingStatusNativeTimer]::WaitForSingleObject($handle, 5000)
            $now = $sw.Elapsed.TotalMilliseconds
            if ($waitResult -eq [GamingStatusNativeTimer]::WAIT_OBJECT_0) {
                $values.Add($now - $last) | Out-Null
            }
            else {
                $waitFailures++
            }
        }
    }
    finally {
        if ($handle -ne [IntPtr]::Zero) {
            [GamingStatusNativeTimer]::CloseHandle($handle) | Out-Null
        }
        if ($timerRequestActive) {
            try {
                [uint32]$unusedResolution = 0
                [GamingStatusNativeTimer]::NtSetTimerResolution(5000, $false, [ref]$unusedResolution) | Out-Null
            }
            catch {
            }
        }
    }

    $array = [double[]]$values.ToArray()
    if ($array.Count -eq 0) {
        Add-Finding "Timer" "High-res waitable timer p95" "UNKNOWN" "no samples" "High-res waits should produce samples" "Wait failures: $waitFailures." 3
        return [pscustomobject]@{
            Samples = $Samples
            RequestedWaitMs = $DelayMs
            Method = if ($fallbackUsed) { "CreateWaitableTimerEx fallback + local NtSetTimerResolution" } else { "CreateWaitableTimerEx HIGH_RESOLUTION + local NtSetTimerResolution" }
            Supported = ($supported -or $fallbackUsed)
            HighResolutionRequested = $true
            FallbackUsed = $fallbackUsed
            ErrorCode = $errorCode
            TimerRequestActive = $timerRequestActive
            TimerRequestCurrentMs = $requestedCurrentMs
            WaitFailures = $waitFailures
            MinMs = $null
            AvgMs = $null
            P50Ms = $null
            P95Ms = $null
            P99Ms = $null
            MaxMs = $null
        }
    }

    $avg = ($array | Measure-Object -Average).Average
    $min = ($array | Measure-Object -Minimum).Minimum
    $max = ($array | Measure-Object -Maximum).Maximum
    $p50 = Get-Percentile $array 50
    $p95 = Get-Percentile $array 95
    $p99 = Get-Percentile $array 99

    $result = [pscustomobject]@{
        Samples = $Samples
        RequestedWaitMs = $DelayMs
        Method = if ($fallbackUsed) { "CreateWaitableTimerEx fallback + local NtSetTimerResolution" } else { "CreateWaitableTimerEx HIGH_RESOLUTION + local NtSetTimerResolution" }
        Supported = ($supported -or $fallbackUsed)
        HighResolutionRequested = $true
        FallbackUsed = $fallbackUsed
        ErrorCode = $errorCode
        TimerRequestActive = $timerRequestActive
        TimerRequestCurrentMs = $requestedCurrentMs
        WaitFailures = $waitFailures
        MinMs = [Math]::Round($min, 4)
        AvgMs = [Math]::Round($avg, 4)
        P50Ms = [Math]::Round($p50, 4)
        P95Ms = [Math]::Round($p95, 4)
        P99Ms = [Math]::Round($p99, 4)
        MaxMs = [Math]::Round($max, 4)
    }

    if ($result.P95Ms -le 2.5) {
        $note = if ($fallbackUsed) { "High-res flag failed with Win32 error $errorCode, but normal waitable timers honor the process timer policy and requested resolution." } else { "High-resolution waitable timers are working in this process." }
        Add-Finding "Timer" "Waitable timer p95" "OK" "$($result.P95Ms) ms" "Close to requested 1 ms wait" $note 1
    }
    elseif ($result.P95Ms -le 8.0) {
        $note = if ($fallbackUsed) { "Normal waitable timer fallback has visible scheduling delay; high-res flag failed with Win32 error $errorCode." } else { "High-res waits work but have visible scheduling delay." }
        Add-Finding "Timer" "Waitable timer p95" "WARN" "$($result.P95Ms) ms" "Close to requested 1 ms wait" $note 2
    }
    else {
        $note = if ($fallbackUsed) { "Normal waitable timer fallback also wakes coarse; high-res flag failed with Win32 error $errorCode." } else { "Even high-res waits are waking on a coarse cadence or this process is delayed." }
        Add-Finding "Timer" "Waitable timer p95" "WARN" "$($result.P95Ms) ms" "Close to requested 1 ms wait" $note 1
    }

    return $result
}

function Add-TimerCompositeFindings {
    param([object]$Timer)

    $resolution = $Timer.NtQueryTimerResolution.CurrentMs
    $sleepP95 = $Timer.SleepJitter.P95Ms
    $waitP95 = $Timer.HighResolutionWaitableTimer.P95Ms

    if ($null -ne $resolution -and $resolution -le 1.0 -and $null -ne $waitP95 -and $waitP95 -ge 10.0) {
        Add-Finding "Timer" "Timer resolution vs wake mismatch" "WARN" "$resolution ms reported / $waitP95 ms waitable p95" "Reported timer and actual wake behavior should agree" "The OS reports a fine timer resolution, but waitable timers still wake on a coarse cadence. Treat this as mixed timer state, not a clean low-latency timer state." 1
    }
    elseif ($null -ne $resolution -and $resolution -le 1.0 -and $null -ne $sleepP95 -and $sleepP95 -le 2.5 -and $null -ne $waitP95 -and $waitP95 -le 2.5) {
        Add-Finding "Timer" "Timer wake consistency" "OK" "$resolution ms / sleep $sleepP95 ms / wait $waitP95 ms" "All timer probes close to 1 ms" "Reported timer resolution and wake probes agree in this process." 2
    }
}

function New-AnalysisRow {
    param(
        [string]$Check,
        [string]$Status,
        [object]$Value,
        [string]$Good,
        [string]$Warn,
        [string]$Bad,
        [string]$Meaning
    )

    return [pscustomobject]@{
        Check = $Check
        Status = $Status
        Value = $Value
        Good = $Good
        Warn = $Warn
        Bad = $Bad
        Meaning = $Meaning
    }
}

function New-TimerAnalysis {
    param([object]$Timer)

    $resolution = $Timer.NtQueryTimerResolution.CurrentMs
    $sleep = $Timer.SleepJitter
    $wait = $Timer.HighResolutionWaitableTimer
    $global = $Timer.GlobalTimerResolutionRequests
    $policy = $Timer.ProcessTimerPolicy

    $sleepP50 = $sleep.P50Ms
    $sleepP95 = $sleep.P95Ms
    $waitP95 = $wait.P95Ms
    $jitter = if ($null -ne $sleepP95 -and $null -ne $sleepP50) { [Math]::Round([double]$sleepP95 - [double]$sleepP50, 4) } else { $null }
    $coarse = (
        ($null -ne $sleepP95 -and [double]$sleepP95 -ge 10.0) -or
        ($null -ne $waitP95 -and [double]$waitP95 -ge 10.0)
    )

    $resolutionStatus = if ($null -eq $resolution) { "UNKNOWN" } elseif ([double]$resolution -le 1.0) { "OK" } elseif ([double]$resolution -le 2.0) { "WARN" } else { "FAIL" }
    $sleepStatus = if ($null -eq $sleepP95) { "UNKNOWN" } elseif ([double]$sleepP95 -le 2.5) { "OK" } elseif ([double]$sleepP95 -lt 10.0) { "WARN" } else { "FAIL" }
    $waitStatus = if ($null -eq $waitP95) { "UNKNOWN" } elseif ([double]$waitP95 -le 2.5) { "OK" } elseif ([double]$waitP95 -lt 10.0) { "WARN" } else { "FAIL" }
    $globalStatus = if ($global.Enabled -eq $true) { "OK" } else { "WARN" }
    $policyStatus = if ($policy.Applied -eq $true) { "OK" } else { "WARN" }
    $coarseStatus = if ($coarse) { "FAIL" } else { "OK" }
    $jitterStatus = if ($null -eq $jitter) { "UNKNOWN" } elseif ($coarse) { "FAIL" } elseif ($jitter -le 0.25) { "OK" } elseif ($jitter -le 1.0) { "INFO" } elseif ($jitter -le 4.0) { "WARN" } else { "FAIL" }

    $globalMode = if ($global.Enabled -eq $true) { "fixed" } else { "not set / legacy external risk" }
    $externalSleep = if ($global.Enabled -eq $true -and -not $coarse) {
        "fixed / expected fixed for legacy tools"
    }
    elseif ($global.Enabled -eq $true -and $coarse) {
        "global mode set, but this process still wakes coarse"
    }
    else {
        "not fixed for old external tools"
    }
    $remainingJitter = if ($coarse) {
        "bad / 15 ms coarse cadence"
    }
    elseif ($null -ne $jitter -and $jitter -le 0.25) {
        "normal / very good"
    }
    elseif ($null -ne $jitter -and $jitter -le 1.0) {
        "normal"
    }
    elseif ($null -ne $jitter) {
        "watch / background scheduling noise"
    }
    else {
        "unknown"
    }

    $overall = if ($coarse) {
        "bad timer wake path"
    }
    elseif ($sleepStatus -eq "OK" -and $waitStatus -eq "OK" -and $resolutionStatus -eq "OK") {
        "clean high-res timer"
    }
    else {
        "mixed timer state"
    }

    $matrix = @(
        New-AnalysisRow "Reported timer resolution" $resolutionStatus "$resolution ms" "<= 1.0 ms" "1.0-2.0 ms" "> 2.0 ms" "Reported OS timer interval. This alone does not prove Sleep(1) wakes fast."
        New-AnalysisRow "Thread.Sleep(1) wake p95" $sleepStatus "$sleepP95 ms" "<= 2.5 ms" "2.5-10 ms" ">= 10 ms, especially ~15.6 ms" "Actual Sleep(1) wake behavior in this process. Around 15.6 ms means default/coarse clock and is not good for latency checks."
        New-AnalysisRow "Waitable timer p95" $waitStatus "$waitP95 ms" "<= 2.5 ms" "2.5-10 ms" ">= 10 ms, especially ~15.6 ms" "Actual waitable timer wake behavior. This catches paths that ignore the reported timer resolution."
        New-AnalysisRow "Global timer mode" $globalStatus $(if ($global.Enabled) { "fixed" } else { "not set" }) "GlobalTimerResolutionRequests=1" "not set if every app requests timers itself" "not set while old external tools sleep at ~15.6 ms" "Compatibility mode for older tools/games that rely on another process keeping 0.5 ms globally active."
        New-AnalysisRow "Process timer policy" $policyStatus $(if ($policy.Applied) { "ignore disabled" } else { "not applied" }) "IGNORE_TIMER_RESOLUTION cleared" "unknown" "policy blocks timer requests" "Windows 11 can let a process ignore timer-resolution requests unless this policy is cleared."
        New-AnalysisRow "15.6 ms coarse cadence" $coarseStatus $(if ($coarse) { "detected" } else { "not detected" }) "not detected" "occasional isolated spikes only" "detected in p95" "If p95 is near 15.6 ms, the process is effectively on the default scheduler tick."
        New-AnalysisRow "Remaining Sleep jitter" $jitterStatus $(if ($null -ne $jitter) { "$jitter ms p95-p50" } else { "unknown" }) "<= 0.25 ms" "0.25-4.0 ms, depending on load/sample count" "> 4.0 ms or coarse cadence" "Small spread after the 15 ms problem is fixed is normal Windows scheduling noise."
    )

    $findingStatus = if ($overall -eq "clean high-res timer") { "OK" } elseif ($coarse) { "FAIL" } else { "WARN" }
    Add-Finding "Timer" "Timer analysis verdict" $findingStatus $overall "No 15.6 ms wake cadence for gaming latency checks" "Global timer mode: $globalMode; External Sleep tester: $externalSleep; Remaining jitter: $remainingJitter." 1

    return [pscustomobject]@{
        Summary = [pscustomobject]@{
            Overall = $overall
            GlobalTimerMode = $globalMode
            ExternalSleepTester = $externalSleep
            RemainingJitter = $remainingJitter
            SleepJitterP95MinusP50Ms = $jitter
        }
        Matrix = $matrix
    }
}

function Get-BcdeditStatus {
    $text = Invoke-TextCommand "bcdedit.exe" @("/enum", "{current}")
    $script:Raw["bcdedit_current"] = $text

    $items = [ordered]@{}
    foreach ($line in ($text -split "`r?`n")) {
        if ($line -match "^\s*([a-zA-Z0-9_]+)\s+(.+?)\s*$") {
            $items[$matches[1].ToLowerInvariant()] = $matches[2].Trim()
        }
    }

    $dyn = $items["disabledynamictick"]
    if ($dyn -match "Yes|Ja|true|1") {
        Add-Finding "Kernel" "Dynamic tick" "OK" "disabled" "Often disabled for repeatable low-latency tests" "BCDEdit disabledynamictick is set." 2
    }
    elseif ($null -eq $dyn -or $dyn -eq "") {
        Add-Finding "Kernel" "Dynamic tick" "INFO" "default/not set" "Default is fine unless you compare tuned profiles" "No disabledynamictick override found." 3
    }
    else {
        Add-Finding "Kernel" "Dynamic tick" "INFO" $dyn "Depends on your tuning profile" "BCDEdit disabledynamictick is explicitly set." 3
    }

    $platformClock = $items["useplatformclock"]
    if ($platformClock -match "Yes|Ja|true|1") {
        Add-Finding "Kernel" "Forced platform clock / HPET" "WARN" "enabled" "Usually do not force HPET for modern gaming PCs" "Forced HPET can add overhead on many systems; benchmark before keeping it." 1
    }
    elseif ($null -eq $platformClock -or $platformClock -eq "") {
        Add-Finding "Kernel" "Forced platform clock / HPET" "OK" "not forced" "Do not force unless you have measured a win" "No useplatformclock override found." 2
    }
    else {
        Add-Finding "Kernel" "Forced platform clock / HPET" "INFO" $platformClock "Measure per PC" "useplatformclock is explicitly configured." 3
    }

    $platformTick = $items["useplatformtick"]
    if ($platformTick -match "Yes|Ja|true|1") {
        Add-Finding "Kernel" "Platform tick" "INFO" "enabled" "Measure per PC" "Platform tick is explicitly forced." 3
    }

    return [pscustomobject]@{
        Parsed = $items
        Raw = $text
    }
}

function Get-PowerStatus {
    $active = Invoke-TextCommand "powercfg.exe" @("/GETACTIVESCHEME")
    $script:Raw["powercfg_active_scheme"] = $active

    $schemeName = $active
    if ($active -match "\((.+)\)") {
        $schemeName = $matches[1]
    }

    if ($schemeName -match "High performance|Ultimate Performance|Hoechstleistung|Ultimative Leistung|Hohe Leistung") {
        Add-Finding "Power" "Active power plan" "OK" $schemeName "High/Ultimate performance for benchmarks" "Good baseline for repeatable gaming tests." 1
    }
    else {
        Add-Finding "Power" "Active power plan" "INFO" $schemeName "High/Ultimate performance when benchmarking" "Balanced can be fine, but compare against a performance plan." 2
    }

    $processorMin = Invoke-TextCommand "powercfg.exe" @("/query", "SCHEME_CURRENT", "SUB_PROCESSOR", "PROCTHROTTLEMIN")
    $processorMax = Invoke-TextCommand "powercfg.exe" @("/query", "SCHEME_CURRENT", "SUB_PROCESSOR", "PROCTHROTTLEMAX")
    $script:Raw["powercfg_processor_min"] = $processorMin
    $script:Raw["powercfg_processor_max"] = $processorMax

    return [pscustomobject]@{
        ActiveScheme = $active
        ProcessorMinRaw = $processorMin
        ProcessorMaxRaw = $processorMax
    }
}

function Get-DisplayAndGpuStatus {
    $video = @()
    try {
        $video = @(Get-CimInstance -ClassName Win32_VideoController -ErrorAction Stop | Select-Object Name, VideoProcessor, DriverVersion, DriverDate, CurrentHorizontalResolution, CurrentVerticalResolution, CurrentRefreshRate, AdapterRAM, Status)
    }
    catch {
        Add-Finding "Display/GPU" "Win32_VideoController" "UNKNOWN" "not readable" "WMI available" $_.Exception.Message 3
    }

    foreach ($gpu in $video) {
        $res = "$($gpu.CurrentHorizontalResolution)x$($gpu.CurrentVerticalResolution)@$($gpu.CurrentRefreshRate)Hz"
        Add-Finding "Display/GPU" "Active display mode - $($gpu.Name)" "INFO" $res "Match monitor native/high refresh mode" "WMI value; verify in Windows Advanced display for exact VRR/HDR state." 3
    }

    $nvidiaSmi = Get-Command "nvidia-smi.exe" -ErrorAction SilentlyContinue
    $nvidia = @()
    if ($nvidiaSmi) {
        $queryArgs = @(
            "--query-gpu=name,driver_version,pstate,temperature.gpu,utilization.gpu,clocks.gr,clocks.mem,power.draw,power.limit",
            "--format=csv,noheader,nounits"
        )
        $raw = Invoke-TextCommand $nvidiaSmi.Source $queryArgs
        $script:Raw["nvidia_smi"] = $raw
        foreach ($line in ($raw -split "`r?`n")) {
            if ($line.Trim() -eq "" -or $line -match "^ERROR") { continue }
            $parts = @($line -split "\s*,\s*")
            if ($parts.Count -ge 9) {
                $nvidia += [pscustomobject]@{
                    Name = $parts[0]
                    Driver = $parts[1]
                    PState = $parts[2]
                    TemperatureC = $parts[3]
                    UtilizationPct = $parts[4]
                    GraphicsClockMHz = $parts[5]
                    MemoryClockMHz = $parts[6]
                    PowerDrawW = $parts[7]
                    PowerLimitW = $parts[8]
                }
            }
        }
    }
    else {
        Add-Finding "Display/GPU" "nvidia-smi" "INFO" "not found" "Optional for NVIDIA telemetry" "WMI GPU data is still collected." 3
    }

    $graphicsDriversPath = "HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers"
    $hags = Get-RegistryValueSafe $graphicsDriversPath "HwSchMode"
    switch ($hags) {
        2 { Add-Finding "Display/GPU" "Hardware accelerated GPU scheduling" "INFO" "enabled" "Benchmark both states on your main games" "HAGS can help or hurt depending on driver/game." 3 }
        1 { Add-Finding "Display/GPU" "Hardware accelerated GPU scheduling" "INFO" "disabled" "Benchmark both states on your main games" "Registry explicitly disables HAGS." 3 }
        $null { Add-Finding "Display/GPU" "Hardware accelerated GPU scheduling" "INFO" "default/not set" "Default is OK" "No HwSchMode override found." 3 }
        default { Add-Finding "Display/GPU" "Hardware accelerated GPU scheduling" "INFO" $hags "Known values: 1 disabled, 2 enabled" "Unexpected HwSchMode value." 3 }
    }

    $mpo = Get-RegistryValueSafe $graphicsDriversPath "OverlayTestMode"
    if ($mpo -eq 5) {
        Add-Finding "Display/GPU" "Multiplane Overlay (MPO)" "INFO" "disabled via OverlayTestMode=5" "Keep only if it fixes flicker/stutter" "MPO is disabled by registry override." 3
    }
    elseif ($null -eq $mpo) {
        Add-Finding "Display/GPU" "Multiplane Overlay (MPO)" "INFO" "default/enabled" "Default unless troubleshooting" "No MPO disable override found." 3
    }
    else {
        Add-Finding "Display/GPU" "Multiplane Overlay (MPO)" "INFO" $mpo "Known disable value: 5" "Unexpected OverlayTestMode value." 3
    }

    return [pscustomobject]@{
        VideoControllers = $video
        NvidiaSmi = $nvidia
        HagsHwSchMode = $hags
        MpoOverlayTestMode = $mpo
    }
}

function Get-GameModeAndFsoStatus {
    $gameConfigPath = "HKCU:\System\GameConfigStore"
    $gameBarPath = "HKCU:\Software\Microsoft\GameBar"
    $gameDvrPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR"

    $values = [ordered]@{
        GameDVR_Enabled = Get-RegistryValueSafe $gameConfigPath "GameDVR_Enabled"
        GameDVR_FSEBehavior = Get-RegistryValueSafe $gameConfigPath "GameDVR_FSEBehavior"
        GameDVR_FSEBehaviorMode = Get-RegistryValueSafe $gameConfigPath "GameDVR_FSEBehaviorMode"
        GameDVR_HonorUserFSEBehaviorMode = Get-RegistryValueSafe $gameConfigPath "GameDVR_HonorUserFSEBehaviorMode"
        GameDVR_DXGIHonorFSEWindowsCompatible = Get-RegistryValueSafe $gameConfigPath "GameDVR_DXGIHonorFSEWindowsCompatible"
        AppCaptureEnabled = Get-RegistryValueSafe $gameDvrPath "AppCaptureEnabled"
        AutoGameModeEnabled = Get-RegistryValueSafe $gameBarPath "AutoGameModeEnabled"
        AllowAutoGameMode = Get-RegistryValueSafe $gameBarPath "AllowAutoGameMode"
        UseNexusForGameBarEnabled = Get-RegistryValueSafe $gameBarPath "UseNexusForGameBarEnabled"
    }

    if ($values.AutoGameModeEnabled -eq 1 -or $values.AllowAutoGameMode -eq 1) {
        Add-Finding "Fullscreen/Game" "Windows Game Mode" "OK" "enabled" "Usually enabled for gaming" "Game Mode registry indicates enabled." 2
    }
    elseif ($null -eq $values.AutoGameModeEnabled -and $null -eq $values.AllowAutoGameMode) {
        Add-Finding "Fullscreen/Game" "Windows Game Mode" "INFO" "default/not set" "Usually enabled for gaming" "No explicit Game Mode values found." 3
    }
    else {
        Add-Finding "Fullscreen/Game" "Windows Game Mode" "INFO" "disabled or custom" "Usually enabled for gaming" "Compare both states if you have stutter." 2
    }

    if ($values.AppCaptureEnabled -eq 0 -or $values.GameDVR_Enabled -eq 0) {
        Add-Finding "Fullscreen/Game" "GameDVR capture" "OK" "disabled" "Disable captures if you do not use them" "Background capture path appears off." 2
    }
    elseif ($values.AppCaptureEnabled -eq 1 -or $values.GameDVR_Enabled -eq 1) {
        Add-Finding "Fullscreen/Game" "GameDVR capture" "INFO" "enabled" "Disable if you want a lean benchmark state" "Capture features can add overhead when active." 2
    }
    else {
        Add-Finding "Fullscreen/Game" "GameDVR capture" "INFO" "default/not set" "Disable if you want a lean benchmark state" "No explicit capture override found." 3
    }

    $fsoMode = $values.GameDVR_FSEBehaviorMode
    if ($fsoMode -eq 2) {
        Add-Finding "Fullscreen/Game" "Global FSO/FSE behavior" "INFO" "FSE preference override visible" "Use per-game flags for exact control" "GameDVR_FSEBehaviorMode=2 is commonly used in FSO-disable tuning profiles." 2
    }
    elseif ($null -eq $fsoMode) {
        Add-Finding "Fullscreen/Game" "Global FSO/FSE behavior" "INFO" "default/not set" "Default is OK; tune per game" "Windows Fullscreen Optimizations usually remain enabled unless per-app disabled." 3
    }
    else {
        Add-Finding "Fullscreen/Game" "Global FSO/FSE behavior" "INFO" $fsoMode "Known tuned value often: 2" "Interpret together with per-game AppCompat flags." 3
    }

    $gameExe = @(Get-GameExeCompatibilityStatus -Paths $GameExePath)
    $windows = @(Get-RunningWindowStatus -KnownGamePaths $GameExePath)

    return [pscustomobject]@{
        Registry = [pscustomobject]$values
        GameExeCompatibility = $gameExe
        RunningWindows = $windows
        Note = "Windows does not expose a perfect external FSE-vs-FSO truth flag. This tool reports policy, per-exe compatibility flags, and window geometry."
    }
}

function Get-AppCompatLayers {
    $paths = @(
        "HKCU:\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers",
        "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers"
    )

    $rows = @()
    foreach ($path in $paths) {
        try {
            $item = Get-ItemProperty -Path $path -ErrorAction Stop
            foreach ($prop in $item.PSObject.Properties) {
                if ($prop.Name -like "PS*") { continue }
                $rows += [pscustomobject]@{
                    Hive = if ($path -like "HKCU:*") { "HKCU" } else { "HKLM" }
                    ExePath = $prop.Name
                    Flags = [string]$prop.Value
                    FsoDisabled = ([string]$prop.Value -match "DISABLEDXMAXIMIZEDWINDOWEDMODE")
                    RunAsAdmin = ([string]$prop.Value -match "RUNASADMIN")
                    DisableDpiScaling = ([string]$prop.Value -match "HIGHDPIAWARE|DPIUNAWARE")
                }
            }
        }
        catch {
        }
    }

    return $rows
}

function Get-GameExeCompatibilityStatus {
    param([string[]]$Paths)

    $layers = @(Get-AppCompatLayers)
    $result = @()

    if ($Paths.Count -eq 0) {
        $interesting = @($layers | Where-Object { $_.FsoDisabled -or $_.ExePath -match "\\(cs2|valorant|r5apex|FortniteClient|cod|bf|Overwatch|League of Legends|RocketLeague|EscapeFromTarkov|RainbowSix|osu!)" } | Select-Object -First 40)
        foreach ($row in $interesting) {
            $result += $row
            if ($row.FsoDisabled) {
                Add-Finding "Fullscreen/Game" "Per-game FSO disabled" "INFO" $row.ExePath "Per-game, only where measured useful" "AppCompat flag DISABLEDXMAXIMIZEDWINDOWEDMODE is set." 2
            }
        }

        if ($interesting.Count -eq 0) {
            Add-Finding "Fullscreen/Game" "Per-game FSO flags" "INFO" "none found" "Pass -GameExePath for exact game checks" "No obvious AppCompat game flags found." 3
        }

        return $result
    }

    foreach ($path in $Paths) {
        if ($path -notmatch "\.exe$" -and -not (Test-Path -LiteralPath $path -PathType Leaf)) {
            Add-Finding "Fullscreen/Game" "Ignored game exe input" "WARN" $path "Pass a .exe file path" "This value is not a Windows executable path, so it was not used for FSO/AppCompat checks." 2
            continue
        }

        $resolved = $path
        try {
            $resolved = (Resolve-Path -Path $path -ErrorAction Stop).Path
        }
        catch {
        }

        $match = @($layers | Where-Object { $_.ExePath -ieq $resolved -or $_.ExePath -ieq $path } | Select-Object -First 1)
        if ($match.Count -gt 0) {
            $result += $match[0]
            if ($match[0].FsoDisabled) {
                Add-Finding "Fullscreen/Game" "FSO flag for $([IO.Path]::GetFileName($path))" "INFO" "disabled" "Only disable if this game benefits" "Per-exe flag DISABLEDXMAXIMIZEDWINDOWEDMODE is set." 1
            }
            else {
                Add-Finding "Fullscreen/Game" "FSO flag for $([IO.Path]::GetFileName($path))" "INFO" "no disable flag" "Default FSO path" "Compatibility layer exists but does not disable FSO." 2
            }
        }
        else {
            $row = [pscustomobject]@{
                Hive = ""
                ExePath = $resolved
                Flags = ""
                FsoDisabled = $false
                RunAsAdmin = $false
                DisableDpiScaling = $false
            }
            $result += $row
            Add-Finding "Fullscreen/Game" "FSO flag for $([IO.Path]::GetFileName($path))" "INFO" "default/no per-exe flag" "Default FSO path" "No AppCompat layer found for this exe." 2
        }
    }

    return $result
}

function Ensure-WindowApi {
    try {
        if (-not ("GamingStatusWindowApi" -as [type])) {
            Add-Type -ReferencedAssemblies System.Windows.Forms -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

public static class GamingStatusWindowApi
{
    public const int GWL_STYLE = -16;
    public const long WS_CAPTION = 0x00C00000L;
    public const long WS_THICKFRAME = 0x00040000L;

    [StructLayout(LayoutKind.Sequential)]
    public struct RECT
    {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }

    [DllImport("user32.dll")]
    public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

    [DllImport("user32.dll", EntryPoint="GetWindowLong")]
    public static extern int GetWindowLong32(IntPtr hWnd, int nIndex);

    [DllImport("user32.dll", EntryPoint="GetWindowLongPtr")]
    public static extern IntPtr GetWindowLongPtr64(IntPtr hWnd, int nIndex);

    public static IntPtr GetWindowLongPtr(IntPtr hWnd, int nIndex)
    {
        if (IntPtr.Size == 8)
        {
            return GetWindowLongPtr64(hWnd, nIndex);
        }
        return new IntPtr(GetWindowLong32(hWnd, nIndex));
    }
}
"@ -ErrorAction Stop
        }

        return $true
    }
    catch {
        Add-Finding "Fullscreen/Game" "Window geometry probe" "UNKNOWN" "not available" "Interactive desktop/session" $_.Exception.Message 3
        return $false
    }
}

function Get-RunningWindowStatus {
    param([string[]]$KnownGamePaths)

    if (-not (Ensure-WindowApi)) {
        return @()
    }

    $screens = @()
    try {
        $screens = @([System.Windows.Forms.Screen]::AllScreens)
    }
    catch {
        return @()
    }

    $knownNames = @()
    foreach ($path in $KnownGamePaths) {
        try {
            $knownNames += [IO.Path]::GetFileNameWithoutExtension($path)
        }
        catch {
        }
    }

    if ($knownNames.Count -eq 0) {
        return @()
    }

    $processes = @(Get-Process -ErrorAction SilentlyContinue | Where-Object {
        $_.MainWindowHandle -ne 0 -and (
            $knownNames -contains $_.ProcessName
        )
    } | Sort-Object ProcessName | Select-Object -First 60)

    $rows = @()
    foreach ($process in $processes) {
        $rect = New-Object GamingStatusWindowApi+RECT
        $ok = [GamingStatusWindowApi]::GetWindowRect($process.MainWindowHandle, [ref]$rect)
        if (-not $ok) { continue }

        $width = $rect.Right - $rect.Left
        $height = $rect.Bottom - $rect.Top
        $stylePtr = [GamingStatusWindowApi]::GetWindowLongPtr($process.MainWindowHandle, [GamingStatusWindowApi]::GWL_STYLE)
        $style = $stylePtr.ToInt64()
        $hasCaption = (($style -band [GamingStatusWindowApi]::WS_CAPTION) -ne 0)
        $hasThickFrame = (($style -band [GamingStatusWindowApi]::WS_THICKFRAME) -ne 0)

        $matchedScreen = $null
        foreach ($screen in $screens) {
            $bounds = $screen.Bounds
            if ([Math]::Abs($rect.Left - $bounds.Left) -le 2 -and
                [Math]::Abs($rect.Top - $bounds.Top) -le 2 -and
                [Math]::Abs($width - $bounds.Width) -le 4 -and
                [Math]::Abs($height - $bounds.Height) -le 4) {
                $matchedScreen = $screen
                break
            }
        }

        $modeGuess = "windowed"
        if ($null -ne $matchedScreen -and -not $hasCaption) {
            $modeGuess = "borderless/fullscreen-size"
        }
        elseif ($null -ne $matchedScreen) {
            $modeGuess = "fullscreen-size with window chrome"
        }

        $path = ""
        try { $path = $process.Path } catch { }

        $rows += [pscustomobject]@{
            Process = $process.ProcessName
            Title = $process.MainWindowTitle
            Path = $path
            Rect = "$($rect.Left),$($rect.Top) $($width)x$($height)"
            Screen = if ($matchedScreen) { "$($matchedScreen.DeviceName) $($matchedScreen.Bounds.Width)x$($matchedScreen.Bounds.Height)" } else { "" }
            HasCaption = $hasCaption
            HasResizableFrame = $hasThickFrame
            ModeGuess = $modeGuess
        }
    }

    if ($rows.Count -gt 0) {
        foreach ($row in $rows | Where-Object { $_.ModeGuess -ne "windowed" } | Select-Object -First 10) {
            Add-Finding "Fullscreen/Game" "Running window mode - $($row.Process)" "INFO" $row.ModeGuess "Geometry probe only" "This does not prove DXGI exclusive mode; it shows window shape and FSO policy separately." 3
        }
    }

    return $rows
}

function Get-NetworkStatus {
    $net = [ordered]@{}

    $netshTcpGlobal = Invoke-TextCommand "netsh.exe" @("int", "tcp", "show", "global")
    $netshTcpSupplemental = Invoke-TextCommand "netsh.exe" @("int", "tcp", "show", "supplemental")
    $netshTcpHeuristics = Invoke-TextCommand "netsh.exe" @("int", "tcp", "show", "heuristics")
    $netshIpGlobal = Invoke-TextCommand "netsh.exe" @("int", "ip", "show", "global")
    $netshSubinterfaces = Invoke-TextCommand "netsh.exe" @("interface", "ipv4", "show", "subinterfaces")

    $script:Raw["netsh_tcp_global"] = $netshTcpGlobal
    $script:Raw["netsh_tcp_supplemental"] = $netshTcpSupplemental
    $script:Raw["netsh_tcp_heuristics"] = $netshTcpHeuristics
    $script:Raw["netsh_ip_global"] = $netshIpGlobal
    $script:Raw["netsh_ipv4_subinterfaces"] = $netshSubinterfaces

    try {
        $adapters = @(Get-NetAdapter -ErrorAction Stop | Sort-Object Status, Name | Select-Object Name, InterfaceDescription, Status, LinkSpeed, MacAddress, DriverInformation)
        $net["Adapters"] = $adapters
        foreach ($adapter in $adapters | Where-Object { $_.Status -eq "Up" }) {
            Add-Finding "Network" "Adapter up - $($adapter.Name)" "INFO" "$($adapter.LinkSpeed)" "Use wired Ethernet for strict latency tests" $adapter.InterfaceDescription 3
        }
    }
    catch {
        $net["Adapters"] = @()
        Add-Finding "Network" "Get-NetAdapter" "UNKNOWN" "not readable" "NetAdapter module available" $_.Exception.Message 3
    }

    try {
        $offloadRaw = Get-NetOffloadGlobalSetting -ErrorAction Stop
        $offload = $offloadRaw | Select-Object Chimney, NetworkDirect, NetworkDirectAcrossIPSubnets, PacketCoalescingFilter, ReceiveSegmentCoalescing, ReceiveSideScaling, TaskOffload
        $net["OffloadGlobal"] = $offload
        if ([string]$offload.ReceiveSideScaling -match "Enabled|1") {
            Add-Finding "Network" "Receive-side scaling" "OK" "enabled" "Enabled for modern NICs" "RSS helps distribute network processing across CPU cores." 2
        }
        else {
            Add-Finding "Network" "Receive-side scaling" "WARN" "$($offload.ReceiveSideScaling)" "Usually enabled" "RSS disabled can bottleneck fast adapters." 2
        }
        if ([string]$offload.ReceiveSegmentCoalescing -match "Enabled|1") {
            Add-Finding "Network" "Receive segment coalescing" "INFO" "enabled" "Measure per game/NIC" "RSC improves throughput but can add batching; low-latency profiles often test disabled." 3
        }
    }
    catch {
        $net["OffloadGlobal"] = $null
    }

    try {
        $rss = @(Get-NetAdapterRss -ErrorAction Stop | Select-Object Name, Enabled, BaseProcessorNumber, MaxProcessorNumber, NumberOfReceiveQueues, Profile)
        $net["AdapterRss"] = $rss
    }
    catch {
        $net["AdapterRss"] = @()
    }

    try {
        $rsc = @(Get-NetAdapterRsc -ErrorAction Stop | Select-Object Name, IPv4Enabled, IPv6Enabled, IPv4OperationalState, IPv6OperationalState)
        $net["AdapterRsc"] = $rsc
    }
    catch {
        $net["AdapterRsc"] = @()
    }

    try {
        $advancedNames = "Interrupt Moderation|Energy Efficient Ethernet|Green Ethernet|Large Send Offload|Receive Side Scaling|Flow Control|Jumbo|Speed.*Duplex|Packet Coalescing|EEE|Power Saving"
        $advanced = @(Get-NetAdapterAdvancedProperty -ErrorAction Stop | Where-Object { $_.DisplayName -match $advancedNames } | Select-Object Name, DisplayName, DisplayValue, RegistryKeyword, RegistryValue)
        $net["AdapterAdvancedGamingRelevant"] = $advanced
        foreach ($prop in $advanced | Where-Object { $_.DisplayName -match "Interrupt Moderation|Energy Efficient|Green Ethernet|Power Saving|Packet Coalescing" }) {
            Add-Finding "Network" "NIC advanced - $($prop.Name) / $($prop.DisplayName)" "INFO" "$($prop.DisplayValue)" "Measure per NIC; disable power-saving features for benchmark profiles" "Driver-specific setting." 3
        }
    }
    catch {
        $net["AdapterAdvancedGamingRelevant"] = @()
    }

    try {
        $ipInterfaces = @(Get-NetIPInterface -AddressFamily IPv4 -ErrorAction Stop | Sort-Object InterfaceMetric | Select-Object InterfaceAlias, AddressFamily, Dhcp, ConnectionState, NlMtu, InterfaceMetric)
        $net["IPInterfaces"] = $ipInterfaces
    }
    catch {
        $net["IPInterfaces"] = @()
    }

    try {
        $dns = @(Get-DnsClientServerAddress -AddressFamily IPv4 -ErrorAction Stop | Select-Object InterfaceAlias, ServerAddresses)
        $net["DnsServers"] = $dns
    }
    catch {
        $net["DnsServers"] = @()
    }

    $ping = @()
    if (-not $NoNetworkBenchmark) {
        $targets = New-Object System.Collections.Generic.List[string]
        try {
            $gateway = Get-NetRoute -DestinationPrefix "0.0.0.0/0" -ErrorAction Stop |
                Sort-Object RouteMetric, InterfaceMetric |
                Select-Object -First 1 -ExpandProperty NextHop
            if ($gateway -and $gateway -ne "0.0.0.0") {
                $targets.Add($gateway) | Out-Null
            }
        }
        catch {
        }

        foreach ($target in $PingTarget) {
            if (-not $targets.Contains($target)) {
                $targets.Add($target) | Out-Null
            }
        }

        foreach ($target in $targets) {
            $ping += Test-PingTarget -Target $target -Count $PingCount
        }
    }
    $net["Ping"] = $ping

    return [pscustomobject]$net
}

function Test-PingTarget {
    param(
        [string]$Target,
        [int]$Count
    )

    $times = @()
    $loss = 100.0
    $status = "UNKNOWN"
    $note = ""

    try {
        $result = @(Test-Connection -ComputerName $Target -Count $Count -ErrorAction SilentlyContinue)
        foreach ($row in $result) {
            if ($null -ne $row.ResponseTime) {
                $times += [double]$row.ResponseTime
            }
            elseif ($null -ne $row.Latency) {
                $times += [double]$row.Latency
            }
        }

        $loss = [Math]::Round((($Count - $times.Count) / [double]$Count) * 100.0, 2)
        if ($times.Count -gt 0) {
            $avg = ($times | Measure-Object -Average).Average
            $min = ($times | Measure-Object -Minimum).Minimum
            $max = ($times | Measure-Object -Maximum).Maximum
            $p95 = Get-Percentile ([double[]]$times) 95
            $jitter = $max - $min
            $status = "OK"
            if ($loss -gt 0) { $status = "WARN" }
            elseif ($jitter -gt 20) { $status = "WARN" }

            if ($status -eq "OK") {
                Add-Finding "Network" "Ping $Target" "OK" "$([Math]::Round($avg, 2)) ms avg / $loss% loss" "0% loss, low jitter" "p95 $([Math]::Round($p95, 2)) ms, jitter $([Math]::Round($jitter, 2)) ms." 2
            }
            else {
                Add-Finding "Network" "Ping $Target" "WARN" "$([Math]::Round($avg, 2)) ms avg / $loss% loss" "0% loss, low jitter" "p95 $([Math]::Round($p95, 2)) ms, jitter $([Math]::Round($jitter, 2)) ms." 1
            }

            return [pscustomobject]@{
                Target = $Target
                Sent = $Count
                Received = $times.Count
                LossPct = $loss
                MinMs = [Math]::Round($min, 3)
                AvgMs = [Math]::Round($avg, 3)
                P95Ms = [Math]::Round($p95, 3)
                MaxMs = [Math]::Round($max, 3)
                JitterMs = [Math]::Round($jitter, 3)
                Status = $status
                Note = $note
            }
        }
    }
    catch {
        $note = $_.Exception.Message
    }

    Add-Finding "Network" "Ping $Target" "WARN" "no replies" "Reachable target" $note 2
    return [pscustomobject]@{
        Target = $Target
        Sent = $Count
        Received = 0
        LossPct = 100
        MinMs = $null
        AvgMs = $null
        P95Ms = $null
        MaxMs = $null
        JitterMs = $null
        Status = $status
        Note = $note
    }
}

function Get-SecurityLatencyStatus {
    $status = [ordered]@{}

    try {
        $dg = Get-CimInstance -Namespace "root\Microsoft\Windows\DeviceGuard" -ClassName "Win32_DeviceGuard" -ErrorAction Stop
        $status["DeviceGuard"] = $dg | Select-Object SecurityServicesConfigured, SecurityServicesRunning, VirtualizationBasedSecurityStatus, RequiredSecurityProperties, AvailableSecurityProperties

        if ($dg.VirtualizationBasedSecurityStatus -eq 2) {
            Add-Finding "Security" "Virtualization-based security" "INFO" "running" "Benchmark both states before changing security" "VBS can affect some latency/FPS results, but disabling it is a security tradeoff." 3
        }
        elseif ($dg.VirtualizationBasedSecurityStatus -eq 1) {
            Add-Finding "Security" "Virtualization-based security" "INFO" "enabled, not running" "Benchmark both states before changing security" "VBS is configured but not currently running." 3
        }
        else {
            Add-Finding "Security" "Virtualization-based security" "INFO" "not running" "Security/performance tradeoff" "No running VBS reported by DeviceGuard WMI." 3
        }
    }
    catch {
        $status["DeviceGuard"] = $null
    }

    try {
        $hvci = Get-RegistryValueSafe "HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity" "Enabled"
        $status["MemoryIntegrityRegistry"] = $hvci
        if ($hvci -eq 1) {
            Add-Finding "Security" "Memory integrity / HVCI" "INFO" "enabled" "Security/performance tradeoff" "Can affect some systems; benchmark before changing." 3
        }
        elseif ($hvci -eq 0) {
            Add-Finding "Security" "Memory integrity / HVCI" "INFO" "disabled" "Security/performance tradeoff" "Registry reports HVCI disabled." 3
        }
    }
    catch {
    }

    return [pscustomobject]$status
}

function Get-OverlayProcessStatus {
    $names = @(
        "Discord", "steam", "GameBar", "GameBarFTServer", "XboxGameBar", "NVIDIA Share",
        "NVIDIA Overlay", "nvsphelper64", "RTSS", "MSIAfterburner", "obs64", "Overwolf",
        "medal", "SteelSeriesGG", "Razer Synapse", "iCUE"
    )

    $rows = @()
    foreach ($process in @(Get-Process -ErrorAction SilentlyContinue)) {
        foreach ($name in $names) {
            if ($process.ProcessName -ieq $name -or $process.ProcessName -like "$name*") {
                $rows += [pscustomobject]@{
                    Process = $process.ProcessName
                    Id = $process.Id
                    MainWindowTitle = $process.MainWindowTitle
                    Path = $(try { $process.Path } catch { "" })
                }
                break
            }
        }
    }

    if ($rows.Count -gt 0) {
        Add-Finding "Overlays" "Overlay/helper processes" "INFO" "$($rows.Count) detected" "Disable for clean A/B benchmarks if needed" "Overlay processes are not automatically bad; keep the state consistent between runs." 3
    }
    else {
        Add-Finding "Overlays" "Overlay/helper processes" "OK" "none from watchlist" "Clean benchmark state" "No common overlay helper process from the watchlist is running." 3
    }

    return $rows | Sort-Object Process, Id
}

function Get-HostStatus {
    $os = $null
    $computer = $null
    $cpu = $null

    try { $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop } catch { }
    try { $computer = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop } catch { }
    try { $cpu = Get-CimInstance Win32_Processor -ErrorAction Stop | Select-Object -First 1 } catch { }

    return [pscustomobject]@{
        ComputerName = $env:COMPUTERNAME
        UserName = $env:USERNAME
        IsAdmin = Test-IsAdmin
        TimestampLocal = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss zzz")
        PowerShell = $PSVersionTable.PSVersion.ToString()
        OS = if ($os) { "$($os.Caption) $($os.Version) build $($os.BuildNumber)" } else { "" }
        InstallDate = if ($os) { $os.InstallDate } else { $null }
        LastBoot = if ($os) { $os.LastBootUpTime } else { $null }
        Manufacturer = if ($computer) { $computer.Manufacturer } else { "" }
        Model = if ($computer) { $computer.Model } else { "" }
        CPU = if ($cpu) { $cpu.Name } else { "" }
        LogicalProcessors = if ($cpu) { $cpu.NumberOfLogicalProcessors } else { $null }
        MemoryGB = if ($computer) { [Math]::Round($computer.TotalPhysicalMemory / 1GB, 2) } else { $null }
    }
}

function Write-ConsoleReport {
    param([object]$Report)

    $colors = @{
        OK = "Green"
        WARN = "Yellow"
        FAIL = "Red"
        INFO = "Cyan"
        UNKNOWN = "DarkYellow"
    }

    Write-Host ""
    Write-Host "Gaming Status Bench - $($Report.Host.ComputerName)" -ForegroundColor White
    Write-Host "Timestamp: $($Report.Host.TimestampLocal) | Admin: $($Report.Host.IsAdmin) | Report: $($Report.Paths.Json)" -ForegroundColor DarkGray
    Write-Host ""

    if ($Report.Analysis -and $Report.Analysis.Timer) {
        $summary = $Report.Analysis.Timer.Summary
        Write-Host "Timer analysis" -ForegroundColor White
        Write-Host "  Overall:               $($summary.Overall)" -ForegroundColor Cyan
        Write-Host "  Global timer mode:     $($summary.GlobalTimerMode)" -ForegroundColor Cyan
        Write-Host "  External Sleep tester: $($summary.ExternalSleepTester)" -ForegroundColor Cyan
        Write-Host "  Remaining jitter:      $($summary.RemainingJitter)" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "  Matrix" -ForegroundColor DarkGray
        foreach ($row in @($Report.Analysis.Timer.Matrix)) {
            $color = if ($colors.ContainsKey([string]$row.Status)) { $colors[[string]$row.Status] } else { "Gray" }
            $line = "    {0,-28} {1,-7} {2}" -f $row.Check, $row.Status, $row.Value
            Write-Host $line -ForegroundColor $color
            Write-Host "      good: $($row.Good) | warn: $($row.Warn) | bad: $($row.Bad)" -ForegroundColor DarkGray
        }
        Write-Host ""
    }

    $order = @("FAIL", "WARN", "OK", "INFO", "UNKNOWN")
    foreach ($status in $order) {
        $items = @($Report.Findings | Where-Object { $_.Status -eq $status } | Sort-Object Priority, Area, Name)
        if ($items.Count -eq 0) { continue }

        Write-Host "[$status] $($items.Count)" -ForegroundColor $colors[$status]
        foreach ($item in $items) {
            $line = "  {0,-18} {1,-42} {2}" -f $item.Area, $item.Name, $item.Value
            Write-Host $line -ForegroundColor $colors[$status]
            if ($item.Note) {
                Write-Host "    $($item.Note)" -ForegroundColor DarkGray
            }
        }
        Write-Host ""
    }

    if ($Report.Paths.Html) {
        Write-Host "HTML: $($Report.Paths.Html)" -ForegroundColor White
    }
}

function ConvertTo-HtmlEscaped {
    param([object]$Value)
    return [System.Net.WebUtility]::HtmlEncode([string]$Value)
}

function Convert-ListToHtmlTable {
    param(
        [object[]]$Rows,
        [string]$EmptyText = "No rows"
    )

    if (-not $Rows -or $Rows.Count -eq 0) {
        return "<p class=""empty"">$([System.Net.WebUtility]::HtmlEncode($EmptyText))</p>"
    }

    $props = @($Rows[0].PSObject.Properties | Select-Object -ExpandProperty Name)
    $html = "<div class=""table-wrap""><table><thead><tr>"
    foreach ($prop in $props) {
        $html += "<th>$(ConvertTo-HtmlEscaped $prop)</th>"
    }
    $html += "</tr></thead><tbody>"

    foreach ($row in $Rows) {
        $html += "<tr>"
        foreach ($prop in $props) {
            $value = $row.$prop
            if ($value -is [System.Collections.IEnumerable] -and $value -isnot [string]) {
                $value = ($value -join ", ")
            }
            $html += "<td>$(ConvertTo-HtmlEscaped $value)</td>"
        }
        $html += "</tr>"
    }

    $html += "</tbody></table></div>"
    return $html
}

function New-HtmlReport {
    param([object]$Report)

    $findingsHtml = Convert-ListToHtmlTable -Rows @($Report.Findings | Sort-Object Priority, Area, Name)
    $pingHtml = Convert-ListToHtmlTable -Rows @($Report.Sections.Network.Ping)
    $gpuHtml = Convert-ListToHtmlTable -Rows @($Report.Sections.DisplayGpu.VideoControllers)
    $nvidiaHtml = Convert-ListToHtmlTable -Rows @($Report.Sections.DisplayGpu.NvidiaSmi)
    $gameExeHtml = Convert-ListToHtmlTable -Rows @($Report.Sections.FullscreenGame.GameExeCompatibility)
    $windowsHtml = Convert-ListToHtmlTable -Rows @($Report.Sections.FullscreenGame.RunningWindows)
    $adapterHtml = Convert-ListToHtmlTable -Rows @($Report.Sections.Network.Adapters)
    $advancedHtml = Convert-ListToHtmlTable -Rows @($Report.Sections.Network.AdapterAdvancedGamingRelevant)
    $overlayHtml = Convert-ListToHtmlTable -Rows @($Report.Sections.Overlays)
    $timerMatrixHtml = Convert-ListToHtmlTable -Rows @($Report.Analysis.Timer.Matrix)
    $timerSummary = $Report.Analysis.Timer.Summary
    $timerJson = ConvertTo-HtmlEscaped (($Report.Sections.Timer | ConvertTo-Json -Depth 6))
    $kernelJson = ConvertTo-HtmlEscaped (($Report.Sections.Kernel.Parsed | ConvertTo-Json -Depth 6))
    $powerJson = ConvertTo-HtmlEscaped (($Report.Sections.Power | ConvertTo-Json -Depth 6))
    $securityJson = ConvertTo-HtmlEscaped (($Report.Sections.Security | ConvertTo-Json -Depth 6))
    $rawJson = ConvertTo-HtmlEscaped (($Report.Raw | ConvertTo-Json -Depth 8))

    $counts = [ordered]@{}
    foreach ($status in @("OK", "WARN", "FAIL", "INFO", "UNKNOWN")) {
        $counts[$status] = @($Report.Findings | Where-Object { $_.Status -eq $status }).Count
    }

@"
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Gaming Status Bench - $(ConvertTo-HtmlEscaped $Report.Host.ComputerName)</title>
  <style>
    :root {
      color-scheme: dark;
      --bg: #101316;
      --panel: #181d22;
      --panel-2: #20262c;
      --text: #eef3f6;
      --muted: #9aa7b1;
      --line: #2d363e;
      --ok: #43d17a;
      --warn: #f2bc57;
      --fail: #ff6b6b;
      --info: #63c7f3;
      --unknown: #b7a6ff;
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      font-family: "Segoe UI", Arial, sans-serif;
      background: var(--bg);
      color: var(--text);
      letter-spacing: 0;
    }
    header {
      padding: 28px clamp(18px, 4vw, 48px) 18px;
      border-bottom: 1px solid var(--line);
      background: #151a1f;
    }
    h1 { margin: 0 0 8px; font-size: clamp(26px, 4vw, 42px); font-weight: 700; }
    h2 { margin: 0 0 14px; font-size: 20px; }
    h3 { margin: 0 0 10px; font-size: 16px; color: var(--muted); }
    .meta { color: var(--muted); line-height: 1.55; }
    main { padding: 22px clamp(18px, 4vw, 48px) 42px; }
    .summary {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
      gap: 12px;
      margin: 0 0 18px;
    }
    .tile {
      border: 1px solid var(--line);
      background: var(--panel);
      border-radius: 8px;
      padding: 14px;
      min-height: 88px;
    }
    .tile .label { color: var(--muted); font-size: 13px; }
    .tile .value { font-size: 32px; font-weight: 700; margin-top: 6px; }
    .OK { color: var(--ok); }
    .WARN { color: var(--warn); }
    .FAIL { color: var(--fail); }
    .INFO { color: var(--info); }
    .UNKNOWN { color: var(--unknown); }
    section {
      margin-top: 18px;
      padding: 18px;
      border: 1px solid var(--line);
      background: var(--panel);
      border-radius: 8px;
    }
    .grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
      gap: 18px;
    }
    .table-wrap {
      overflow: auto;
      border: 1px solid var(--line);
      border-radius: 8px;
      background: var(--panel-2);
    }
    table {
      width: 100%;
      border-collapse: collapse;
      min-width: 720px;
    }
    th, td {
      border-bottom: 1px solid var(--line);
      padding: 9px 10px;
      text-align: left;
      vertical-align: top;
      font-size: 13px;
      line-height: 1.4;
      overflow-wrap: anywhere;
    }
    th {
      color: var(--muted);
      font-weight: 600;
      background: #1b2127;
      position: sticky;
      top: 0;
    }
    pre {
      margin: 0;
      white-space: pre-wrap;
      overflow-wrap: anywhere;
      background: #0d1013;
      border: 1px solid var(--line);
      border-radius: 8px;
      padding: 12px;
      color: #d8e1e7;
      font-size: 12px;
      line-height: 1.45;
    }
    .empty { color: var(--muted); margin: 0; }
    .note { color: var(--muted); margin: 0 0 14px; }
  </style>
</head>
<body>
  <header>
    <h1>Gaming Status Bench</h1>
    <div class="meta">
      $(ConvertTo-HtmlEscaped $Report.Host.ComputerName) | $(ConvertTo-HtmlEscaped $Report.Host.OS)<br>
      $(ConvertTo-HtmlEscaped $Report.Host.CPU) | RAM $(ConvertTo-HtmlEscaped $Report.Host.MemoryGB) GB | Admin: $(ConvertTo-HtmlEscaped $Report.Host.IsAdmin)<br>
      $(ConvertTo-HtmlEscaped $Report.Host.TimestampLocal)
    </div>
  </header>
  <main>
    <div class="summary">
      <div class="tile"><div class="label">OK</div><div class="value OK">$($counts.OK)</div></div>
      <div class="tile"><div class="label">WARN</div><div class="value WARN">$($counts.WARN)</div></div>
      <div class="tile"><div class="label">FAIL</div><div class="value FAIL">$($counts.FAIL)</div></div>
      <div class="tile"><div class="label">INFO</div><div class="value INFO">$($counts.INFO)</div></div>
      <div class="tile"><div class="label">UNKNOWN</div><div class="value UNKNOWN">$($counts.UNKNOWN)</div></div>
    </div>

	    <section>
	      <h2>Timer Analysis</h2>
	      <p class="note">
	        Overall: $(ConvertTo-HtmlEscaped $timerSummary.Overall)<br>
	        Global timer mode: $(ConvertTo-HtmlEscaped $timerSummary.GlobalTimerMode)<br>
	        External Sleep tester: $(ConvertTo-HtmlEscaped $timerSummary.ExternalSleepTester)<br>
	        Remaining jitter: $(ConvertTo-HtmlEscaped $timerSummary.RemainingJitter)
	      </p>
	      $timerMatrixHtml
	    </section>

	    <section>
	      <h2>Findings</h2>
	      $findingsHtml
	    </section>

    <div class="grid">
      <section>
        <h2>Timer</h2>
        <pre>$timerJson</pre>
      </section>
      <section>
        <h2>Kernel / BCDEdit</h2>
        <pre>$kernelJson</pre>
      </section>
      <section>
        <h2>Power</h2>
        <pre>$powerJson</pre>
      </section>
      <section>
        <h2>Security</h2>
        <pre>$securityJson</pre>
      </section>
    </div>

    <section>
      <h2>Display / GPU</h2>
      <h3>WMI video controllers</h3>
      $gpuHtml
      <h3>NVIDIA SMI</h3>
      $nvidiaHtml
    </section>

    <section>
      <h2>Fullscreen / Game</h2>
      <p class="note">FSE vs FSO is not exposed as one perfect public status flag. The report separates global policy, per-exe compatibility flags, and running window geometry.</p>
      <h3>Per-game compatibility flags</h3>
      $gameExeHtml
      <h3>Running windows</h3>
      $windowsHtml
    </section>

    <section>
      <h2>Network</h2>
      <h3>Ping</h3>
      $pingHtml
      <h3>Adapters</h3>
      $adapterHtml
      <h3>Gaming-relevant NIC advanced properties</h3>
      $advancedHtml
    </section>

    <section>
      <h2>Overlays</h2>
      $overlayHtml
    </section>

    <section>
      <h2>Raw Command Output</h2>
      <pre>$rawJson</pre>
    </section>
  </main>
</body>
</html>
"@
}

function Save-Report {
    param([object]$Report)

    if (-not (Test-Path $OutputDir)) {
        New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
    }

    $stamp = Get-Date -Format "yyyyMMdd-HHmmss"
    $base = "gaming-status-$($env:COMPUTERNAME)-$stamp"
    $jsonPath = Join-Path $OutputDir "$base.json"
    $htmlPath = if ($NoHtml) { $null } else { Join-Path $OutputDir "$base.html" }

    $Report.Paths.Json = $jsonPath
    $Report.Paths.Html = $htmlPath

    $jsonObject = ConvertTo-Hashtable $Report
    $jsonObject | ConvertTo-Json -Depth 12 | Set-Content -Path $jsonPath -Encoding UTF8

    if (-not $NoHtml) {
        $html = New-HtmlReport -Report $Report
        Set-Content -Path $htmlPath -Value $html -Encoding UTF8
    }

    return $Report
}

function Main {
    $hostStatus = Get-HostStatus
    if (-not $hostStatus.IsAdmin) {
        Add-Finding "Tool" "Administrator rights" "INFO" "not elevated" "Run as admin for full adapter/BCDEdit visibility" "The report still runs, but some settings may be hidden." 2
    }
    else {
        Add-Finding "Tool" "Administrator rights" "OK" "elevated" "Admin recommended for full report" "Full system queries are more likely to work." 3
    }

    $timer = [ordered]@{
        NtQueryTimerResolution = Get-TimerResolutionStatus
        ProcessTimerPolicy = Set-ProcessTimerResolutionPolicy
        GlobalTimerResolutionRequests = Get-GlobalTimerResolutionRequestStatus
        SleepJitter = Test-SleepJitter -Samples $TimerSampleCount -DelayMs $SleepMs
        HighResolutionWaitableTimer = Test-HighResolutionWaitableTimer -Samples $TimerSampleCount -DelayMs $SleepMs
    }
    $timerObject = [pscustomobject]$timer
    Add-TimerCompositeFindings -Timer $timerObject
    $timerAnalysis = New-TimerAnalysis -Timer $timerObject

    $report = [pscustomobject]@{
        Tool = "GamingStatusBench"
        Version = "0.1.0"
        Host = $hostStatus
        Paths = [ordered]@{
            Json = ""
            Html = ""
        }
        Findings = $script:Findings
        Analysis = [ordered]@{
            Timer = $timerAnalysis
        }
        Sections = [ordered]@{
            Timer = $timerObject
            Kernel = Get-BcdeditStatus
            Power = Get-PowerStatus
            DisplayGpu = Get-DisplayAndGpuStatus
            FullscreenGame = Get-GameModeAndFsoStatus
            Network = Get-NetworkStatus
            Security = Get-SecurityLatencyStatus
            Overlays = Get-OverlayProcessStatus
        }
        Raw = $script:Raw
    }

    $report = Save-Report -Report $report
    if (-not $Quiet) {
        Write-ConsoleReport -Report $report
    }

    if ($OpenHtml -and $report.Paths.Html) {
        Start-Process $report.Paths.Html
    }
}

Main
